module.exports=[38890,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_producten_page_actions_498fea12.js.map