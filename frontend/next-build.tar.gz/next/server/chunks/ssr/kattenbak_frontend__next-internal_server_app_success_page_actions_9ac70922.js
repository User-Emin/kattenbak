module.exports=[8502,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_success_page_actions_9ac70922.js.map