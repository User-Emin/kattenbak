module.exports=[93554,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_verzending_page_actions_e35c7be9.js.map