module.exports=[89808,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_over-ons_page_actions_6b25e981.js.map