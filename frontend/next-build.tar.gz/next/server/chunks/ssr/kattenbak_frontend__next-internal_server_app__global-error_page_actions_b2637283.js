module.exports=[87854,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app__global-error_page_actions_b2637283.js.map