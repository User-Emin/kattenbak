module.exports=[81149,(a,b,c)=>{}];

//# sourceMappingURL=8ef6f_frontend__next-internal_server_app_veelgestelde-vragen_page_actions_74f76126.js.map