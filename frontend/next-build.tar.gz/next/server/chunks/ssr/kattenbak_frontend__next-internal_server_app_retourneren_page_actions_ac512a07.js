module.exports=[82323,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_retourneren_page_actions_ac512a07.js.map