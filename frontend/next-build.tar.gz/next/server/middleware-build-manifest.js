globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9b28481b92afaaf1.js",
    "static/chunks/0375c0b4efc04530.js",
    "static/chunks/84122cc92ba1d848.js",
    "static/chunks/027d70b21784ddce.js",
    "static/chunks/3b497e6535bb8056.js",
    "static/chunks/turbopack-fddca715cb6c8e60.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];