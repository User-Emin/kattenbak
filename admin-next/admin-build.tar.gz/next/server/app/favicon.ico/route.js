var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/44ceb_next_dist_esm_build_templates_app-route_493a3c85.js")
R.c("server/chunks/8ef6f_admin-next__next-internal_server_app_favicon_ico_route_actions_a3a8dafd.js")
R.m(81336)
module.exports=R.m(81336).exports
