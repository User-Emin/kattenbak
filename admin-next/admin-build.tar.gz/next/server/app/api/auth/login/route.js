var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__2afedfb3._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/[root-of-the-server]__cbcb0bdf._.js")
R.c("server/chunks/8ef6f_admin-next__next-internal_server_app_api_auth_login_route_actions_89be4bc4.js")
R.m(78398)
module.exports=R.m(78398).exports
