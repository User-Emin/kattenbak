var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__43c4ed12._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/[root-of-the-server]__cbcb0bdf._.js")
R.c("server/chunks/8ef6f_admin-next__next-internal_server_app_api_products_route_actions_08358f4a.js")
R.m(48648)
module.exports=R.m(48648).exports
