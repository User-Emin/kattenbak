var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__2ed81596._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/[root-of-the-server]__cbcb0bdf._.js")
R.c("server/chunks/8ef6f_admin-next__next-internal_server_app_api_products_[id]_route_actions_31fd78fd.js")
R.m(90717)
module.exports=R.m(90717).exports
