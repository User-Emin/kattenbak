var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/returns/route.js")
R.c("server/chunks/[root-of-the-server]__069b563d._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/[root-of-the-server]__cbcb0bdf._.js")
R.c("server/chunks/8ef6f_admin-next__next-internal_server_app_api_returns_route_actions_56eaed5e.js")
R.m(83703)
module.exports=R.m(83703).exports
