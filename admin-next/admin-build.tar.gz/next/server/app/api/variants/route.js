var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/variants/route.js")
R.c("server/chunks/[root-of-the-server]__5995bebb._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/8ef6f_admin-next__next-internal_server_app_api_variants_route_actions_33ad42f2.js")
R.m(91916)
module.exports=R.m(91916).exports
