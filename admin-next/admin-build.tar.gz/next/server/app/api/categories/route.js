var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/route.js")
R.c("server/chunks/[root-of-the-server]__8722c026._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/8ef6f_admin-next__next-internal_server_app_api_categories_route_actions_bc41faff.js")
R.m(94424)
module.exports=R.m(94424).exports
