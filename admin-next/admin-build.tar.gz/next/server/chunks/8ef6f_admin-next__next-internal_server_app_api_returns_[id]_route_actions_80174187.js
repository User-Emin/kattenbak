module.exports=[5456,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_api_returns_%5Bid%5D_route_actions_80174187.js.map