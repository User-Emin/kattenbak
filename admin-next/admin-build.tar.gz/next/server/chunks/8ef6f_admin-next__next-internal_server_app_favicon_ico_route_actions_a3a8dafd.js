module.exports=[74021,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_favicon_ico_route_actions_a3a8dafd.js.map