module.exports=[72748,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_api_orders_%5Bid%5D_route_actions_c5328281.js.map