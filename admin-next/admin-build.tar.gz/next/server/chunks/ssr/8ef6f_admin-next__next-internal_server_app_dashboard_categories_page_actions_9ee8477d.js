module.exports=[75819,(a,b,c)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_dashboard_categories_page_actions_9ee8477d.js.map