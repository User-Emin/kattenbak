module.exports=[67744,a=>{a.v("/admin/_next/static/media/favicon.0b3bf435.ico")},33260,a=>{"use strict";let b={src:a.i(67744).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=kattenbak_admin-next_app_0ae179d5._.js.map