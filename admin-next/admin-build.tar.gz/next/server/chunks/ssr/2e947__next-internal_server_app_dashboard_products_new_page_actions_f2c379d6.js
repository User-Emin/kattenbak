module.exports=[49345,(a,b,c)=>{}];

//# sourceMappingURL=2e947__next-internal_server_app_dashboard_products_new_page_actions_f2c379d6.js.map