module.exports=[27076,(a,b,c)=>{}];

//# sourceMappingURL=2e947__next-internal_server_app_dashboard_products_%5Bid%5D_page_actions_4d2f08da.js.map