module.exports=[43541,(a,b,c)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app__global-error_page_actions_1a3e2e33.js.map