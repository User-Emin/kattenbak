module.exports=[72431,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app__not-found_page_actions_5a257caf.js.map