module.exports=[93164,(a,b,c)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_dashboard_shipments_page_actions_6f41c7fc.js.map