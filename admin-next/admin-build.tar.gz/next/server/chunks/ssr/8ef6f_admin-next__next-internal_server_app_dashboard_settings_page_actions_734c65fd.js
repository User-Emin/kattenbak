module.exports=[78041,(a,b,c)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_dashboard_settings_page_actions_734c65fd.js.map