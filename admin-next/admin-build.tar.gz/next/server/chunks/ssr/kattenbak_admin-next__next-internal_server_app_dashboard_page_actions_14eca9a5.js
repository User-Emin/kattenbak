module.exports=[42876,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app_dashboard_page_actions_14eca9a5.js.map