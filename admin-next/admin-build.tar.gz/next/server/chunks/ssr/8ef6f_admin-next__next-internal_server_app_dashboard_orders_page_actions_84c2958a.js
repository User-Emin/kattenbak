module.exports=[28243,(a,b,c)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_dashboard_orders_page_actions_84c2958a.js.map