module.exports=[29880,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app_page_actions_ea460ad4.js.map