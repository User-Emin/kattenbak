module.exports=[65892,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_api_variants_route_actions_33ad42f2.js.map