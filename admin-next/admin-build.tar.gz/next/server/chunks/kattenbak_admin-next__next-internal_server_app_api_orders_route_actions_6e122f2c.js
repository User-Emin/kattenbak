module.exports=[45017,(e,o,d)=>{}];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app_api_orders_route_actions_6e122f2c.js.map