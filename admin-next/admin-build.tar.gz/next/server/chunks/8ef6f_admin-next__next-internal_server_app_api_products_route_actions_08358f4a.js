module.exports=[80937,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_api_products_route_actions_08358f4a.js.map