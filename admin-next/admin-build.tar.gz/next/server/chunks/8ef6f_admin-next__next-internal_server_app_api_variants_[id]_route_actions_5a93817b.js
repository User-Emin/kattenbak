module.exports=[31732,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_api_variants_%5Bid%5D_route_actions_5a93817b.js.map