module.exports=[11461,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_api_categories_route_actions_bc41faff.js.map