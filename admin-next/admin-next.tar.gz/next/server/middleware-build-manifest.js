globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/598c270fc3da5e0f.js",
    "static/chunks/feed7cc9e63e5b86.js",
    "static/chunks/182e73373e386405.js",
    "static/chunks/40b258296ca1fc7a.js",
    "static/chunks/d24492a4996d2387.js",
    "static/chunks/turbopack-6151ae792c7f02bc.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];