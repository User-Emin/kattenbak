module.exports=[66071,(e,o,d)=>{}];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_api_returns_route_actions_56eaed5e.js.map