module.exports=[18045,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app_login_page_actions_eb4ac258.js.map