module.exports=[96309,(a,b,c)=>{}];

//# sourceMappingURL=2e947__next-internal_server_app_dashboard_returns_%5Bid%5D_page_actions_2e4468b3.js.map