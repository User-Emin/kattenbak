var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/[root-of-the-server]__5e50bb38._.js")
R.c("server/chunks/[root-of-the-server]__b1e02f52._.js")
R.c("server/chunks/[root-of-the-server]__06e9c2f0._.js")
R.c("server/chunks/kattenbak_admin-next__next-internal_server_app_api_orders_route_actions_6e122f2c.js")
R.m(55612)
module.exports=R.m(55612).exports
