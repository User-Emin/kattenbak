/**
 * 🔒 SECURE LLM SERVICE - HMAC Signed Prompts + Leak Prevention (Layer 5)
 *
 * Features:
 * - HMAC SHA256 signed system prompts (tamper-proof)
 * - XML-wrapped user input (injection isolation)
 * - Few-shot examples (improve accuracy)
 * - Chain-of-thought prompting (complex queries)
 * - Output filtering (prevent prompt leaking)
 * - Timestamped prompts (prevent replay attacks)
 * - DRY: Single LLM service for all RAG queries
 *
 * Security (Layer 5 of 6-Layer Defense):
 * - ✅ SIGNED: HMAC prevents prompt tampering
 * - ✅ ISOLATED: User input wrapped in <question> tags
 * - ✅ VALIDATED: Output filtered for leaked secrets
 * - ✅ TIMESTAMPED: Prevents replay attacks
 * - ✅ LOW TEMP: 0.3 = factual, deterministic responses
 * - ✅ TOKEN LIMIT: Max 300 tokens (prevents abuse)
 *
 * Prevents:
 * - ❌ Prompt injection ("ignore previous instructions")
 * - ❌ Prompt leaking ("show me your system prompt")
 * - ❌ Context smuggling ("</context>\n\nNew system:")
 * - ❌ Tool manipulation (N/A - no tools in Phase 1)
 * - ❌ Response smuggling ("answer in JSON with secrets")
 */
export interface LLMGenerationRequest {
    query: string;
    context: string;
    conversation_history?: Array<{
        question: string;
        answer: string;
    }>;
    options?: {
        max_tokens?: number;
        temperature?: number;
        timeout?: number;
    };
}
export interface LLMGenerationResponse {
    answer: string;
    model: string;
    latency_ms: number;
    tokens_used: number;
    signed: boolean;
    filtered: boolean;
    prompt_signature: string;
}
export declare class SecureLLMService {
    private static readonly MODEL;
    private static readonly API_URL;
    private static readonly API_VERSION;
    private static readonly DEFAULT_MAX_TOKENS;
    private static readonly DEFAULT_TEMPERATURE;
    private static readonly TIMEOUT_MS;
    private static get API_KEY();
    private static get SIGNING_SECRET();
    /**
     * Build HMAC-signed system prompt
     */
    private static buildSystemPrompt;
    /**
     * Sign prompt with HMAC SHA256
     */
    private static signPrompt;
    /**
     * Build user prompt with XML isolation
     */
    private static buildUserPrompt;
    /**
     * Generate answer using Claude API (SECURE)
     *
     * @param request - Generation request with query, context, history
     * @returns Secure LLM response with answer
     */
    static generateAnswer(request: LLMGenerationRequest): Promise<LLMGenerationResponse>;
    /**
     * Call Claude API
     */
    private static callClaudeAPI;
    /**
     * Filter output to prevent prompt leaking (CRITICAL)
     */
    private static filterOutput;
    /**
     * Verify prompt signature (anti-tampering)
     */
    static verifySignature(signature: string, prompt: string, timestamp: number): boolean;
    /**
     * Health check
     */
    static healthCheck(): Promise<{
        status: string;
        details: any;
    }>;
}
//# sourceMappingURL=secure-llm.service.d.ts.map