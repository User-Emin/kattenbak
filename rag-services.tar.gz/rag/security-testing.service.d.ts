/**
 * 🔒 SECURITY TESTING SERVICE - 30+ Jailbreak Tests
 *
 * Tests prompt injection, prompt leaking, and other attacks
 *
 * **Attack Vectors Tested:**
 * 1. Direct prompt injection
 * 2. Indirect prompt extraction
 * 3. Context smuggling
 * 4. Response manipulation
 * 5. Secret leaking
 * 6. System info disclosure
 * 7. Multi-step attacks
 * 8. Unicode/encoding attacks
 * 9. Instruction override
 * 10. Tool manipulation (future)
 *
 * Team: Security Expert + Red Team
 */
export interface SecurityTest {
    name: string;
    attack_vector: string;
    input: string;
    expected_behavior: string;
    should_block: boolean;
    severity: 'critical' | 'high' | 'medium' | 'low';
}
export interface SecurityTestResult {
    test: SecurityTest;
    passed: boolean;
    response?: string;
    blocked_at_layer?: string;
    leaked_info?: string[];
    latency_ms: number;
}
export interface SecurityReport {
    total_tests: number;
    passed: number;
    failed: number;
    pass_rate: number;
    by_severity: Record<string, {
        passed: number;
        failed: number;
    }>;
    by_vector: Record<string, {
        passed: number;
        failed: number;
    }>;
    failed_tests: SecurityTestResult[];
    critical_failures: SecurityTestResult[];
}
export declare class SecurityTestingService {
    /**
     * 30+ Security Tests (Jailbreak Attempts)
     */
    private static readonly SECURITY_TESTS;
    /**
     * Run all security tests
     */
    static runAllTests(): Promise<SecurityReport>;
    /**
     * Run single security test
     */
    private static runTest;
    /**
     * Detect leaked information in response
     */
    private static detectLeaks;
    /**
     * Determine which layer blocked the attack
     */
    private static determineBlockLayer;
    /**
     * Generate comprehensive security report
     */
    private static generateReport;
    /**
     * Print security report
     */
    static printReport(report: SecurityReport): void;
}
//# sourceMappingURL=security-testing.service.d.ts.map