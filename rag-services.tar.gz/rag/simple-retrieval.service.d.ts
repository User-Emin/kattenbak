/**
 * SIMPLE KEYWORD RETRIEVAL SERVICE
 * Fast, deterministic, 80% accurate for product Q&A
 * NO embeddings needed for small corpus (<100 docs)
 *
 * Team: AI Implementation Expert
 */
export interface Document {
    id: string;
    content: string;
    metadata: {
        title: string;
        keywords: string[];
        importance: string;
        type: string;
        [key: string]: any;
    };
    type: string;
}
export interface SearchResult {
    doc: Document;
    score: number;
    matchedKeywords: string[];
}
export declare class SimpleRetrievalService {
    /**
     * Extract keywords from query (Dutch-aware)
     */
    static extractKeywords(query: string): string[];
    /**
     * Search documents by keyword matching
     * Fast: O(n*m) where n=docs, m=keywords (~20-50ms for 21 docs)
     */
    static searchDocuments(query: string, documents: Document[], topK?: number, minScore?: number): SearchResult[];
    /**
     * Format results as context for LLM
     */
    static formatContext(results: SearchResult[]): string;
    /**
     * Health check
     */
    static testRetrieval(documents: Document[]): void;
}
//# sourceMappingURL=simple-retrieval.service.d.ts.map