/**
 * 🚀 ENHANCED RAG PIPELINE SERVICE
 *
 * Integrates ALL 5 RAG techniques + 6-layer security
 *
 * **5 RAG Techniques:**
 * 1. Embeddings (HuggingFace multilingual-e5-base)
 * 2. Query Rewriting (Claude-based, sandboxed)
 * 3. Hierarchical Filtering (metadata-based)
 * 4. Re-ranking (cross-encoder)
 * 5. Secure LLM (HMAC signed prompts)
 *
 * **6-Layer Security:**
 * Layer 1: Input Validation (rate limit, XSS/SQL blocking)
 * Layer 2: Query Rewriting Isolation (signed, fallback)
 * Layer 3: Retrieval Sandboxing (read-only)
 * Layer 4: Re-ranking Validation (deterministic)
 * Layer 5: LLM Safeguards (HMAC signed, XML-wrapped)
 * Layer 6: Response Post-Processing (secret scanning)
 *
 * **DRY Architecture:**
 * - Single entry point for all RAG queries
 * - Each technique optional (graceful degradation)
 * - Comprehensive error handling
 * - Full observability (latency tracking per step)
 *
 * Team: LLM Engineer + Security Expert + ML Engineer
 */
import { RAGResponse } from './response-processor.service';
export interface EnhancedRAGRequest {
    query: string;
    conversation_history?: Array<{
        question: string;
        answer: string;
    }>;
    options?: {
        enable_query_rewriting?: boolean;
        enable_hierarchical_filter?: boolean;
        enable_embeddings?: boolean;
        enable_reranking?: boolean;
        top_k?: number;
        min_score?: number;
        max_tokens?: number;
        temperature?: number;
        overall_timeout_ms?: number;
    };
}
export interface EnhancedRAGResponse extends RAGResponse {
    pipeline_metadata?: {
        query_original: string;
        query_rewritten?: string;
        rewriting_used: boolean;
        filtering_used: boolean;
        embeddings_used: boolean;
        reranking_used: boolean;
        techniques_applied: string[];
        latency_breakdown: {
            total_ms: number;
            rewriting_ms?: number;
            filtering_ms?: number;
            embeddings_ms?: number;
            retrieval_ms?: number;
            reranking_ms?: number;
            llm_ms?: number;
            processing_ms?: number;
        };
        retrieval_stats: {
            docs_total: number;
            docs_after_filter?: number;
            docs_retrieved: number;
            docs_after_rerank?: number;
            docs_used_for_context: number;
        };
        security_applied: string[];
    };
}
export declare class EnhancedRAGPipelineService {
    /**
     * Default options
     */
    private static readonly DEFAULTS;
    /**
     * Main query method - orchestrates entire pipeline
     *
     * @param request - Enhanced RAG request
     * @returns Processed response with full metadata
     */
    static query(request: EnhancedRAGRequest): Promise<EnhancedRAGResponse>;
    /**
     * Health check for entire pipeline
     */
    static healthCheck(): Promise<{
        status: string;
        details: any;
    }>;
}
//# sourceMappingURL=enhanced-rag-pipeline.service.d.ts.map