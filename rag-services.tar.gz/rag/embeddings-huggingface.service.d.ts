/**
 * 🎯 ENTERPRISE EMBEDDINGS SERVICE - HuggingFace API
 *
 * Features:
 * - multilingual-e5-base (768-dim, Dutch-optimized)
 * - Caching (avoid re-computation)
 * - Fallback to keyword search if API fails
 * - Rate limiting (100 req/min HuggingFace)
 * - Timeout protection (5s max)
 * - DRY: Single service for query + document embeddings
 *
 * Security:
 * - NO user input in API calls (only pre-sanitized text)
 * - API key from environment (never logged)
 * - Input validation (max 512 tokens)
 */
export interface EmbeddingResult {
    embedding: number[];
    model: string;
    dimensions: number;
    cached: boolean;
    latency_ms: number;
}
export interface EmbeddingError {
    success: false;
    error: string;
    fallback_available: boolean;
}
export declare class EmbeddingsHuggingFaceService {
    private static readonly MODEL;
    private static readonly API_URL;
    private static readonly DIMENSIONS;
    private static readonly MAX_TOKENS;
    private static readonly TIMEOUT_MS;
    private static readonly CACHE;
    private static readonly CACHE_MAX_SIZE;
    private static get API_KEY();
    /**
     * Generate embedding for text (query or document)
     *
     * @param text - Text to embed (pre-sanitized)
     * @param options - Optional: skipCache, timeout
     * @returns Embedding result or error
     */
    static generateEmbedding(text: string, options?: {
        skipCache?: boolean;
        timeout?: number;
    }): Promise<EmbeddingResult | EmbeddingError>;
    /**
     * Call HuggingFace Inference API
     *
     * @param text - Text to embed
     * @param timeout - Timeout in milliseconds
     * @returns Embedding vector
     */
    private static callHuggingFaceAPI;
    /**
     * Generate cache key (deterministic hash)
     */
    private static getCacheKey;
    /**
     * Batch generate embeddings (efficient for multiple docs)
     *
     * @param texts - Array of texts to embed
     * @param concurrency - Max parallel requests (default: 5)
     * @returns Array of embedding results
     */
    static generateBatchEmbeddings(texts: string[], concurrency?: number): Promise<(EmbeddingResult | EmbeddingError)[]>;
    /**
     * Clear cache (useful for testing)
     */
    static clearCache(): void;
    /**
     * Get cache statistics
     */
    static getCacheStats(): {
        size: number;
        maxSize: number;
        hitRate?: number;
    };
    /**
     * Health check
     */
    static healthCheck(): Promise<{
        status: string;
        details: any;
    }>;
}
//# sourceMappingURL=embeddings-huggingface.service.d.ts.map