/**
 * 🔒 RESPONSE PROCESSOR - Secret Scanning & Metadata Removal (Layer 6)
 *
 * Features:
 * - Scan for API keys, tokens, connection strings
 * - Remove internal metadata (doc IDs, scores, embeddings)
 * - Validate JSON structure
 * - Sanitize error messages (prevent info disclosure)
 * - DRY: Single processor for all RAG responses
 *
 * Security (Layer 6 of 6-Layer Defense - FINAL LINE):
 * - ✅ SECRET SCANNING: Detects 10+ secret patterns
 * - ✅ METADATA REMOVAL: Strips internal info
 * - ✅ ERROR SANITIZATION: Generic user-facing errors
 * - ✅ STRUCTURE VALIDATION: Ensures safe JSON
 * - ✅ AUDIT LOGGING: Records suspicious responses
 *
 * Prevents:
 * - ❌ API key leakage (Claude, HuggingFace, DB)
 * - ❌ Connection string exposure
 * - ❌ Internal metadata disclosure
 * - ❌ Stack trace leakage
 * - ❌ System path disclosure
 */
export interface RAGResponse {
    success: boolean;
    answer?: string;
    sources?: Array<{
        title: string;
        snippet: string;
    }>;
    metadata?: {
        query?: string;
        latency_ms?: number;
        model?: string;
        techniques_used?: string[];
        [key: string]: any;
    };
    error?: string;
    internal_doc_ids?: string[];
    internal_scores?: number[];
    internal_embeddings?: number[][];
    internal_prompts?: string[];
    internal_debug?: any;
}
export interface ProcessorResult {
    response: RAGResponse;
    secrets_found: number;
    metadata_removed: string[];
    sanitized: boolean;
    safe: boolean;
}
export declare class ResponseProcessorService {
    /**
     * Secret patterns (regex for common secrets)
     */
    private static readonly SECRET_PATTERNS;
    /**
     * Internal metadata fields to remove
     */
    private static readonly INTERNAL_FIELDS;
    /**
     * Process RAG response (scan, sanitize, validate)
     *
     * @param response - Raw RAG response
     * @returns Processed response with security report
     */
    static processResponse(response: RAGResponse): ProcessorResult;
    /**
     * Scan text for secrets and redact them
     */
    private static scanAndRedactSecrets;
    /**
     * Sanitize error messages (generic user-facing errors)
     */
    private static sanitizeError;
    /**
     * Validate response structure
     */
    private static validateStructure;
    /**
     * Audit security event (log for monitoring)
     */
    private static auditSecurityEvent;
    /**
     * Build safe error response
     */
    static buildErrorResponse(error: string, originalQuery?: string): RAGResponse;
    /**
     * Build success response (with automatic processing)
     */
    static buildSuccessResponse(answer: string, sources: Array<{
        title: string;
        snippet: string;
    }>, metadata: any): ProcessorResult;
    /**
     * Health check
     */
    static healthCheck(): {
        status: string;
        details: any;
    };
}
//# sourceMappingURL=response-processor.service.d.ts.map