/**
 * 📊 COMPREHENSIVE RAG METRICS SERVICE
 *
 * Implements 9 state-of-the-art metrics:
 *
 * **Traditional IR Metrics:**
 * 1. MRR (Mean Reciprocal Rank)
 * 2. Precision@K (P@1, P@3, P@5)
 * 3. Recall@K (R@5)
 * 4. F1 Score
 * 5. NDCG (Normalized Discounted Cumulative Gain)
 *
 * **RAG-Specific Metrics (RAGAS Framework):**
 * 6. Faithfulness (answer matches context)
 * 7. Answer Relevancy (answer relevant to question)
 * 8. Context Precision (retrieved docs relevant)
 * 9. Context Recall (all relevant docs retrieved)
 *
 * **2025 Advanced:**
 * 10. OPI (Overall Performance Index) - Harmonic mean of all metrics
 *
 * Team: ML Engineer + Data Scientist + LLM Engineer
 */
export interface RetrievalResult {
    query: string;
    retrieved_docs: Array<{
        id: string;
        content: string;
        rank: number;
        score: number;
        relevant: boolean;
    }>;
    answer: string;
    ground_truth_answer?: string;
    ground_truth_doc_ids?: string[];
    latency_ms: number;
}
export interface ComprehensiveMetrics {
    mrr: number;
    precision_at_1: number;
    precision_at_3: number;
    precision_at_5: number;
    recall_at_5: number;
    f1_score: number;
    ndcg_at_5: number;
    faithfulness: number;
    answer_relevancy: number;
    context_precision: number;
    context_recall: number;
    opi: number;
    avg_latency_ms: number;
    total_queries: number;
}
export interface DetailedMetricsReport {
    metrics: ComprehensiveMetrics;
    by_difficulty: Record<string, ComprehensiveMetrics>;
    by_category: Record<string, ComprehensiveMetrics>;
    failed_queries: Array<{
        query: string;
        reason: string;
        metrics: Partial<ComprehensiveMetrics>;
    }>;
    timestamp: string;
    model: string;
}
export declare class ComprehensiveMetricsService {
    /**
     * 1. MRR (Mean Reciprocal Rank)
     *
     * Definition: 1 / rank_of_first_relevant_doc
     * Range: 0-1 (higher is better)
     * Target: >0.90 (excellent)
     */
    static calculateMRR(results: RetrievalResult[]): number;
    /**
     * 2. Precision@K
     *
     * Definition: % of top-K retrieved docs that are relevant
     * Range: 0-1 (higher is better)
     * Target: P@1 >0.80, P@3 >0.90
     */
    static calculatePrecisionAtK(results: RetrievalResult[], k: number): number;
    /**
     * 3. Recall@K
     *
     * Definition: % of all relevant docs that are in top-K
     * Range: 0-1 (higher is better)
     * Target: R@5 >0.90
     */
    static calculateRecallAtK(results: RetrievalResult[], k: number): number;
    /**
     * 4. F1 Score
     *
     * Definition: Harmonic mean of Precision and Recall
     * Range: 0-1 (higher is better)
     * Target: >0.85
     */
    static calculateF1Score(precision: number, recall: number): number;
    /**
     * 5. NDCG@K (Normalized Discounted Cumulative Gain)
     *
     * Definition: Quality of ranking with position discount
     * Range: 0-1 (higher is better)
     * Target: >0.85
     *
     * Formula:
     * DCG = Σ (relevance / log2(rank + 1))
     * IDCG = DCG of perfect ranking
     * NDCG = DCG / IDCG
     */
    static calculateNDCG(results: RetrievalResult[], k: number): number;
    /**
     * 6. Faithfulness (RAGAS)
     *
     * Definition: Does answer match retrieved context?
     * Range: 0-1 (higher is better)
     * Target: >0.95
     *
     * Method: Check if answer claims are supported by context
     */
    static calculateFaithfulness(results: RetrievalResult[]): number;
    /**
     * 7. Answer Relevancy (RAGAS)
     *
     * Definition: Is answer relevant to question?
     * Range: 0-1 (higher is better)
     * Target: >0.90
     *
     * Method: Semantic overlap between question and answer
     */
    static calculateAnswerRelevancy(results: RetrievalResult[]): number;
    /**
     * 8. Context Precision (RAGAS)
     *
     * Definition: Are retrieved docs actually relevant?
     * Range: 0-1 (higher is better)
     * Target: >0.80
     *
     * Same as Precision@K but specific to RAGAS framework
     */
    static calculateContextPrecision(results: RetrievalResult[]): number;
    /**
     * 9. Context Recall (RAGAS)
     *
     * Definition: Did we retrieve all relevant docs?
     * Range: 0-1 (higher is better)
     * Target: >0.90
     *
     * Same as Recall@K but specific to RAGAS framework
     */
    static calculateContextRecall(results: RetrievalResult[]): number;
    /**
     * 10. OPI (Overall Performance Index) - NEW 2025
     *
     * Definition: Harmonic mean of all key metrics
     * Range: 0-1 (higher is better)
     * Target: >0.85
     *
     * Formula: Harmonic mean of MRR, F1, NDCG, Faithfulness, Answer Relevancy
     */
    static calculateOPI(metrics: ComprehensiveMetrics): number;
    /**
     * Calculate ALL metrics for a set of results
     */
    static calculateAllMetrics(results: RetrievalResult[]): ComprehensiveMetrics;
    /**
     * Get zero metrics (for empty results)
     */
    private static getZeroMetrics;
    /**
     * Print formatted metrics report
     */
    static printMetrics(metrics: ComprehensiveMetrics, title?: string): void;
    /**
     * Get grade emoji for metric
     */
    private static getGrade;
    /**
     * Get overall grade
     */
    private static getOverallGrade;
    /**
     * Compare two metric sets (e.g., before vs after)
     */
    static compareMetrics(before: ComprehensiveMetrics, after: ComprehensiveMetrics): Record<string, {
        before: number;
        after: number;
        change: number;
        percentage: number;
    }>;
    /**
     * Health check
     */
    static healthCheck(): {
        status: string;
        details: any;
    };
}
//# sourceMappingURL=comprehensive-metrics.service.d.ts.map