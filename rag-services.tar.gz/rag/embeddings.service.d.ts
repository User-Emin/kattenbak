/**
 * EMBEDDINGS SERVICE
 * Generate vector embeddings for text using sentence-transformers
 * Model: all-MiniLM-L6-v2 (384 dimensions)
 */
export interface EmbeddingResult {
    embedding: number[];
    model: string;
    dimensions: number;
}
export declare class EmbeddingsService {
    private static readonly MODEL;
    private static readonly DIMENSIONS;
    /**
     * Generate embedding for text
     * ✅ FAST MOCK for testing (no HuggingFace API)
     */
    static generateEmbedding(text: string): Promise<EmbeddingResult>;
    /**
     * Convert hash to embedding vector (deterministic)
     */
    private static hashToEmbedding;
    /**
     * Generate embeddings for multiple texts (batch)
     */
    static generateBatchEmbeddings(texts: string[]): Promise<EmbeddingResult[]>;
    /**
     * Calculate content hash for deduplication
     */
    static calculateHash(content: string): string;
    /**
     * Sanitize text before embedding
     * SECURITY: Remove potential injection attempts
     */
    private static sanitizeText;
    /**
     * Call Python embeddings script
     * Uses sentence-transformers library
     */
    private static callPythonEmbeddings;
}
//# sourceMappingURL=embeddings.service.d.ts.map