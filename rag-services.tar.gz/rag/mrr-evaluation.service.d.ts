/**
 * MRR EVALUATION SERVICE
 * Mean Reciprocal Rank for RAG Quality
 * Team: ML Engineer + Data Scientist
 */
interface EvaluationQuestion {
    question: string;
    expected_keywords: string[];
    category: 'product' | 'safety' | 'technical' | 'general';
    difficulty: 'easy' | 'medium' | 'hard';
}
interface EvaluationResult {
    question: string;
    answer: string;
    expected_keywords: string[];
    found_keywords: string[];
    reciprocal_rank: number;
    latency_ms: number;
    sources_count: number;
    category: string;
    difficulty: string;
    passed: boolean;
    score: number;
}
interface MRRReport {
    mrr: number;
    total_questions: number;
    passed: number;
    failed: number;
    avg_latency_ms: number;
    avg_sources: number;
    by_category: Record<string, {
        mrr: number;
        count: number;
    }>;
    by_difficulty: Record<string, {
        mrr: number;
        count: number;
    }>;
    failed_questions: Array<{
        question: string;
        reason: string;
        expected: string[];
        found: string[];
    }>;
}
export declare class MRREvaluationService {
    /**
     * Standard evaluation questions (20+)
     */
    private static readonly EVAL_QUESTIONS;
    /**
     * Calculate reciprocal rank for a single answer
     */
    private static calculateReciprocalRank;
    /**
     * Evaluate single question
     */
    static evaluateQuestion(evalQ: EvaluationQuestion): Promise<EvaluationResult>;
    /**
     * Run full evaluation suite
     */
    static runFullEvaluation(questions?: EvaluationQuestion[]): Promise<MRRReport>;
    /**
     * Print formatted report
     */
    static printReport(report: MRRReport): void;
    /**
     * Quick health check (3 questions)
     */
    static quickCheck(): Promise<{
        passed: boolean;
        mrr: number;
    }>;
}
export {};
//# sourceMappingURL=mrr-evaluation.service.d.ts.map