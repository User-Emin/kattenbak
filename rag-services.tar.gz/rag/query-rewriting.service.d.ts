/**
 * 🎯 QUERY REWRITING SERVICE - Sandboxed Claude Call
 *
 * Features:
 * - Reformulates vague queries into specific ones
 * - Separate Claude instance (NO product context access)
 * - HMAC signed prompts (prevent tampering)
 * - Output validation (max 100 chars, alphanumeric)
 * - Fallback to original query if rewriting fails
 * - DRY: Single rewriter for all query types
 *
 * Security:
 * - ✅ ISOLATED: Rewriting LLM has NO access to product docs
 * - ✅ SIGNED: System prompt HMAC prevents injection
 * - ✅ VALIDATED: Output strictly validated
 * - ✅ FALLBACK: Original query used if suspicious output
 * - ✅ RATE LIMITED: 10 rewrites/min per IP (handled by middleware)
 *
 * Examples:
 * - "hoeveel past erin?" → "Wat is de afvalbak capaciteit in liters?"
 * - "is het stil?" → "Hoeveel lawaai maakt de kattenbak in decibels?"
 * - "past het?" → "Wat zijn de afmetingen van de automatische kattenbak?"
 */
export interface RewriteResult {
    original: string;
    rewritten: string;
    changed: boolean;
    reason?: string;
    latency_ms: number;
    fallback_used: boolean;
}
export declare class QueryRewritingService {
    private static readonly MODEL;
    private static readonly API_URL;
    private static readonly API_VERSION;
    private static readonly MAX_OUTPUT_LENGTH;
    private static readonly TIMEOUT_MS;
    private static get API_KEY();
    private static get SIGNING_SECRET();
    /**
     * System prompt for query rewriting (SIGNED with HMAC)
     */
    private static getSystemPrompt;
    /**
     * Sign system prompt with HMAC SHA256
     */
    private static signPrompt;
    /**
     * Rewrite query (sandboxed)
     *
     * @param query - Original user query (pre-sanitized)
     * @param options - Optional: skipRewrite, timeout
     * @returns Rewrite result with fallback
     */
    static rewriteQuery(query: string, options?: {
        skipRewrite?: boolean;
        timeout?: number;
    }): Promise<RewriteResult>;
    /**
     * Call Claude API for rewriting (ISOLATED)
     */
    private static callClaudeRewriter;
    /**
     * Validate rewritten query
     */
    private static validateRewrittenQuery;
    /**
     * Check if query is already clear (skip rewriting)
     */
    private static isQueryAlreadyClear;
    /**
     * Fallback result (use original query)
     */
    private static fallbackResult;
    /**
     * Health check
     */
    static healthCheck(): Promise<{
        status: string;
        details: any;
    }>;
}
//# sourceMappingURL=query-rewriting.service.d.ts.map