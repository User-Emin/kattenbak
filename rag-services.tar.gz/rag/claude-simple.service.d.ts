/**
 * CLAUDE DIRECT API - SIMPLE KEYWORD RETRIEVAL
 * NO embeddings = FAST + RELIABLE
 * Uses keyword search for instant product Q&A
 * Team: AI Engineer + Security Expert
 */
export declare class ClaudeSimpleService {
    private static readonly API_URL;
    private static readonly MODEL;
    private static readonly API_VERSION;
    private static get API_KEY();
    /**
     * Main RAG pipeline (SIMPLE + FAST)
     */
    static answerQuestion(question: string): Promise<{
        answer: string;
        latency_ms: number;
        model: string;
        sources: any[];
        backend: string;
    }>;
    /**
     * Call Claude REST API directly
     */
    private static callClaude;
    /**
     * Health check
     */
    static healthCheck(): Promise<{
        claude: boolean;
        vectorStore: boolean;
        retrieval: boolean;
    }>;
}
//# sourceMappingURL=claude-simple.service.d.ts.map