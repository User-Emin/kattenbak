globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/9aa6f_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_34835757._.js",
    "static/chunks/9aa6f_next_dist_compiled_react-dom_154fbbde._.js",
    "static/chunks/9aa6f_next_dist_compiled_react-server-dom-turbopack_87af497e._.js",
    "static/chunks/9aa6f_next_dist_compiled_next-devtools_index_7d82befa.js",
    "static/chunks/9aa6f_next_dist_compiled_80aa7135._.js",
    "static/chunks/9aa6f_next_dist_client_c2634a94._.js",
    "static/chunks/9aa6f_next_dist_2273ffc3._.js",
    "static/chunks/9aa6f_@swc_helpers_cjs_c2a12935._.js",
    "static/chunks/kattenbak_frontend_a0ff3932._.js",
    "static/chunks/turbopack-kattenbak_frontend_39377e99._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];