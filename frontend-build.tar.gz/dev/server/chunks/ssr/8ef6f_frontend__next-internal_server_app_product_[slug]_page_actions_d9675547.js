module.exports = [
"[project]/kattenbak/frontend/.next-internal/server/app/product/[slug]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=8ef6f_frontend__next-internal_server_app_product_%5Bslug%5D_page_actions_d9675547.js.map