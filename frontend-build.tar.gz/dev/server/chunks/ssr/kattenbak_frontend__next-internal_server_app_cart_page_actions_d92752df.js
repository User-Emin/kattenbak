module.exports = [
"[project]/kattenbak/frontend/.next-internal/server/app/cart/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_cart_page_actions_d92752df.js.map