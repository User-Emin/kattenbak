module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/kattenbak/frontend/context/cart-context.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * CART CONTEXT - State Management
 * localStorage persistence + cookies voor guest checkout
 * Maximaal DRY, type-safe, performance optimized
 */ __turbopack_context__.s([
    "CartProvider",
    ()=>CartProvider,
    "useCart",
    ()=>useCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const CartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const CART_STORAGE_KEY = 'kattenbak_cart';
const CUSTOMER_DATA_COOKIE = 'kb_customer_data';
const CONSENT_COOKIE = 'kb_consent';
const COOKIE_MAX_AGE = 7; // dagen
const CartProvider = ({ children })=>{
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [customerData, setCustomerData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // Load cart from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const stored = localStorage.getItem(CART_STORAGE_KEY);
        if (stored) {
            try {
                const parsed = JSON.parse(stored);
                setItems(parsed.items || []);
            } catch (e) {
                console.error('Failed to parse cart data');
            }
        }
        // Load customer data from cookies
        const data = loadCustomerData();
        if (data) {
            setCustomerData(data);
        }
    }, []);
    // Save cart to localStorage whenever it changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (items.length > 0) {
            localStorage.setItem(CART_STORAGE_KEY, JSON.stringify({
                items,
                updated: new Date().toISOString()
            }));
        } else {
            localStorage.removeItem(CART_STORAGE_KEY);
        }
    }, [
        items
    ]);
    const itemCount = items.reduce((sum, item)=>sum + item.quantity, 0);
    const subtotal = items.reduce((sum, item)=>sum + item.product.price * item.quantity, 0);
    const addItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((product, quantity = 1)=>{
        setItems((prev)=>{
            const existingIndex = prev.findIndex((item)=>item.product.id === product.id);
            if (existingIndex >= 0) {
                const updated = [
                    ...prev
                ];
                updated[existingIndex].quantity += quantity;
                return updated;
            }
            return [
                ...prev,
                {
                    product,
                    quantity
                }
            ];
        });
    }, []);
    const removeItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((productId)=>{
        setItems((prev)=>prev.filter((item)=>item.product.id !== productId));
    }, []);
    const updateQuantity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((productId, quantity)=>{
        if (quantity <= 0) {
            removeItem(productId);
            return;
        }
        setItems((prev)=>prev.map((item)=>item.product.id === productId ? {
                    ...item,
                    quantity
                } : item));
    }, [
        removeItem
    ]);
    const clearCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        setItems([]);
        localStorage.removeItem(CART_STORAGE_KEY);
    }, []);
    // ✅ Save customer data (localStorage only - GDPR compliant)
    const saveCustomerData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((data)=>{
        setCustomerData(data);
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    // ✅ Load customer data (localStorage only - GDPR compliant)
    const loadCustomerData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if ("TURBOPACK compile-time truthy", 1) return null;
        //TURBOPACK unreachable
        ;
    }, []);
    // ✅ Clear customer data (localStorage only - GDPR compliant)
    const clearCustomerData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        setCustomerData(null);
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CartContext.Provider, {
        value: {
            items,
            itemCount,
            subtotal,
            addItem,
            removeItem,
            updateQuantity,
            clearCart,
            customerData,
            saveCustomerData,
            loadCustomerData,
            clearCustomerData
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/kattenbak/frontend/context/cart-context.tsx",
        lineNumber: 158,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const useCart = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(CartContext);
    if (!context) {
        throw new Error('useCart must be used within CartProvider');
    }
    return context;
};
}),
"[project]/kattenbak/frontend/context/ui-context.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UIProvider",
    ()=>UIProvider,
    "useUI",
    ()=>useUI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const UIContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function UIProvider({ children }) {
    const [isChatOpen, setIsChatOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCartOpen, setIsCartOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // DRY: Open chat, sluit cart
    const openChat = ()=>{
        setIsChatOpen(true);
        setIsCartOpen(false);
    };
    const closeChat = ()=>{
        setIsChatOpen(false);
    };
    // DRY: Open cart, sluit chat
    const openCart = ()=>{
        setIsCartOpen(true);
        setIsChatOpen(false);
    };
    const closeCart = ()=>{
        setIsCartOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(UIContext.Provider, {
        value: {
            isChatOpen,
            isCartOpen,
            openChat,
            closeChat,
            openCart,
            closeCart
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/kattenbak/frontend/context/ui-context.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
}
function useUI() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(UIContext);
    if (!context) {
        throw new Error("useUI must be used within UIProvider");
    }
    return context;
}
}),
"[project]/kattenbak/frontend/lib/utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn,
    "debounce",
    ()=>debounce,
    "formatDate",
    ()=>formatDate,
    "formatPrice",
    ()=>formatPrice,
    "getPlaceholderImage",
    ()=>getPlaceholderImage,
    "truncate",
    ()=>truncate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
function formatPrice(price) {
    return new Intl.NumberFormat("nl-NL", {
        style: "currency",
        currency: "EUR"
    }).format(price);
}
function formatDate(date) {
    return new Intl.DateTimeFormat("nl-NL", {
        year: "numeric",
        month: "long",
        day: "numeric"
    }).format(new Date(date));
}
function debounce(func, wait) {
    let timeout;
    return (...args)=>{
        clearTimeout(timeout);
        timeout = setTimeout(()=>func(...args), wait);
    };
}
function getPlaceholderImage(width = 600, height = 600, text) {
    const displayText = text || `${width}x${height}`;
    return `https://placehold.co/${width}x${height}/f5f5f5/1a1a1a?text=${encodeURIComponent(displayText)}`;
}
function truncate(text, length) {
    if (text.length <= length) return text;
    return text.substring(0, length) + "...";
}
}),
"[project]/kattenbak/frontend/lib/theme-colors.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * THEME COLORS + TYPOGRAPHY - MAXIMAAL DYNAMISCH & DRY
 * 
 * FUNDAMENTELE FIX:
 * - Direct Tailwind classes gebruiken (geen strings in objects)
 * - Tailwind JIT compiler kan deze WEL detecteren
 * - Alles via CSS variabelen voor maximale dynamiek
 * - TYPOGRAPHY: Centralized font weights & sizes
 * 
 * DRY Principles:
 * - Single source of truth
 * - Type-safe met TypeScript
 * - Maintainable & consistent
 */ // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// TYPOGRAPHY - CENTRALIZED FONT SYSTEM
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__turbopack_context__.s([
    "BACKGROUND_OPACITY",
    ()=>BACKGROUND_OPACITY,
    "BG_COLORS",
    ()=>BG_COLORS,
    "BORDER_COLORS",
    ()=>BORDER_COLORS,
    "BORDER_RADIUS",
    ()=>BORDER_RADIUS,
    "BRAND_COLORS",
    ()=>BRAND_COLORS,
    "COMPONENT_COLORS",
    ()=>COMPONENT_COLORS,
    "DARK_BACKGROUNDS",
    ()=>DARK_BACKGROUNDS,
    "GRADIENTS",
    ()=>GRADIENTS,
    "SEMANTIC_COLORS",
    ()=>SEMANTIC_COLORS,
    "SHADOWS",
    ()=>SHADOWS,
    "TEXT_COLORS",
    ()=>TEXT_COLORS,
    "TEXT_COLORS_OLD",
    ()=>TEXT_COLORS,
    "TYPOGRAPHY",
    ()=>TYPOGRAPHY,
    "getButton",
    ()=>getButton,
    "getContrastText",
    ()=>getContrastText,
    "getStepColor",
    ()=>getStepColor,
    "getTextColor",
    ()=>getTextColor
]);
const TYPOGRAPHY = {
    // ✅ DIKKE TYPOGRAPHY - ALLES font-semibold (zoals FAQ balken)
    // Font Weights - MAXIMAAL DUIDELIJK & LEESBAAR
    weight: {
        light: 'font-normal',
        normal: 'font-semibold',
        medium: 'font-semibold',
        semibold: 'font-bold',
        bold: 'font-bold'
    },
    // Font Sizes - Headlines - GROTER & ZICHTBAARDER
    heading: {
        hero: 'text-6xl md:text-8xl',
        h1: 'text-5xl md:text-7xl',
        h2: 'text-4xl md:text-5xl',
        h3: 'text-3xl md:text-4xl',
        h4: 'text-2xl md:text-3xl',
        h5: 'text-xl md:text-2xl'
    },
    // Font Sizes - Body - GROTER & LEESBAARDER
    body: {
        xl: 'text-2xl',
        lg: 'text-xl',
        base: 'text-lg',
        sm: 'text-base',
        xs: 'text-sm'
    },
    // Complete Heading Styles - DIKKE TITELS
    heading_complete: {
        hero: 'text-6xl md:text-8xl font-semibold tracking-tight',
        h1: 'text-5xl md:text-7xl font-semibold tracking-tight',
        h2: 'text-4xl md:text-5xl font-semibold',
        h3: 'text-3xl md:text-4xl font-semibold',
        h4: 'text-2xl md:text-3xl font-semibold',
        h5: 'text-xl md:text-2xl font-semibold'
    },
    // Body Text Styles - DIKKE BODY TEKST (zoals FAQ)
    body_complete: {
        xl: 'text-2xl font-semibold leading-relaxed',
        lg: 'text-xl font-semibold leading-relaxed',
        base: 'text-lg font-semibold leading-relaxed',
        sm: 'text-base font-semibold leading-relaxed',
        xs: 'text-sm font-semibold leading-relaxed'
    }
};
const GRADIENTS = {
    primary: 'bg-gradient-to-r from-gray-900 to-black',
    secondary: 'bg-gradient-to-r from-blue-500 to-blue-600',
    hero: 'bg-gradient-to-br from-gray-50 via-white to-gray-100',
    cta: 'bg-gradient-to-br from-black to-gray-900',
    ctaHover: 'hover:from-gray-900 hover:to-gray-800',
    ctaReverse: 'bg-gradient-to-br from-blue-600 to-gray-900',
    subtle: 'bg-gradient-to-br from-gray-50 via-white to-gray-50',
    textGradient: 'bg-gradient-to-r from-gray-900 to-black bg-clip-text text-transparent'
};
const TEXT_COLORS = {
    // Primary is now BLACK (was cyan)
    primary: {
        50: 'text-gray-50',
        100: 'text-gray-100',
        200: 'text-gray-200',
        300: 'text-gray-300',
        400: 'text-gray-400',
        500: 'text-gray-500',
        600: 'text-gray-600',
        700: 'text-gray-700',
        800: 'text-gray-800',
        900: 'text-gray-900',
        black: 'text-black'
    },
    blue: {
        50: 'text-blue-50',
        100: 'text-blue-100',
        200: 'text-blue-200',
        300: 'text-blue-300',
        400: 'text-blue-400',
        500: 'text-blue-500',
        600: 'text-blue-600',
        700: 'text-blue-700',
        800: 'text-blue-800',
        900: 'text-blue-900'
    },
    // ✅ ORANJE VERVANGEN DOOR ZWART (maximaal dynamisch)
    accent: {
        500: 'text-gray-900',
        600: 'text-black',
        700: 'text-black'
    },
    gray: {
        50: 'text-gray-50',
        100: 'text-gray-100',
        200: 'text-gray-200',
        300: 'text-gray-300',
        400: 'text-gray-400',
        500: 'text-gray-500',
        600: 'text-gray-600',
        700: 'text-gray-700',
        800: 'text-gray-800',
        900: 'text-gray-900',
        black: 'text-black',
        white: 'text-white'
    }
};
const BG_COLORS = {
    // Primary is now BLACK (was cyan)
    primary: {
        50: 'bg-gray-50',
        100: 'bg-gray-100',
        200: 'bg-gray-200',
        300: 'bg-gray-300',
        400: 'bg-gray-400',
        500: 'bg-gray-500',
        600: 'bg-gray-600',
        700: 'bg-gray-700',
        800: 'bg-gray-800',
        900: 'bg-gray-900',
        black: 'bg-black'
    },
    blue: {
        50: 'bg-blue-50',
        100: 'bg-blue-100',
        200: 'bg-blue-200',
        300: 'bg-blue-300',
        400: 'bg-blue-400',
        500: 'bg-blue-500',
        600: 'bg-blue-600',
        700: 'bg-blue-700',
        800: 'bg-blue-800',
        900: 'bg-blue-900'
    },
    // ✅ ORANJE VERVANGEN DOOR ZWART (maximaal dynamisch)
    accent: {
        50: 'bg-gray-50',
        100: 'bg-gray-100',
        500: 'bg-gray-900',
        600: 'bg-black',
        700: 'bg-black',
        800: 'bg-black'
    },
    // ✅ GEEN CREAM MEER - VERVANGEN DOOR ORANJE!
    // cream kleur #eff0cc is vervangen door oranje (bg-orange-50)
    gray: {
        50: 'bg-gray-50',
        100: 'bg-gray-100',
        200: 'bg-gray-200',
        300: 'bg-gray-300',
        400: 'bg-gray-400',
        500: 'bg-gray-500',
        600: 'bg-gray-600',
        700: 'bg-gray-700',
        800: 'bg-gray-800',
        900: 'bg-gray-900',
        black: 'bg-black',
        white: 'bg-white'
    }
};
const BORDER_COLORS = {
    primary: {
        100: 'border-gray-100',
        600: 'border-gray-600'
    },
    blue: {
        100: 'border-blue-100',
        600: 'border-blue-600'
    },
    gray: {
        600: 'border-gray-600',
        800: 'border-gray-800'
    }
};
const SEMANTIC_COLORS = {
    success: {
        bg: 'bg-green-50',
        text: 'text-green-600',
        border: 'border-green-600',
        icon: 'text-green-600'
    },
    warning: {
        bg: 'bg-gray-50',
        text: 'text-black',
        border: 'border-black',
        icon: 'text-black'
    },
    error: {
        bg: 'bg-red-50',
        text: 'text-red-600',
        border: 'border-red-600',
        icon: 'text-red-600'
    },
    info: {
        bg: 'bg-blue-50',
        text: 'text-blue-600',
        border: 'border-blue-600',
        icon: 'text-blue-600'
    }
};
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// COMPONENT-SPECIFIC COLORS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ✅ DRY: NAVBAR KLEUR - Single source of truth
// Navbar gebruikt bg-brand class (zie globals.css: #005980)
const NAVBAR_COLOR = 'bg-brand';
const COMPONENT_COLORS = {
    button: {
        primary: 'bg-gradient-to-br from-gray-900 to-black hover:from-gray-800 hover:to-gray-900 text-white font-bold rounded-full',
        secondary: 'bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-full',
        cta: 'bg-accent hover:bg-accent-dark text-white font-bold rounded-full transform hover:scale-[1.02] transition-all duration-200',
        outline: 'border-2 border-current rounded-full'
    },
    navbar: {
        bg: `${NAVBAR_COLOR}`,
        text: 'text-white',
        hover: 'hover:text-white/80'
    },
    sidebar: {
        bg: 'bg-white',
        text: 'text-gray-900',
        border: 'border-gray-200',
        button: `${NAVBAR_COLOR} hover:bg-brand-dark text-white font-semibold transition-all`,
        ctaButton: 'bg-black hover:bg-gray-900 text-white font-bold transition-all'
    },
    chat: {
        icon: NAVBAR_COLOR,
        iconText: 'text-white'
    }
};
function getTextColor(bgColor) {
    return bgColor === 'dark' ? 'text-white' : 'text-gray-900';
}
function getContrastText(bgShade) {
    // Donker: 700-900 = witte tekst
    // Licht: 50-600 = zwarte tekst
    return bgShade >= 700 ? 'text-white' : 'text-gray-900';
}
function getButton(bgColor, type = 'solid') {
    const isDark = bgColor.includes('black') || bgColor.includes('gray-900') || bgColor.includes('gray-800') || bgColor.includes('blue-600') || bgColor.includes('orange-600');
    const textColor = isDark ? 'text-white' : 'text-gray-900';
    if (type === 'gradient') {
        return `${bgColor} ${textColor}`;
    }
    return `bg-${bgColor} hover:bg-${bgColor.replace('600', '700')} ${textColor}`;
}
function getStepColor(index) {
    const colors = [
        {
            text: TEXT_COLORS.blue[600],
            bg: BG_COLORS.blue[50]
        },
        {
            text: TEXT_COLORS.primary[900],
            bg: BG_COLORS.primary[50]
        },
        {
            text: SEMANTIC_COLORS.warning.text,
            bg: SEMANTIC_COLORS.warning.bg
        },
        {
            text: SEMANTIC_COLORS.success.text,
            bg: SEMANTIC_COLORS.success.bg
        }
    ];
    return colors[index % colors.length];
}
const BACKGROUND_OPACITY = {
    full: 'opacity-100',
    high: 'opacity-90',
    medium: 'opacity-50',
    low: 'opacity-20',
    minimal: 'opacity-10',
    decoration: 'opacity-[0.07]'
};
const BORDER_RADIUS = {
    none: 'rounded-none',
    sm: 'rounded-sm',
    default: 'rounded',
    md: 'rounded-md',
    lg: 'rounded-lg',
    xl: 'rounded-xl',
    '2xl': 'rounded-2xl',
    '3xl': 'rounded-3xl',
    full: 'rounded-full'
};
const SHADOWS = {
    none: 'shadow-none',
    sm: 'shadow-sm',
    default: 'shadow',
    md: 'shadow-md',
    lg: 'shadow-lg',
    xl: 'shadow-xl',
    '2xl': 'shadow-2xl',
    glow: 'shadow-xl hover:shadow-2xl transition-shadow'
};
const DARK_BACKGROUNDS = {
    black: 'bg-black text-white',
    gray900: 'bg-gray-900 text-white',
    gray800: 'bg-gray-800 text-white',
    blue600: 'bg-blue-600 text-white',
    blue700: 'bg-blue-700 text-white',
    accent600: 'bg-black text-white',
    accent700: 'bg-black text-white',
    // Gradients met auto witte tekst
    gradientDark: 'bg-gradient-to-br from-gray-900 to-black text-white',
    gradientBlue: 'bg-gradient-to-br from-blue-600 to-blue-700 text-white',
    gradientAccent: 'bg-gradient-to-br from-black to-gray-900 text-white'
};
const BRAND_COLORS = {
    primary: BG_COLORS.primary,
    secondary: BG_COLORS.blue,
    accent: BG_COLORS.accent,
    neutral: BG_COLORS.gray
};
;
}),
"[project]/kattenbak/frontend/components/ui/button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/theme-colors.ts [app-ssr] (ecmascript)");
;
;
;
;
;
// DRY: Gebruik theme-colors.ts (MAXIMAAL DYNAMISCH)
const VARIANT_STYLES = {
    primary: `${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].button.primary} border-2 border-transparent`,
    secondary: `${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].button.secondary} border-2 border-transparent`,
    cta: `${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].button.cta} border-2 border-transparent`,
    outline: 'bg-transparent border-2 border-current hover:bg-gray-50',
    ghost: 'bg-transparent hover:bg-gray-50',
    brand: 'bg-brand text-white hover:bg-brand-dark border-2 border-transparent'
};
const SIZE_STYLES = {
    sm: 'text-sm px-6 py-2',
    md: 'text-base px-8 py-3',
    lg: 'text-lg px-10 py-4',
    xl: 'text-xl px-12 py-5'
};
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].forwardRef(({ className, variant = 'primary', size = 'md', fullWidth = false, loading = false, leftIcon, rightIcon, children, disabled, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        ref: ref,
        disabled: disabled || loading,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])('inline-flex items-center justify-center gap-2 font-medium rounded transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 hover:scale-105 active:scale-95', VARIANT_STYLES[variant], SIZE_STYLES[size], fullWidth && 'w-full', className),
        ...props,
        children: [
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                className: "h-5 w-5 animate-spin"
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/button.tsx",
                lineNumber: 64,
                columnNumber: 21
            }, ("TURBOPACK compile-time value", void 0)),
            !loading && leftIcon && leftIcon,
            children,
            !loading && rightIcon && rightIcon
        ]
    }, void 0, true, {
        fileName: "[project]/kattenbak/frontend/components/ui/button.tsx",
        lineNumber: 52,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
Button.displayName = "Button";
}),
"[project]/kattenbak/frontend/lib/demo-images.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * DEMO IMAGES - Sync met Backend
 * DRY: Zelfde SVG images als backend voor consistentie
 * Self-contained, geen externe dependencies
 */ // DRY: Default product image (identical to backend)
__turbopack_context__.s([
    "DEFAULT_PRODUCT_IMAGE",
    ()=>DEFAULT_PRODUCT_IMAGE,
    "DEMO_PRODUCT_IMAGES",
    ()=>DEMO_PRODUCT_IMAGES,
    "getDemoProductImages",
    ()=>getDemoProductImages,
    "getFallbackImage",
    ()=>getFallbackImage,
    "isValidImageUrl",
    ()=>isValidImageUrl
]);
const DEFAULT_PRODUCT_IMAGE = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='800' viewBox='0 0 800 800'%3E%3Crect fill='%2310b981' width='800' height='800'/%3E%3Cg fill='%23ffffff' font-family='Arial, sans-serif' font-size='48' font-weight='bold' text-anchor='middle'%3E%3Ctext x='400' y='350'%3EPremium%3C/text%3E%3Ctext x='400' y='420'%3EKattenbak%3C/text%3E%3C/g%3E%3C/svg%3E`;
const DEMO_PRODUCT_IMAGES = {
    main: DEFAULT_PRODUCT_IMAGE,
    front: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='800' viewBox='0 0 800 800'%3E%3Crect fill='%23ef4444' width='800' height='800'/%3E%3Cg fill='%23ffffff' font-family='Arial, sans-serif' font-size='48' font-weight='bold' text-anchor='middle'%3E%3Ctext x='400' y='380'%3EVooraanzicht%3C/text%3E%3C/g%3E%3C/svg%3E`,
    side: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='800' viewBox='0 0 800 800'%3E%3Crect fill='%230ea5e9' width='800' height='800'/%3E%3Cg fill='%23ffffff' font-family='Arial, sans-serif' font-size='48' font-weight='bold' text-anchor='middle'%3E%3Ctext x='400' y='380'%3EZijaanzicht%3C/text%3E%3C/g%3E%3C/svg%3E`,
    inside: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='800' viewBox='0 0 800 800'%3E%3Crect fill='%238b5cf6' width='800' height='800'/%3E%3Cg fill='%23ffffff' font-family='Arial, sans-serif' font-size='48' font-weight='bold' text-anchor='middle'%3E%3Ctext x='400' y='380'%3EBinnenkant%3C/text%3E%3C/g%3E%3C/svg%3E`,
    detail: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='800' viewBox='0 0 800 800'%3E%3Crect fill='%23f97316' width='800' height='800'/%3E%3Cg fill='%23ffffff' font-family='Arial, sans-serif' font-size='48' font-weight='bold' text-anchor='middle'%3E%3Ctext x='400' y='380'%3EDetail%3C/text%3E%3C/g%3E%3C/svg%3E`
};
function getDemoProductImages() {
    return [
        DEMO_PRODUCT_IMAGES.main,
        DEMO_PRODUCT_IMAGES.front,
        DEMO_PRODUCT_IMAGES.side,
        DEMO_PRODUCT_IMAGES.inside,
        DEMO_PRODUCT_IMAGES.detail
    ];
}
function getFallbackImage() {
    return DEFAULT_PRODUCT_IMAGE;
}
function isValidImageUrl(url) {
    // Data URLs altijd valid
    if (url.startsWith('data:')) return true;
    // Relative URLs (uploads) altijd valid
    if (url.startsWith('/')) return true;
    // External URLs: moet http(s) zijn
    try {
        const parsed = new URL(url);
        return [
            'http:',
            'https:'
        ].includes(parsed.protocol);
    } catch  {
        return false;
    }
}
}),
"[project]/kattenbak/frontend/components/ui/product-image.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductImage",
    ()=>ProductImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zoom$2d$in$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ZoomIn$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/zoom-in.js [app-ssr] (ecmascript) <export default as ZoomIn>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/demo-images.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function ProductImage({ src, alt, fill = false, className = '', priority = false, width, height, enableZoom = false, zoomScale = 2.5 }) {
    const [isLightboxOpen, setIsLightboxOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isHovering, setIsHovering] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [mousePosition, setMousePosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        x: 50,
        y: 50
    });
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // DRY: Use fallback from demo-images (sync met backend)
    // MAXIMAAL DYNAMISCH: Eerst API, dan demo fallback
    const imageSrc = src || (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFallbackImage"])();
    // Open lightbox on click
    const handleImageClick = ()=>{
        if (enableZoom) {
            setIsLightboxOpen(true);
            setIsHovering(false);
            document.body.style.overflow = 'hidden';
        }
    };
    // Close lightbox
    const handleCloseLightbox = ()=>{
        setIsLightboxOpen(false);
        setMousePosition({
            x: 50,
            y: 50
        });
        document.body.style.overflow = 'auto';
    };
    // Mouse tracking for hover zoom
    const handleMouseMove = (e)=>{
        if (!containerRef.current || !enableZoom) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width * 100;
        const y = (e.clientY - rect.top) / rect.height * 100;
        // Clamp values between 0 and 100
        const clampedX = Math.max(0, Math.min(100, x));
        const clampedY = Math.max(0, Math.min(100, y));
        setMousePosition({
            x: clampedX,
            y: clampedY
        });
    };
    const handleMouseEnter = ()=>{
        if (enableZoom) setIsHovering(true);
    };
    const handleMouseLeave = ()=>{
        setIsHovering(false);
        setMousePosition({
            x: 50,
            y: 50
        });
    };
    // Keyboard ESC to close lightbox
    const handleKeyDown = (e)=>{
        if (e.key === 'Escape') handleCloseLightbox();
    };
    const transformOrigin = `${mousePosition.x}% ${mousePosition.y}%`;
    const baseClassName = className || 'object-cover';
    // Main image with hover zoom
    const imageElement = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "relative w-full h-full overflow-hidden",
        onMouseMove: handleMouseMove,
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        onClick: handleImageClick,
        children: [
            fill ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: imageSrc,
                alt: alt,
                fill: true,
                className: `${baseClassName} transition-transform duration-200 ease-out ${enableZoom ? 'cursor-zoom-in' : ''}`,
                style: {
                    transform: isHovering ? `scale(${zoomScale})` : 'scale(1)',
                    transformOrigin: transformOrigin
                },
                priority: priority
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                lineNumber: 110,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: imageSrc,
                alt: alt,
                width: width || 800,
                height: height || 800,
                className: `${baseClassName} transition-transform duration-200 ease-out ${enableZoom ? 'cursor-zoom-in' : ''}`,
                style: {
                    transform: isHovering ? `scale(${zoomScale})` : 'scale(1)',
                    transformOrigin: transformOrigin
                },
                priority: priority
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                lineNumber: 124,
                columnNumber: 9
            }, this),
            enableZoom && !isHovering && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-4 right-4 bg-black/60 text-white p-2 rounded-full backdrop-blur-sm transition-opacity",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zoom$2d$in$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ZoomIn$3e$__["ZoomIn"], {
                    className: "h-5 w-5"
                }, void 0, false, {
                    fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                    lineNumber: 143,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                lineNumber: 142,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
        lineNumber: 101,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            imageElement,
            isLightboxOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[9999] bg-black/95 flex items-center justify-center",
                onClick: handleCloseLightbox,
                onKeyDown: handleKeyDown,
                tabIndex: 0,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleCloseLightbox,
                        className: "absolute top-6 right-6 z-[10000] bg-white/10 hover:bg-white/20 text-white p-3 rounded-full backdrop-blur-sm transition-all",
                        "aria-label": "Sluiten",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            className: "h-6 w-6"
                        }, void 0, false, {
                            fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                            lineNumber: 168,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                        lineNumber: 163,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative max-w-6xl max-h-[90vh] w-full h-full mx-8",
                        onClick: (e)=>e.stopPropagation(),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-full h-full flex items-center justify-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: imageSrc,
                                alt: alt,
                                fill: true,
                                className: "object-contain",
                                priority: true
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                                lineNumber: 177,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                            lineNumber: 176,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                        lineNumber: 172,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-6 left-1/2 -translate-x-1/2 text-white/60 text-sm text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "ESC of klik buiten om te sluiten"
                        }, void 0, false, {
                            fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                            lineNumber: 189,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                        lineNumber: 188,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/kattenbak/frontend/components/ui/product-image.tsx",
                lineNumber: 156,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/kattenbak/frontend/lib/image-config.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * IMAGE CONFIGURATION - Maximaal DRY & DYNAMISCH
 * Sync met backend demo images voor consistentie
 * NO HARDCODED PATHS - Alles via API of demo fallback
 */ __turbopack_context__.s([
    "IMAGE_CONFIG",
    ()=>IMAGE_CONFIG,
    "IMAGE_QUALITY",
    ()=>IMAGE_QUALITY,
    "getImageFillProps",
    ()=>getImageFillProps,
    "getImageFixedProps",
    ()=>getImageFixedProps,
    "getProductImage",
    ()=>getProductImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/demo-images.ts [app-ssr] (ecmascript)");
;
const IMAGE_CONFIG = {
    // DRY: Alle images gebruiken demo fallback (sync met backend)
    // Deze worden ALLEEN gebruikt als fallback - echte images komen van API
    hero: {
        main: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_PRODUCT_IMAGE"],
        alt: 'Premium automatische kattenbak'
    },
    usps: {
        capacity: {
            src: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_PRODUCT_IMAGE"],
            alt: '10.5L grote capaciteit'
        },
        quiet: {
            src: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_PRODUCT_IMAGE"],
            alt: 'Ultra-stille motor onder 40dB'
        }
    },
    // Product images - ALLEEN fallback, echte data via API
    product: {
        main: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_PRODUCT_IMAGE"],
        alt: 'Premium Kattenbak'
    },
    // Cart & Checkout - ALLEEN fallback, echte data via API
    cart: {
        thumbnail: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_PRODUCT_IMAGE"],
        alt: 'Premium Kattenbak'
    },
    checkout: {
        thumbnail: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_PRODUCT_IMAGE"],
        alt: 'Premium Kattenbak'
    },
    // Fallback placeholder (zelfde als demo main)
    placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_PRODUCT_IMAGE"]
};
const IMAGE_QUALITY = 85;
const getProductImage = (images)=>{
    // 1. Probeer images array vanuit API (DYNAMISCH)
    if (images && Array.isArray(images) && images.length > 0 && images[0]) {
        return images[0];
    }
    // 2. Fallback naar demo image (sync met backend)
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$demo$2d$images$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFallbackImage"])();
};
const getImageFillProps = (config)=>{
    console.log('🖼️ Loading image:', config.src || 'placeholder');
    return {
        src: config.src || IMAGE_CONFIG.placeholder,
        alt: config.alt,
        fill: true,
        quality: IMAGE_QUALITY,
        sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
        onError: ()=>console.error('❌ Image failed to load:', config.src),
        onLoad: ()=>console.log('✅ Image loaded:', config.src)
    };
};
const getImageFixedProps = (config)=>({
        src: config.src || IMAGE_CONFIG.placeholder,
        alt: config.alt,
        width: config.width,
        height: config.height,
        quality: IMAGE_QUALITY,
        onError: ()=>console.error('❌ Image failed to load:', config.src),
        onLoad: ()=>console.log('✅ Image loaded:', config.src)
    });
}),
"[project]/kattenbak/frontend/components/ui/separator.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Separator",
    ()=>Separator,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/utils.ts [app-ssr] (ecmascript)");
;
;
const SPACING_STYLES = {
    sm: 'my-4',
    md: 'my-8',
    lg: 'my-12',
    xl: 'my-16'
};
const VARIANT_STYLES = {
    float: 'h-px bg-gradient-to-r from-transparent via-gray-400 to-transparent',
    solid: 'h-px bg-gray-400',
    gradient: 'h-px bg-gradient-to-r from-gray-300 via-gray-500 to-gray-300'
};
const Separator = ({ variant = 'float', spacing = 'lg', fade = true, shadow = true, className })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])('w-full', SPACING_STYLES[spacing], className),
        role: "separator",
        "aria-orientation": "horizontal",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(VARIANT_STYLES[variant], shadow && 'shadow-sm', fade && variant === 'float' && 'opacity-80', 'transition-opacity duration-300')
        }, void 0, false, {
            fileName: "[project]/kattenbak/frontend/components/ui/separator.tsx",
            lineNumber: 50,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/kattenbak/frontend/components/ui/separator.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Separator;
}),
"[project]/kattenbak/frontend/lib/content.config.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * CONTENT CONFIG - DRY & MAINTAINABLE
 * Alle website teksten op één plek
 * 
 * BELANGRIJK: Dit is de ENIGE plek waar content wordt gedefinieerd!
 * Vermijd hardcoded strings in components.
 */ // ============================================
// HOME PAGE CONTENT
// ============================================
__turbopack_context__.s([
    "HOME_CONTENT",
    ()=>HOME_CONTENT,
    "PRODUCT_CONTENT",
    ()=>PRODUCT_CONTENT,
    "SHARED_CONTENT",
    ()=>SHARED_CONTENT,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getContent",
    ()=>getContent
]);
const HOME_CONTENT = {
    hero: {
        title: 'Slimme Kattenbak',
        subtitle: 'Automatisch • Smart • Hygiënisch'
    },
    uspSection: {
        title: 'Waarom Kiezen Voor Deze Kattenbak?'
    },
    features: [
        {
            icon: 'package',
            title: '10.5L Capaciteit',
            description: 'De grootste afvalbak in zijn klasse. Minder vaak legen betekent meer vrijheid voor jou.'
        },
        {
            icon: 'volume',
            title: 'Ultra-Quiet Motor',
            description: 'Werkt onder 40 decibel. Zo stil dat je het nauwelijks hoort, maar het doet zijn werk perfect.'
        }
    ],
    videoSection: {
        title: 'Zie Het in Actie',
        subtitle: '2:30 min demo video'
    },
    faqSection: {
        title: 'Veelgestelde Vragen',
        subtitle: 'Alles wat je moet weten'
    },
    faqs: [
        {
            q: 'Hoe werkt de zelfreinigende functie?',
            a: 'De kattenbak detecteert automatisch wanneer je kat klaar is en start een reinigingscyclus. Alle afval wordt verzameld in een afgesloten compartiment.'
        },
        {
            q: 'Voor welke katten is dit geschikt?',
            a: 'Geschikt voor katten van alle maten tot 7kg. De ruime binnenruimte zorgt voor comfort.'
        },
        {
            q: 'Hoe vaak moet ik de afvalbak legen?',
            a: 'Bij één kat ongeveer 1x per week. De 10L capaciteit betekent minder onderhoud.'
        },
        {
            q: 'Is de app-bediening inbegrepen?',
            a: 'Ja! De app is gratis te downloaden en biedt realtime monitoring, schema\'s en gezondheidsrapporten.'
        }
    ]
};
const PRODUCT_CONTENT = {
    mainDescription: 'De automatische kattenbak met zelfreinigende functie. Perfect voor katten tot 7kg. Volledig automatisch met app-bediening.',
    // UI Labels - DRY
    labels: {
        showMore: 'Meer',
        showLess: 'Minder',
        showAllSpecs: 'Meer specificaties',
        hideSpecs: 'Minder specificaties',
        ourProduct: 'Onze',
        versus: 'vs'
    },
    // Top 3 USPs (boven prijs)
    topUsps: [
        {
            icon: 'check',
            text: 'Gratis verzending vanaf €50'
        },
        {
            icon: 'check',
            text: '10.5L capaciteit - Grootste afvalbak'
        },
        {
            icon: 'check',
            text: 'Ultra-stil motor (<40 decibel)'
        }
    ],
    // Marketing USPs (onder prijs)
    marketingUsps: [
        {
            icon: 'dot',
            text: '14 dagen bedenktijd'
        },
        {
            icon: 'dot',
            text: 'Veilig betalen met Mollie'
        }
    ],
    // Product sections
    sections: {
        description: {
            title: 'Over dit product',
            videoCaption: '🎥 Bekijk de demo video'
        }
    },
    // Specs comparison (accordion) - ALLE 12 specs uit screenshot
    specs: [
        // ✅ EERSTE 4 SPECS (altijd zichtbaar)
        {
            icon: 'sparkles',
            title: 'Zelfreinigende Functie',
            description: 'Volledig automatisch systeem dat na elk gebruik de bak reinigt. Intelligente sensoren detecteren wanneer je kat klaar is.',
            hasFeature: true
        },
        {
            icon: 'package',
            title: 'Open-Top Design',
            description: 'Laag-stress ontwerp zonder deur. Je kat voelt zich vrij en niet opgesloten, wat stress vermindert.',
            hasFeature: true,
            competitors: [
                false,
                true
            ]
        },
        {
            icon: 'shieldCheck',
            title: 'Dubbele Veiligheidssensoren',
            description: 'Twee onafhankelijke sensoren voor maximale veiligheid. Stopt automatisch als je kat de bak in gaat.',
            hasFeature: true,
            competitors: [
                false,
                false
            ]
        },
        {
            icon: 'smartphone',
            title: 'App Bediening & Monitoring',
            description: 'Real-time monitoring via smartphone app. Bekijk status, plan reinigingen en ontvang gezondheidsdata.',
            hasFeature: true,
            competitors: [
                true,
                false
            ]
        },
        // ✅ EXTRA SPECS (alleen zichtbaar na "Meer" klik)
        {
            icon: 'filter',
            title: 'High-Efficiency Filter',
            description: 'Geavanceerd filtersysteem voor optimale luchtzuivering. Houdt de lucht fris en geurvrij.',
            hasFeature: true,
            competitors: [
                false,
                false
            ]
        },
        {
            icon: 'package',
            title: 'Afvalbak Capaciteit',
            description: 'De grootste afvalbak in zijn klasse. 10.5L betekent minder vaak legen - tot 7 dagen voor 1 kat.',
            value: '10.5L',
            competitors: [
                '9L',
                '7L'
            ]
        },
        {
            icon: 'shield',
            title: 'Anti-Splash Hoge Wanden',
            description: 'Extra hoge wanden voorkomen morsen. Houdt de omgeving schoon, zelfs bij actieve katten.',
            hasFeature: true,
            competitors: [
                false,
                false
            ]
        },
        {
            icon: 'layers',
            title: 'Makkelijk Te Demonteren',
            description: 'Modulair ontwerp voor eenvoudige reiniging. Alle onderdelen zijn afneembaar en afwasbaar.',
            hasFeature: true,
            competitors: [
                false,
                true
            ]
        },
        {
            icon: 'checkCircle',
            title: 'Geschikt Voor Alle Kattenbakvulling',
            description: 'Werkt met klonterende en niet-klonterende korrels. Flexibel in gebruik.',
            hasFeature: true,
            competitors: [
                true,
                false
            ]
        },
        {
            icon: 'maximize',
            title: 'Compact Footprint, Groot Interieur',
            description: 'Klein aan de buitenkant, ruim van binnen. Optimaal ruimtegebruik voor je huis.',
            hasFeature: true,
            competitors: [
                false,
                false
            ]
        },
        {
            icon: 'volumeX',
            title: 'Ultra-Stil Motor (<40 dB)',
            description: 'Fluisterstille motor die je kat niet verstoort. Werkt onder 40 decibel - stiller dan een gesprek.',
            hasFeature: true,
            competitors: [
                true,
                false
            ]
        },
        {
            icon: 'settings',
            title: 'Modulair Ontwerp (OEM-Friendly)',
            description: 'Professioneel modulair ontwerp. Makkelijk te upgraden en onderdelen vervangbaar.',
            hasFeature: true,
            competitors: [
                false,
                false
            ]
        }
    ],
    // Aantal specs dat standaard zichtbaar is
    initialVisibleSpecs: 4
};
const SHARED_CONTENT = {
    breadcrumb: {
        home: 'Home'
    },
    buttons: {
        addToCart: 'In Winkelwagen',
        addingToCart: 'Toevoegen...',
        viewProduct: 'Bekijk Product',
        viewCart: 'Bekijk Winkelwagen',
        checkout: 'Afrekenen',
        startChat: 'Start Chat',
        continueShopping: 'Verder Winkelen',
        placeOrder: 'Bestelling Plaatsen',
        processing: 'Verwerken...'
    },
    quantity: {
        label: 'Aantal:',
        increase: 'Verhoog aantal',
        decrease: 'Verlaag aantal'
    },
    cart: {
        empty: {
            title: 'Je winkelwagen is leeg',
            subtitle: 'Ontdek onze premium zelfreinigende kattenbak'
        },
        title: 'Winkelwagen',
        itemCount: (count)=>`${count} ${count === 1 ? 'product' : 'producten'}`,
        summary: {
            title: 'Overzicht',
            subtotal: 'Subtotaal',
            shipping: 'Verzendkosten',
            shippingFree: 'Gratis',
            tax: 'BTW (21%)',
            total: 'Totaal'
        },
        benefits: [
            'Gratis verzending vanaf €50',
            'Veilig betalen met Mollie',
            '14 dagen bedenktijd'
        ],
        guestCheckout: 'Geen account nodig - direct afrekenen als gast'
    },
    checkout: {
        title: 'Afrekenen',
        steps: [
            'Gegevens',
            'Betaling',
            'Bevestiging'
        ],
        shipping: {
            title: 'Verzendadres',
            useExisting: 'Gebruik bestaand adres',
            addNew: 'Nieuw adres'
        },
        payment: {
            title: 'Betaling',
            method: 'Selecteer betaalmethode'
        },
        summary: 'Overzicht',
        benefits: [
            'Veilig betalen met Mollie',
            'Gratis verzending vanaf €50',
            '14 dagen bedenktijd'
        ]
    },
    success: {
        title: 'Bedankt voor je bestelling!',
        subtitle: 'We hebben je bestelling ontvangen en zijn deze aan het verwerken.',
        orderNumber: 'Bestelnummer',
        email: 'Je ontvangt een bevestiging op',
        nextSteps: {
            title: 'Wat gebeurt er nu?',
            steps: [
                {
                    title: 'Bevestiging',
                    description: 'Je ontvangt binnen enkele minuten een bevestigingsmail'
                },
                {
                    title: 'Verwerking',
                    description: 'We verwerken je bestelling en maken deze verzendklaar'
                },
                {
                    title: 'Verzending',
                    description: 'Je ontvangt een track & trace code zodra het pakket onderweg is'
                }
            ]
        },
        orderSummary: 'Jouw bestelling'
    }
};
function getContent(obj, key, fallback) {
    const keys = key.split('.');
    let value = obj;
    for (const k of keys){
        if (value && typeof value === 'object' && k in value) {
            value = value[k];
        } else {
            return fallback;
        }
    }
    return value ?? fallback;
}
const __TURBOPACK__default__export__ = {
    HOME_CONTENT,
    PRODUCT_CONTENT,
    SHARED_CONTENT
};
}),
"[project]/kattenbak/frontend/components/ui/mini-cart.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MiniCart",
    ()=>MiniCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$context$2f$cart$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/context/cart-context.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$product$2d$image$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/components/ui/product-image.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$image$2d$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/image-config.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/plus.js [app-ssr] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/minus.js [app-ssr] (ecmascript) <export default as Minus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-ssr] (ecmascript) <export default as ShoppingCart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/components/ui/separator.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/theme-colors.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$content$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/content.config.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
const MiniCart = ({ onClose })=>{
    const { items, itemCount, subtotal, removeItem, updateQuantity } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$context$2f$cart$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCart"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    // DRY Handler voor navigatie met auto-close - Maintainable
    const handleNavigate = (path)=>{
        if (onClose) {
            onClose(); // Sluit de mini-cart
        }
        router.push(path); // Navigeer naar pagina
    };
    if (itemCount === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `p-8 text-center ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.bg}`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__["ShoppingCart"], {
                    className: "h-12 w-12 mx-auto mb-4 text-gray-300"
                }, void 0, false, {
                    fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-4",
                    children: "Je winkelwagen is leeg"
                }, void 0, false, {
                    fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "outline",
                    className: "border-2 border-gray-300 hover:border-accent rounded px-6",
                    onClick: ()=>handleNavigate('/'),
                    children: "Verder winkelen"
                }, void 0, false, {
                    fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
            lineNumber: 33,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex flex-col h-full ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.bg}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-y-auto p-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: `text-xl font-normal mb-6 ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                        children: [
                            "Winkelwagen (",
                            itemCount,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative w-20 h-20 bg-gray-50 rounded overflow-hidden flex-shrink-0",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$product$2d$image$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProductImage"], {
                                            src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$image$2d$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getProductImage"])(item.product.images),
                                            alt: item.product.name,
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                            lineNumber: 53,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 52,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: `font-medium text-sm mb-1 truncate ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                                                children: item.product.name
                                            }, void 0, false, {
                                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                lineNumber: 62,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-gray-600 mb-2",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatPrice"])(item.product.price)
                                            }, void 0, false, {
                                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                lineNumber: 65,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>updateQuantity(item.product.id, item.quantity - 1),
                                                        className: `w-9 h-9 rounded border-2 ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.border} hover:border-accent flex items-center justify-center hover:bg-gray-100 transition active:scale-95 ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                                                        "aria-label": "Verlaag aantal",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                                            className: "h-3 w-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                            lineNumber: 75,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                        lineNumber: 70,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `w-10 text-center text-base font-semibold ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                                                        children: item.quantity
                                                    }, void 0, false, {
                                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                        lineNumber: 78,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>updateQuantity(item.product.id, item.quantity + 1),
                                                        className: `w-9 h-9 rounded border-2 ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.border} hover:border-accent flex items-center justify-center hover:bg-gray-100 transition active:scale-95 ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                                                        "aria-label": "Verhoog aantal",
                                                        disabled: item.quantity >= item.product.stock,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                            className: "h-3 w-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                            lineNumber: 88,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                        lineNumber: 82,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                                lineNumber: 69,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 61,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>removeItem(item.product.id),
                                        className: `text-gray-400 hover:${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text} transition`,
                                        "aria-label": "Verwijder uit winkelwagen",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                            className: "h-5 w-5"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                            lineNumber: 98,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 93,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, item.product.id, true, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 51,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex-shrink-0 ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.bg} border-t ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.border} p-6 pt-5`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2 mb-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: `font-semibold ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text} text-base mb-3`,
                                children: "Overzicht"
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 109,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gray-600 text-sm",
                                        children: "Subtotaal"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 113,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `font-medium ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatPrice"])(subtotal)
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 114,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 112,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gray-600 text-sm",
                                        children: "Verzendkosten"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 119,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm font-medium text-green-600",
                                        children: "Gratis"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 120,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 118,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gray-600 text-sm",
                                        children: "BTW (21%)"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 125,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `font-medium ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatPrice"])(subtotal * 0.21)
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 126,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 124,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"], {
                                className: "my-3"
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `font-bold ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text} text-lg`,
                                        children: "Totaal"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 133,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `text-2xl font-bold ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].sidebar.text}`,
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatPrice"])(subtotal * 1.21)
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                        lineNumber: 134,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 132,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                size: "lg",
                                fullWidth: true,
                                variant: "outline",
                                className: "border-2 border-gray-300 hover:border-accent bg-white text-gray-900 font-semibold rounded-sm",
                                onClick: ()=>handleNavigate('/cart'),
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$content$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SHARED_CONTENT"].buttons.viewCart
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 140,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                size: "lg",
                                fullWidth: true,
                                variant: "cta",
                                className: "rounded-sm",
                                onClick: ()=>handleNavigate(`/checkout?product=${items[0].product.id}&quantity=${items[0].quantity}`),
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$content$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SHARED_CONTENT"].buttons.checkout
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                                lineNumber: 151,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 text-center mt-4",
                        children: "Gratis verzending • 30 dagen bedenktijd"
                    }, void 0, false, {
                        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                        lineNumber: 162,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/kattenbak/frontend/components/ui/mini-cart.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
}),
"[project]/kattenbak/frontend/components/layout/header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Header",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-ssr] (ecmascript) <export default as ShoppingCart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/menu.js [app-ssr] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$context$2f$cart$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/context/cart-context.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$context$2f$ui$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/context/ui-context.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$mini$2d$cart$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/components/ui/mini-cart.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
function Header() {
    const { itemCount } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$context$2f$cart$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCart"])();
    const { isCartOpen, openCart, closeCart } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$context$2f$ui$2d$context$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useUI"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // Dynamisch checken of we op cart pagina zijn - DRY & Maintainable
    const isOnCartPage = pathname === '/cart';
    // Auto-close cart wanneer we naar cart pagina navigeren
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (isOnCartPage && isCartOpen) {
            closeCart();
        }
    }, [
        isOnCartPage,
        isCartOpen,
        closeCart
    ]);
    // Handler voor cart toggle met page detection
    const handleCartToggle = ()=>{
        if (isOnCartPage) {
            closeCart();
            return;
        }
        if (isCartOpen) {
            closeCart();
        } else {
            openCart();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "sticky top-0 z-50 bg-brand",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-6 lg:px-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between h-18",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    className: "flex items-center hover:opacity-90 transition",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/logo.png",
                                        alt: "Catsupply",
                                        width: 180,
                                        height: 180,
                                        className: "h-14 w-auto",
                                        priority: true
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                        lineNumber: 50,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                    className: "hidden md:flex items-center gap-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/",
                                            className: "text-white hover:text-white/80 transition font-medium",
                                            children: "Home"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 62,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/over-ons",
                                            className: "text-white hover:text-white/80 transition font-medium",
                                            children: "Over Ons"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/contact",
                                            className: "text-white hover:text-white/80 transition font-medium",
                                            children: "Contact"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 68,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                    lineNumber: 61,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: isOnCartPage ? ()=>{} : handleCartToggle,
                                    className: `hidden md:block relative transition ${isOnCartPage ? 'opacity-50 cursor-default' : 'hover:opacity-80 cursor-pointer'}`,
                                    "aria-label": "Winkelwagen",
                                    title: isOnCartPage ? 'Je bent al op de winkelwagen pagina' : 'Open winkelwagen',
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__["ShoppingCart"], {
                                            className: "h-6 w-6 text-white"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 82,
                                            columnNumber: 15
                                        }, this),
                                        itemCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute -top-2 -right-2 min-w-[20px] h-5 bg-black text-white text-xs rounded-full flex items-center justify-center font-bold px-1.5",
                                            children: itemCount
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 84,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                    lineNumber: 74,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "md:hidden flex items-center gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: isOnCartPage ? ()=>{} : handleCartToggle,
                                            className: `relative transition ${isOnCartPage ? 'opacity-50 cursor-default' : 'hover:opacity-80 cursor-pointer'}`,
                                            "aria-label": "Winkelwagen",
                                            title: isOnCartPage ? 'Je bent al op de winkelwagen pagina' : 'Open winkelwagen',
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__["ShoppingCart"], {
                                                    className: "h-6 w-6 text-white"
                                                }, void 0, false, {
                                                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 17
                                                }, this),
                                                itemCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute -top-2 -right-2 min-w-[20px] h-5 bg-black text-white text-xs rounded-full flex items-center justify-center font-bold px-1.5",
                                                    children: itemCount
                                                }, void 0, false, {
                                                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                                    lineNumber: 102,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 92,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setIsMobileMenuOpen(!isMobileMenuOpen),
                                            className: "hover:opacity-80 transition",
                                            "aria-label": "Menu",
                                            children: isMobileMenuOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                className: "h-6 w-6 text-white"
                                            }, void 0, false, {
                                                fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                                lineNumber: 113,
                                                columnNumber: 37
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                                className: "h-6 w-6 text-white"
                                            }, void 0, false, {
                                                fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                                lineNumber: 113,
                                                columnNumber: 76
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 108,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                    lineNumber: 91,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this),
                        isMobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                            className: "md:hidden pb-4 border-t border-white/20 mt-2 pt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/",
                                        className: "text-white hover:text-white/80 transition font-medium px-4 py-3 hover:bg-white/10 rounded",
                                        onClick: ()=>setIsMobileMenuOpen(false),
                                        children: "Home"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                        lineNumber: 122,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/over-ons",
                                        className: "text-white hover:text-white/80 transition font-medium px-4 py-3 hover:bg-white/10 rounded",
                                        onClick: ()=>setIsMobileMenuOpen(false),
                                        children: "Over Ons"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                        lineNumber: 125,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/contact",
                                        className: "text-white hover:text-white/80 transition font-medium px-4 py-3 hover:bg-white/10 rounded",
                                        onClick: ()=>setIsMobileMenuOpen(false),
                                        children: "Contact"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                        lineNumber: 128,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                lineNumber: 121,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                            lineNumber: 120,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            isCartOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 bg-black/20 z-[150] backdrop-blur-sm",
                        onClick: closeCart
                    }, void 0, false, {
                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                        lineNumber: 140,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed right-0 top-0 h-screen w-full max-w-md bg-white shadow-2xl z-[160] animate-slide-in-right flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between p-6 border-b border-gray-200 flex-shrink-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-medium",
                                        children: "Winkelwagen"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                        lineNumber: 146,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: closeCart,
                                        className: "p-2 hover:bg-gray-100 rounded transition",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                            className: "h-6 w-6"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                            lineNumber: 148,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                        lineNumber: 147,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                lineNumber: 145,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 overflow-hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$mini$2d$cart$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MiniCart"], {
                                    onClose: closeCart
                                }, void 0, false, {
                                    fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                    lineNumber: 152,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                                lineNumber: 151,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/kattenbak/frontend/components/layout/header.tsx",
                        lineNumber: 144,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true);
}
}),
"[project]/kattenbak/frontend/shared/cookies.config.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * COOKIES CONFIGURATION - GDPR Compliant
 * DRY: Single source voor alle cookie settings
 */ __turbopack_context__.s([
    "COOKIES_CONFIG",
    ()=>COOKIES_CONFIG
]);
const COOKIES_CONFIG = {
    // Cookie categories (GDPR required)
    CATEGORIES: {
        NECESSARY: {
            id: 'necessary',
            name: 'Noodzakelijk',
            description: 'Essentieel voor de werking van de website. Kunnen niet worden uitgeschakeld.',
            required: true,
            cookies: [
                {
                    name: 'cart',
                    purpose: 'Winkelwagen opslaan',
                    duration: '7 dagen'
                },
                {
                    name: 'session',
                    purpose: 'Sessie beheren',
                    duration: 'Sessie'
                },
                {
                    name: 'cookie_consent',
                    purpose: 'Cookie voorkeuren onthouden',
                    duration: '1 jaar'
                }
            ]
        },
        FUNCTIONAL: {
            id: 'functional',
            name: 'Functioneel',
            description: 'Zorgen voor extra functionaliteit zoals chat en taalvoorkeuren.',
            required: false,
            cookies: [
                {
                    name: 'hcaptcha',
                    purpose: 'Spam preventie (hCaptcha)',
                    duration: 'Sessie'
                },
                {
                    name: 'language',
                    purpose: 'Taalvoorkeur onthouden',
                    duration: '1 jaar'
                }
            ]
        },
        ANALYTICS: {
            id: 'analytics',
            name: 'Analytisch',
            description: 'Helpen ons begrijpen hoe bezoekers de website gebruiken.',
            required: false,
            cookies: [
                {
                    name: '_ga',
                    purpose: 'Google Analytics',
                    duration: '2 jaar'
                },
                {
                    name: '_gid',
                    purpose: 'Google Analytics',
                    duration: '24 uur'
                }
            ]
        },
        MARKETING: {
            id: 'marketing',
            name: 'Marketing',
            description: 'Gebruikt voor gepersonaliseerde advertenties.',
            required: false,
            cookies: [
                {
                    name: 'fbp',
                    purpose: 'Facebook Pixel',
                    duration: '3 maanden'
                },
                {
                    name: 'ads',
                    purpose: 'Advertentie tracking',
                    duration: '1 jaar'
                }
            ]
        }
    },
    // LocalStorage keys (DRY)
    STORAGE_KEY: 'cookie_consent',
    // Consent expiry (1 jaar)
    CONSENT_DURATION: 365 * 24 * 60 * 60 * 1000,
    // Default consent (only necessary)
    DEFAULT_CONSENT: {
        necessary: true,
        functional: false,
        analytics: false,
        marketing: false,
        timestamp: null
    }
};
}),
"[project]/kattenbak/frontend/lib/hooks/use-cookie-consent.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCookieConsent",
    ()=>useCookieConsent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$shared$2f$cookies$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/shared/cookies.config.ts [app-ssr] (ecmascript)");
"use client";
;
;
function useCookieConsent() {
    const [consent, setConsent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>({
            necessary: true,
            functional: false,
            analytics: false,
            marketing: false,
            timestamp: Date.now()
        }));
    const [showBanner, setShowBanner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoaded, setIsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // Load consent from localStorage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time truthy", 1) return;
        //TURBOPACK unreachable
        ;
        const stored = undefined;
    }, []);
    // Save consent to localStorage
    const saveConsent = (newConsent)=>{
        const updated = {
            necessary: true,
            functional: newConsent.functional ?? false,
            analytics: newConsent.analytics ?? false,
            marketing: newConsent.marketing ?? false,
            timestamp: Date.now()
        };
        setConsent(updated);
        localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$shared$2f$cookies$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COOKIES_CONFIG"].STORAGE_KEY, JSON.stringify(updated));
        setShowBanner(false);
        console.log('✅ Cookie consent saved:', updated);
    };
    // Accept all cookies
    const acceptAll = ()=>{
        setConsent({
            necessary: true,
            functional: true,
            analytics: true,
            marketing: true,
            timestamp: Date.now()
        });
        localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$shared$2f$cookies$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COOKIES_CONFIG"].STORAGE_KEY, JSON.stringify({
            necessary: true,
            functional: true,
            analytics: true,
            marketing: true,
            timestamp: Date.now()
        }));
        setShowBanner(false);
    };
    // Reject all (only necessary)
    const rejectAll = ()=>{
        setConsent({
            necessary: true,
            functional: false,
            analytics: false,
            marketing: false,
            timestamp: Date.now()
        });
        localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$shared$2f$cookies$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COOKIES_CONFIG"].STORAGE_KEY, JSON.stringify({
            necessary: true,
            functional: false,
            analytics: false,
            marketing: false,
            timestamp: Date.now()
        }));
        setShowBanner(false);
    };
    // Custom consent (from settings page)
    const updateConsent = (categories)=>{
        saveConsent(categories);
    };
    // Check if specific category is enabled
    const hasConsent = (category)=>{
        return consent[category] === true;
    };
    return {
        consent,
        showBanner,
        isLoaded,
        acceptAll,
        rejectAll,
        updateConsent,
        hasConsent
    };
}
}),
"[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CookieConsentBanner",
    ()=>CookieConsentBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cookie$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/cookie.js [app-ssr] (ecmascript) <export default as Cookie>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/settings.js [app-ssr] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
function CookieConsentBanner({ onAcceptAll, onRejectAll, onShowSettings, onClose }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed bottom-0 left-0 right-0 z-[100] animate-in slide-in-from-bottom duration-300",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white border-t-2 border-gray-200 shadow-lg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col md:flex-row items-start md:items-center gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start gap-3 flex-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-10 h-10 bg-gray-100 flex items-center justify-center flex-shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cookie$3e$__["Cookie"], {
                                        className: "h-5 w-5 text-gray-700"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                        lineNumber: 33,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                    lineNumber: 32,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-semibold text-gray-900 mb-1.5 text-sm",
                                            children: "Deze website gebruikt cookies"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                            lineNumber: 37,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-600 leading-relaxed mb-2",
                                            children: [
                                                "Wij gebruiken ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: "noodzakelijke cookies"
                                                }, void 0, false, {
                                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                                    lineNumber: 41,
                                                    columnNumber: 33
                                                }, this),
                                                " voor de werking van de website. Met je toestemming gebruiken we ook ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: "functionele cookies"
                                                }, void 0, false, {
                                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                                    lineNumber: 42,
                                                    columnNumber: 55
                                                }, this),
                                                " (zoals hCaptcha voor spam-preventie). Analytische en marketing cookies worden alleen gebruikt na jouw expliciete toestemming."
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                            lineNumber: 40,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-500",
                                            children: [
                                                "Meer informatie in ons",
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/privacy-policy",
                                                    className: "text-brand hover:underline",
                                                    children: "privacybeleid"
                                                }, void 0, false, {
                                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 19
                                                }, this),
                                                " ",
                                                "en",
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/cookie-policy",
                                                    className: "text-brand hover:underline",
                                                    children: "cookiebeleid"
                                                }, void 0, false, {
                                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                                    lineNumber: 54,
                                                    columnNumber: 19
                                                }, this),
                                                "."
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                            lineNumber: 45,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                    lineNumber: 36,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                            lineNumber: 31,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col sm:flex-row gap-2 w-full md:w-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onRejectAll,
                                    className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 transition-colors rounded-none whitespace-nowrap",
                                    children: "Alleen noodzakelijk"
                                }, void 0, false, {
                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                    lineNumber: 67,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onShowSettings,
                                    className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 transition-colors rounded-none whitespace-nowrap flex items-center justify-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                            lineNumber: 78,
                                            columnNumber: 17
                                        }, this),
                                        "Instellingen"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                    lineNumber: 74,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onAcceptAll,
                                    className: "px-4 py-2 text-sm font-bold text-white bg-accent hover:bg-accent-dark transition-colors rounded-none whitespace-nowrap",
                                    children: "Alles accepteren"
                                }, void 0, false, {
                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                                    lineNumber: 82,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                            lineNumber: 66,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                    lineNumber: 29,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
                lineNumber: 28,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
            lineNumber: 27,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
}),
"[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CookieSettingsModal",
    ()=>CookieSettingsModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cookie$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/cookie.js [app-ssr] (ecmascript) <export default as Cookie>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/shield.js [app-ssr] (ecmascript) <export default as Shield>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$no$2d$axes$2d$column$2d$increasing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/chart-no-axes-column-increasing.js [app-ssr] (ecmascript) <export default as BarChart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$target$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Target$3e$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/lucide-react/dist/esm/icons/target.js [app-ssr] (ecmascript) <export default as Target>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$shared$2f$cookies$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/shared/cookies.config.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/theme-colors.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
// DRY: Icon mapping voor categorieën
const CATEGORY_ICONS = {
    NECESSARY: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__["Shield"],
    FUNCTIONAL: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cookie$3e$__["Cookie"],
    ANALYTICS: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$no$2d$axes$2d$column$2d$increasing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart$3e$__["BarChart"],
    MARKETING: __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$target$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Target$3e$__["Target"]
};
function CookieSettingsModal({ currentConsent, onSave, onClose }) {
    const [consent, setConsent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(currentConsent);
    const handleToggle = (category)=>{
        // Necessary cookies cannot be disabled
        if (category === 'necessary') return;
        setConsent((prev)=>({
                ...prev,
                [category]: !prev[category]
            }));
    };
    const handleSave = ()=>{
        onSave(consent);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[200] flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-black/50 backdrop-blur-sm",
                onClick: onClose
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative bg-white rounded-xl sm:rounded-2xl shadow-2xl max-w-xl w-full max-h-[85vh] sm:max-h-[80vh] overflow-hidden animate-in zoom-in-95 duration-300",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `sticky top-0 ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].navbar.bg} border-b border-gray-700/20 px-4 py-3 flex items-center justify-between`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cookie$3e$__["Cookie"], {
                                        className: "h-6 w-6 text-white"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                        lineNumber: 61,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-lg font-semibold text-white",
                                        children: "Cookie instellingen"
                                    }, void 0, false, {
                                        fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                        lineNumber: 62,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "text-white/80 hover:text-white transition-colors p-1.5 hover:bg-white/10 rounded-full",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    className: "h-5 w-5"
                                }, void 0, false, {
                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                lineNumber: 64,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-y-auto max-h-[calc(85vh-140px)] px-4 py-4 space-y-3",
                        children: Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$shared$2f$cookies$2e$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COOKIES_CONFIG"].CATEGORIES).map(([categoryKey, category])=>{
                            const consentKey = category.id;
                            const isEnabled = consent[consentKey];
                            const isRequired = category.required;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-start justify-between gap-3 mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 mb-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "font-semibold text-sm text-gray-900",
                                                            children: category.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                                            lineNumber: 87,
                                                            columnNumber: 23
                                                        }, this),
                                                        isRequired && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: `text-xs ${__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$theme$2d$colors$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPONENT_COLORS"].navbar.bg} text-white px-2 py-0.5 rounded-full`,
                                                            children: "Verplicht"
                                                        }, void 0, false, {
                                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                                            lineNumber: 89,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                                    lineNumber: 86,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-600",
                                                    children: category.description
                                                }, void 0, false, {
                                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                                    lineNumber: 94,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                            lineNumber: 85,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleToggle(consentKey),
                                            disabled: isRequired,
                                            className: `relative inline-flex h-5 w-9 items-center rounded-full transition-colors flex-shrink-0 ${isRequired ? 'bg-brand cursor-not-allowed opacity-50' : isEnabled ? 'bg-black' : 'bg-gray-200'}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${isEnabled ? 'translate-x-5' : 'translate-x-0.5'}`
                                            }, void 0, false, {
                                                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                                lineNumber: 109,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                            lineNumber: 98,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                    lineNumber: 84,
                                    columnNumber: 17
                                }, this)
                            }, categoryKey, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                lineNumber: 80,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "sticky bottom-0 bg-gray-50 border-t border-gray-200 px-4 py-3 flex flex-col sm:flex-row gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                fullWidth: true,
                                onClick: onClose,
                                size: "sm",
                                className: "border-2 border-gray-900",
                                children: "Annuleren"
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                lineNumber: 123,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "cta",
                                fullWidth: true,
                                onClick: handleSave,
                                size: "sm",
                                children: "Voorkeuren opslaan"
                            }, void 0, false, {
                                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                                lineNumber: 132,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
}
}),
"[project]/kattenbak/frontend/components/ui/cookie-consent-manager.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CookieConsentManager",
    ()=>CookieConsentManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$hooks$2f$use$2d$cookie$2d$consent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/lib/hooks/use-cookie-consent.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$cookie$2d$consent$2d$banner$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/components/ui/cookie-consent-banner.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$cookie$2d$settings$2d$modal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/frontend/components/ui/cookie-settings-modal.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function CookieConsentManager() {
    const [showSettings, setShowSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const { showBanner, isLoaded, consent, acceptAll, rejectAll, updateConsent } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$lib$2f$hooks$2f$use$2d$cookie$2d$consent$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCookieConsent"])();
    // Don't render until loaded (avoid hydration mismatch)
    if (!isLoaded) return null;
    // Don't show anything if consent already given
    if (!showBanner && !showSettings) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            showBanner && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$cookie$2d$consent$2d$banner$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CookieConsentBanner"], {
                onAcceptAll: acceptAll,
                onRejectAll: rejectAll,
                onShowSettings: ()=>setShowSettings(true),
                onClose: rejectAll
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-manager.tsx",
                lineNumber: 32,
                columnNumber: 9
            }, this),
            showSettings && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$frontend$2f$components$2f$ui$2f$cookie$2d$settings$2d$modal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CookieSettingsModal"], {
                currentConsent: consent,
                onSave: (newConsent)=>{
                    updateConsent(newConsent);
                    setShowSettings(false);
                },
                onClose: ()=>setShowSettings(false)
            }, void 0, false, {
                fileName: "[project]/kattenbak/frontend/components/ui/cookie-consent-manager.tsx",
                lineNumber: 41,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b839d331._.js.map