(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/kattenbak_frontend_d5e5d7f1._.js",
  "static/chunks/9aa6f_lucide-react_dist_esm_icons_bc8eb754._.js"
],
    source: "dynamic"
});
