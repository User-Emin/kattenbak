(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__6abe748d._.css",
  "static/chunks/kattenbak_frontend_024c3e3b._.js",
  "static/chunks/9aa6f_2d13262a._.js"
],
    source: "dynamic"
});
