(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_34835757._.js",
  "static/chunks/9aa6f_next_dist_compiled_react-dom_154fbbde._.js",
  "static/chunks/9aa6f_next_dist_compiled_react-server-dom-turbopack_87af497e._.js",
  "static/chunks/9aa6f_next_dist_compiled_next-devtools_index_7d82befa.js",
  "static/chunks/9aa6f_next_dist_compiled_80aa7135._.js",
  "static/chunks/9aa6f_next_dist_client_c2634a94._.js",
  "static/chunks/9aa6f_next_dist_2273ffc3._.js",
  "static/chunks/9aa6f_@swc_helpers_cjs_c2a12935._.js"
],
    source: "entry"
});
