module.exports=[64558,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_cart_page_actions_d92752df.js.map