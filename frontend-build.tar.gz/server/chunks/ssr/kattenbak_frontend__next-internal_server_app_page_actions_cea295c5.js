module.exports=[49365,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_page_actions_cea295c5.js.map