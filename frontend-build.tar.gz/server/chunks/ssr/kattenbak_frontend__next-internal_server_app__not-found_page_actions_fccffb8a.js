module.exports=[97061,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app__not-found_page_actions_fccffb8a.js.map