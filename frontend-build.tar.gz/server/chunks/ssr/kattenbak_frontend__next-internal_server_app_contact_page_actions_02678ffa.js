module.exports=[90428,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_contact_page_actions_02678ffa.js.map