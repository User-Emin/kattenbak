module.exports=[75153,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_checkout_page_actions_96a19207.js.map