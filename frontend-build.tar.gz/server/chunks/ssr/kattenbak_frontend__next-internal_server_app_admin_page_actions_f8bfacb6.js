module.exports=[33744,(a,b,c)=>{}];

//# sourceMappingURL=kattenbak_frontend__next-internal_server_app_admin_page_actions_f8bfacb6.js.map