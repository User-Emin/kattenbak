module.exports=[14213,(a,b,c)=>{}];

//# sourceMappingURL=918b8__next-internal_server_app_orders_%5BorderId%5D_return_page_actions_42cc56d7.js.map