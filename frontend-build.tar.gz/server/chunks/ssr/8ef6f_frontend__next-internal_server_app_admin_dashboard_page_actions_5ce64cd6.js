module.exports=[95007,(a,b,c)=>{}];

//# sourceMappingURL=8ef6f_frontend__next-internal_server_app_admin_dashboard_page_actions_5ce64cd6.js.map