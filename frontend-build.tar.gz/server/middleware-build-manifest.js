globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c5dc6315bd4c96fc.js",
    "static/chunks/33794d9bea54be2e.js",
    "static/chunks/027d70b21784ddce.js",
    "static/chunks/84122cc92ba1d848.js",
    "static/chunks/3b497e6535bb8056.js",
    "static/chunks/turbopack-6968ace9d2b73345.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];