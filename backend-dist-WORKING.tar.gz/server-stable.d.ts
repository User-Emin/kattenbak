import type { Application } from 'express';
declare const app: Application;
export default app;
//# sourceMappingURL=server-stable.d.ts.map