import { Request, Response, NextFunction } from 'express';
/**
 * Webhook Controller
 * Handles external webhooks (Mollie, MyParcel)
 */
export declare class WebhookController {
    /**
     * Handle Mollie webhook
     * POST /api/v1/webhooks/mollie
     */
    static handleMollieWebhook(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Handle MyParcel webhook
     * POST /api/v1/webhooks/myparcel
     */
    static handleMyParcelWebhook(req: Request, res: Response, next: NextFunction): Promise<void>;
}
//# sourceMappingURL=webhook.controller.d.ts.map