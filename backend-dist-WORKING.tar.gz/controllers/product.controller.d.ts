import { Request, Response, NextFunction } from 'express';
/**
 * Product Controller
 * Handles HTTP requests for products
 */
export declare class ProductController {
    /**
     * Get all products with filters and pagination
     * GET /api/v1/products
     */
    static getAllProducts(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Get product by ID
     * GET /api/v1/products/:id
     */
    static getProductById(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Get product by slug
     * GET /api/v1/products/slug/:slug
     */
    static getProductBySlug(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Get featured products
     * GET /api/v1/products/featured
     */
    static getFeaturedProducts(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Search products
     * GET /api/v1/products/search?q=query
     */
    static searchProducts(req: Request, res: Response, next: NextFunction): Promise<void>;
}
//# sourceMappingURL=product.controller.d.ts.map