"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookController = void 0;
const mollie_service_1 = require("../services/mollie.service");
const logger_config_1 = require("../config/logger.config");
const response_util_1 = require("../utils/response.util");
/**
 * Webhook Controller
 * Handles external webhooks (Mollie, MyParcel)
 */
class WebhookController {
    /**
     * Handle Mollie webhook
     * POST /api/v1/webhooks/mollie
     */
    static async handleMollieWebhook(req, res, next) {
        try {
            const { id: mollieId } = req.body;
            if (!mollieId) {
                return res.status(400).json({
                    success: false,
                    message: 'Missing payment ID',
                });
            }
            logger_config_1.logger.info(`Mollie webhook received: ${mollieId}`);
            // Process webhook asynchronously
            mollie_service_1.MollieService.handleWebhook(mollieId).catch((error) => {
                logger_config_1.logger.error('Mollie webhook processing failed:', error);
            });
            // Respond immediately to Mollie
            res.status(200).json((0, response_util_1.successResponse)({ received: true }));
        }
        catch (error) {
            next(error);
        }
    }
    /**
     * Handle MyParcel webhook
     * POST /api/v1/webhooks/myparcel
     */
    static async handleMyParcelWebhook(req, res, next) {
        try {
            const webhookData = req.body;
            logger_config_1.logger.info('MyParcel webhook received:', webhookData);
            // TODO: Implement MyParcel webhook processing
            // For now, just acknowledge receipt
            res.status(200).json((0, response_util_1.successResponse)({ received: true }));
        }
        catch (error) {
            next(error);
        }
    }
}
exports.WebhookController = WebhookController;
//# sourceMappingURL=webhook.controller.js.map