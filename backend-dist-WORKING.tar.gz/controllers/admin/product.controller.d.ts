import { Request, Response, NextFunction } from 'express';
/**
 * Admin Product Controller
 * Full CRUD operations for products
 */
export declare class AdminProductController {
    /**
     * Get all products (including inactive)
     * GET /api/v1/admin/products
     */
    static getAllProducts(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Get product by ID
     * GET /api/v1/admin/products/:id
     */
    static getProductById(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Create product
     * POST /api/v1/admin/products
     */
    static createProduct(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Update product
     * PUT /api/v1/admin/products/:id
     */
    static updateProduct(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Delete product (soft delete)
     * DELETE /api/v1/admin/products/:id
     */
    static deleteProduct(req: Request, res: Response, next: NextFunction): Promise<void>;
}
//# sourceMappingURL=product.controller.d.ts.map