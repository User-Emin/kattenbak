"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminAuthController = void 0;
const auth_util_1 = require("../../utils/auth.util");
const response_util_1 = require("../../utils/response.util");
const errors_util_1 = require("../../utils/errors.util");
const logger_config_1 = require("../../config/logger.config");
const env_config_1 = require("../../config/env.config");
/**
 * Admin Auth Controller - DRY & Database-free version
 * Works without Prisma/Database for development
 */
// Mock admin user from env
const MOCK_ADMIN = {
    id: 'admin-1',
    email: env_config_1.env.ADMIN_EMAIL,
    password: env_config_1.env.ADMIN_PASSWORD,
    role: 'ADMIN',
    firstName: 'Admin',
    lastName: 'User',
};
class AdminAuthController {
    /**
     * Admin login - Database-free
     * POST /api/v1/admin/auth/login
     */
    static async login(req, res, next) {
        try {
            const { email, password } = req.body;
            // Simple comparison for development
            if (email !== MOCK_ADMIN.email || password !== MOCK_ADMIN.password) {
                throw new errors_util_1.UnauthorizedError('Invalid credentials');
            }
            // Generate JWT token
            const token = (0, auth_util_1.generateToken)({
                id: MOCK_ADMIN.id,
                email: MOCK_ADMIN.email,
                role: MOCK_ADMIN.role,
            });
            logger_config_1.logger.info(`✅ Admin login successful: ${email}`);
            // DRY: Correct successResponse usage
            (0, response_util_1.successResponse)(res, {
                token,
                user: {
                    id: MOCK_ADMIN.id,
                    email: MOCK_ADMIN.email,
                    role: MOCK_ADMIN.role,
                    firstName: MOCK_ADMIN.firstName,
                    lastName: MOCK_ADMIN.lastName,
                },
            });
        }
        catch (error) {
            logger_config_1.logger.error('â Admin login failed:', error);
            next(error);
        }
    }
}
exports.AdminAuthController = AdminAuthController;
//# sourceMappingURL=auth.controller.js.map