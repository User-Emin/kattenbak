"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductController = void 0;
const product_service_1 = require("../services/product.service");
const response_util_1 = require("../utils/response.util");
/**
 * Product Controller
 * Handles HTTP requests for products
 */
class ProductController {
    /**
     * Get all products with filters and pagination
     * GET /api/v1/products
     */
    static async getAllProducts(req, res, next) {
        try {
            const { page = 1, pageSize = 12, categoryId, isFeatured, inStock, minPrice, maxPrice, search, sortBy = 'createdAt', sortOrder = 'desc', } = req.query;
            const filters = {
                categoryId: categoryId,
                isFeatured: isFeatured === 'true',
                inStock: inStock === 'true',
                minPrice: minPrice ? parseFloat(minPrice) : undefined,
                maxPrice: maxPrice ? parseFloat(maxPrice) : undefined,
                search: search,
            };
            const pagination = {
                page: parseInt(page, 10),
                pageSize: parseInt(pageSize, 10),
                sortBy: sortBy,
                sortOrder: sortOrder,
            };
            const { products, total } = await product_service_1.ProductService.getAllProducts(filters, pagination);
            res.json((0, response_util_1.successResponse)({
                products,
                pagination: {
                    page: pagination.page,
                    pageSize: pagination.pageSize,
                    total,
                    totalPages: Math.ceil(total / pagination.pageSize),
                },
            }));
        }
        catch (error) {
            next(error);
        }
    }
    /**
     * Get product by ID
     * GET /api/v1/products/:id
     */
    static async getProductById(req, res, next) {
        try {
            const { id } = req.params;
            const product = await product_service_1.ProductService.getProductById(id);
            res.json((0, response_util_1.successResponse)(product));
        }
        catch (error) {
            next(error);
        }
    }
    /**
     * Get product by slug
     * GET /api/v1/products/slug/:slug
     */
    static async getProductBySlug(req, res, next) {
        try {
            const { slug } = req.params;
            const product = await product_service_1.ProductService.getProductBySlug(slug);
            res.json((0, response_util_1.successResponse)(product));
        }
        catch (error) {
            next(error);
        }
    }
    /**
     * Get featured products
     * GET /api/v1/products/featured
     */
    static async getFeaturedProducts(req, res, next) {
        try {
            const limit = req.query.limit ? parseInt(req.query.limit, 10) : 8;
            const products = await product_service_1.ProductService.getFeaturedProducts(limit);
            res.json((0, response_util_1.successResponse)(products));
        }
        catch (error) {
            next(error);
        }
    }
    /**
     * Search products
     * GET /api/v1/products/search?q=query
     */
    static async searchProducts(req, res, next) {
        try {
            const query = req.query.q;
            const limit = req.query.limit ? parseInt(req.query.limit, 10) : 10;
            if (!query) {
                return res.json((0, response_util_1.successResponse)([]));
            }
            const products = await product_service_1.ProductService.searchProducts(query, limit);
            res.json((0, response_util_1.successResponse)(products));
        }
        catch (error) {
            next(error);
        }
    }
}
exports.ProductController = ProductController;
//# sourceMappingURL=product.controller.js.map