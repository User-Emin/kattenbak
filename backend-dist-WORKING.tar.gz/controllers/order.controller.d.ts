import { Request, Response, NextFunction } from 'express';
/**
 * Order Controller
 * Handles HTTP requests for orders
 */
export declare class OrderController {
    /**
     * Create new order and initiate payment
     * POST /api/v1/orders
     */
    static createOrder(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Get order by ID
     * GET /api/v1/orders/:id
     */
    static getOrderById(req: Request, res: Response, next: NextFunction): Promise<void>;
}
//# sourceMappingURL=order.controller.d.ts.map