"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderController = void 0;
const order_service_1 = require("../services/order.service");
const mollie_service_1 = require("../services/mollie.service");
const response_util_1 = require("../utils/response.util");
const env_config_1 = require("../config/env.config");
/**
 * Order Controller
 * Handles HTTP requests for orders
 */
class OrderController {
    /**
     * Create new order and initiate payment
     * POST /api/v1/orders
     */
    static async createOrder(req, res, next) {
        try {
            const { paymentMethod, ...orderData } = req.body;
            // Create order
            const order = await order_service_1.OrderService.createOrder(orderData);
            // Create Mollie payment with optional method
            const redirectUrl = `${env_config_1.env.FRONTEND_URL}/order/${order.id}/payment`;
            const payment = await mollie_service_1.MollieService.createPayment(order.id, order.total, `Order ${order.orderNumber}`, redirectUrl, paymentMethod // Pass payment method from frontend
            );
            res.status(201).json((0, response_util_1.successResponse)({
                order,
                payment: {
                    id: payment.id,
                    checkoutUrl: payment.checkoutUrl,
                },
            }));
        }
        catch (error) {
            next(error);
        }
    }
    /**
     * Get order by ID
     * GET /api/v1/orders/:id
     */
    static async getOrderById(req, res, next) {
        try {
            const { id } = req.params;
            const order = await order_service_1.OrderService.getOrderById(id);
            res.json((0, response_util_1.successResponse)(order));
        }
        catch (error) {
            next(error);
        }
    }
}
exports.OrderController = OrderController;
//# sourceMappingURL=order.controller.js.map