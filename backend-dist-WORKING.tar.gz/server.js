"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const env_config_1 = require("./config/env.config");
const database_config_1 = require("./config/database.config");
const logger_config_1 = require("./config/logger.config");
const logger_middleware_1 = require("./middleware/logger.middleware");
const error_middleware_1 = require("./middleware/error.middleware");
const ratelimit_middleware_1 = require("./middleware/ratelimit.middleware");
/**
 * Enterprise Express Server
 * Production-ready with security, logging, and error handling
 */
class Server {
    app;
    constructor() {
        this.app = (0, express_1.default)();
        this.validateEnvironment();
        this.initializeMiddleware();
        this.initializeRoutes().then(() => {
            this.initializeErrorHandling();
        });
    }
    /**
     * Validate environment configuration
     */
    validateEnvironment() {
        try {
            env_config_1.env.validate();
        }
        catch (error) {
            logger_config_1.logger.error('Environment validation failed:', error);
            process.exit(1);
        }
    }
    /**
     * Initialize middleware
     */
    initializeMiddleware() {
        // Security middleware
        this.app.use((0, helmet_1.default)({
            contentSecurityPolicy: env_config_1.env.IS_PRODUCTION,
            crossOriginEmbedderPolicy: env_config_1.env.IS_PRODUCTION,
        }));
        // CORS
        this.app.use((0, cors_1.default)({
            origin: env_config_1.env.CORS_ORIGINS,
            credentials: true,
        }));
        // Body parsing
        this.app.use(express_1.default.json({ limit: '10mb' }));
        this.app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
        // Request logging
        this.app.use(logger_middleware_1.requestLogger);
        // Rate limiting
        this.app.use('/api/', ratelimit_middleware_1.apiRateLimiter);
        logger_config_1.logger.info('✅ Middleware initialized');
    }
    /**
     * Initialize routes
     */
    async initializeRoutes() {
        // Health check
        this.app.get('/health', (req, res) => {
            res.json({
                success: true,
                message: 'Healthy',
                environment: env_config_1.env.NODE_ENV,
                mollie: env_config_1.env.MOLLIE_API_KEY.startsWith('live_') ? 'LIVE' : 'TEST',
                timestamp: new Date().toISOString(),
            });
        });
        // API v1 routes
        this.app.get('/api/v1/health', (req, res) => {
            res.json({
                success: true,
                message: 'API v1 is healthy',
                version: '1.0.0',
            });
        });
        // Load simple product routes (no database needed)
        const productRoutes = (await Promise.resolve().then(() => __importStar(require('./routes/product.routes.simple')))).default;
        this.app.use('/api/v1/products', productRoutes);
        // Returns routes (public - customer facing)
        const returnsRoutes = (await Promise.resolve().then(() => __importStar(require('./routes/returns.routes')))).default;
        this.app.use('/api/v1/returns', returnsRoutes);
        // Admin routes - IMPORTANT for admin panel
        const adminRoutes = (await Promise.resolve().then(() => __importStar(require('./routes/admin/index')))).default;
        this.app.use('/api/v1/admin', adminRoutes);
        // Webhook routes
        const webhookRoutes = (await Promise.resolve().then(() => __importStar(require('./routes/webhook.routes')))).default;
        this.app.use('/api/v1/webhooks', webhookRoutes);
        logger_config_1.logger.info('✅ Routes initialized (admin + products + returns + webhooks)');
    }
    /**
     * Initialize error handling
     */
    initializeErrorHandling() {
        // 404 handler
        this.app.use(error_middleware_1.notFoundHandler);
        // Global error handler
        this.app.use(error_middleware_1.errorHandler);
        logger_config_1.logger.info('✅ Error handling initialized');
    }
    /**
     * Start server
     */
    async start() {
        try {
            // Try database connection (but don't fail if not available)
            try {
                const dbConnected = await database_config_1.DatabaseClient.testConnection();
                if (dbConnected) {
                    logger_config_1.logger.info('✅ Database connected');
                }
            }
            catch (error) {
                logger_config_1.logger.warn('⚠️ Database not available, using mock data');
            }
            // Start listening
            this.app.listen(env_config_1.env.BACKEND_PORT, () => {
                logger_config_1.logger.info('='.repeat(50));
                logger_config_1.logger.info('🚀 KATTENBAK WEBSHOP API SERVER');
                logger_config_1.logger.info('='.repeat(50));
                logger_config_1.logger.info(`Environment: ${env_config_1.env.NODE_ENV}`);
                logger_config_1.logger.info(`Server: ${env_config_1.env.BACKEND_URL}`);
                logger_config_1.logger.info(`Port: ${env_config_1.env.BACKEND_PORT}`);
                logger_config_1.logger.info(`Redis: ${env_config_1.env.REDIS_HOST}:${env_config_1.env.REDIS_PORT}`);
                logger_config_1.logger.info(`Mollie: ${env_config_1.env.MOLLIE_API_KEY.substring(0, 15)}...`);
                logger_config_1.logger.info('='.repeat(50));
            });
        }
        catch (error) {
            logger_config_1.logger.error('Failed to start server:', error);
            process.exit(1);
        }
    }
    /**
     * Graceful shutdown
     */
    async shutdown() {
        logger_config_1.logger.info('Shutting down server...');
        process.exit(0);
    }
}
// Start server
const server = new Server();
server.start();
// Handle shutdown signals
process.on('SIGTERM', () => server.shutdown());
process.on('SIGINT', () => server.shutdown());
exports.default = server;
//# sourceMappingURL=server.js.map