/**
 * 50+ REAL TEST QUESTIONS
 * For MRR and accuracy evaluation
 */
export declare const TEST_QUESTIONS: {
    id: number;
    question: string;
    expected_answer_contains: string[];
    category: string;
    importance: string;
}[];
export declare const EXPECTED_MRR = 0.85;
export declare const EXPECTED_P1 = 0.8;
export declare const EXPECTED_P3 = 0.95;
//# sourceMappingURL=rag-test-questions.d.ts.map