"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const order_controller_1 = require("../controllers/order.controller");
const validation_middleware_1 = require("../middleware/validation.middleware");
const zod_1 = require("zod");
const router = (0, express_1.Router)();
// Validation schemas
const createOrderSchema = zod_1.z.object({
    body: zod_1.z.object({
        items: zod_1.z.array(zod_1.z.object({
            productId: zod_1.z.string().cuid('Invalid product ID'),
            quantity: zod_1.z.number().int().positive('Quantity must be positive'),
        })).min(1, 'Order must have at least one item'),
        customerEmail: zod_1.z.string().email('Invalid email'),
        customerPhone: zod_1.z.string().optional(),
        shippingAddress: zod_1.z.object({
            firstName: zod_1.z.string().min(1, 'First name is required'),
            lastName: zod_1.z.string().min(1, 'Last name is required'),
            street: zod_1.z.string().min(1, 'Street is required'),
            houseNumber: zod_1.z.string().min(1, 'House number is required'),
            addition: zod_1.z.string().optional(),
            postalCode: zod_1.z.string().min(1, 'Postal code is required'),
            city: zod_1.z.string().min(1, 'City is required'),
            country: zod_1.z.string().default('NL'),
            phone: zod_1.z.string().optional(),
        }),
        billingAddress: zod_1.z.object({
            firstName: zod_1.z.string().min(1, 'First name is required'),
            lastName: zod_1.z.string().min(1, 'Last name is required'),
            street: zod_1.z.string().min(1, 'Street is required'),
            houseNumber: zod_1.z.string().min(1, 'House number is required'),
            addition: zod_1.z.string().optional(),
            postalCode: zod_1.z.string().min(1, 'Postal code is required'),
            city: zod_1.z.string().min(1, 'City is required'),
            country: zod_1.z.string().default('NL'),
            phone: zod_1.z.string().optional(),
        }).optional(),
        customerNotes: zod_1.z.string().optional(),
    }),
});
const orderIdSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().cuid('Invalid order ID'),
    }),
});
// Public routes
router.post('/', (0, validation_middleware_1.validateRequest)(createOrderSchema), order_controller_1.OrderController.createOrder);
router.get('/:id', (0, validation_middleware_1.validateRequest)(orderIdSchema), order_controller_1.OrderController.getOrderById);
exports.default = router;
//# sourceMappingURL=order.routes.js.map