"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const image_service_1 = require("../services/image.service");
const router = (0, express_1.Router)();
/**
 * Upload Single Image
 * POST /api/v1/upload/image
 * Returns: WebP optimized images (thumbnail, medium, large)
 */
router.post('/image', image_service_1.upload.single('file'), async (req, res, next) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                error: 'No file uploaded',
            });
        }
        // Validate dimensions for images
        if (req.file.mimetype.startsWith('image/')) {
            const isValid = await (0, image_service_1.validateImageDimensions)(req.file.path);
            if (!isValid) {
                return res.status(400).json({
                    success: false,
                    error: 'Image must be at least 200x200 pixels',
                });
            }
            // Process image - convert to WebP
            const imageUrls = await (0, image_service_1.processImage)(req.file.path, req.file.filename);
            return res.json({
                success: true,
                data: {
                    message: 'Image uploaded and optimized successfully',
                    urls: imageUrls,
                },
            });
        }
        // For videos - just return the path
        const videoUrl = `/uploads/${req.file.filename}`;
        return res.json({
            success: true,
            data: {
                message: 'Video uploaded successfully',
                url: videoUrl,
            },
        });
    }
    catch (error) {
        console.error('Upload error:', error);
        return res.status(500).json({
            success: false,
            error: error.message || 'Upload failed',
        });
    }
});
/**
 * Upload Multiple Images
 * POST /api/v1/upload/images
 * Max 5 images
 */
router.post('/images', image_service_1.upload.array('files', 5), async (req, res, next) => {
    try {
        if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'No files uploaded',
            });
        }
        const processedImages = await Promise.all(req.files.map(async (file) => {
            if (file.mimetype.startsWith('image/')) {
                const isValid = await (0, image_service_1.validateImageDimensions)(file.path);
                if (!isValid) {
                    throw new Error(`Image ${file.originalname} must be at least 200x200 pixels`);
                }
                return (0, image_service_1.processImage)(file.path, file.filename);
            }
            // Video
            return { url: `/uploads/${file.filename}` };
        }));
        return res.json({
            success: true,
            data: {
                message: `${processedImages.length} files uploaded successfully`,
                files: processedImages,
            },
        });
    }
    catch (error) {
        console.error('Multiple upload error:', error);
        return res.status(500).json({
            success: false,
            error: error.message || 'Upload failed',
        });
    }
});
exports.default = router;
//# sourceMappingURL=upload.routes.js.map