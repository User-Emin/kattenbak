"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const product_controller_1 = require("../controllers/product.controller");
const validation_middleware_1 = require("../middleware/validation.middleware");
const zod_1 = require("zod");
const router = (0, express_1.Router)();
// Validation schemas
const getProductsSchema = zod_1.z.object({
    query: zod_1.z.object({
        page: zod_1.z.string().optional().transform(val => val ? parseInt(val, 10) : 1),
        pageSize: zod_1.z.string().optional().transform(val => val ? parseInt(val, 10) : 12),
        categoryId: zod_1.z.string().optional(),
        isFeatured: zod_1.z.string().optional().transform(val => val === 'true'),
        inStock: zod_1.z.string().optional().transform(val => val === 'true'),
        minPrice: zod_1.z.string().optional().transform(val => val ? parseFloat(val) : undefined),
        maxPrice: zod_1.z.string().optional().transform(val => val ? parseFloat(val) : undefined),
        search: zod_1.z.string().optional(),
        sortBy: zod_1.z.enum(['name', 'price', 'createdAt', 'stock']).optional(),
        sortOrder: zod_1.z.enum(['asc', 'desc']).optional(),
    }),
});
const productIdSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().cuid('Invalid product ID'),
    }),
});
const productSlugSchema = zod_1.z.object({
    params: zod_1.z.object({
        slug: zod_1.z.string().min(1, 'Slug is required'),
    }),
});
// Public routes
router.get('/', (0, validation_middleware_1.validateRequest)(getProductsSchema), product_controller_1.ProductController.getAllProducts);
router.get('/featured', product_controller_1.ProductController.getFeaturedProducts);
router.get('/search', product_controller_1.ProductController.searchProducts);
router.get('/slug/:slug', (0, validation_middleware_1.validateRequest)(productSlugSchema), product_controller_1.ProductController.getProductBySlug);
router.get('/:id', (0, validation_middleware_1.validateRequest)(productIdSchema), product_controller_1.ProductController.getProductById);
exports.default = router;
//# sourceMappingURL=product.routes.js.map