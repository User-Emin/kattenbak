"use strict";
/**
 * RAG API ROUTES
 * No hCaptcha - security via rate limiting + input validation
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const claude_direct_service_1 = require("../services/rag/claude-direct.service");
const rag_security_middleware_1 = require("../middleware/rag-security.middleware");
const router = (0, express_1.Router)();
/**
 * POST /api/v1/rag/chat
 * Ask question using RAG (no hCaptcha required)
 */
router.post('/chat', rag_security_middleware_1.RAGSecurityMiddleware.checkSecurity, async (req, res) => {
    try {
        const sanitizedQuery = req.body.sanitized_query;
        if (!sanitizedQuery || sanitizedQuery.length < 3) {
            return res.status(400).json({
                success: false,
                error: 'Vraag is te kort. Stel een volledige vraag.'
            });
        }
        // Claude Direct API (no SDK dependency)
        const response = await claude_direct_service_1.ClaudeDirectService.answerQuestion(sanitizedQuery);
        // Update log with response
        const latency = response.latency_ms;
        res.json({
            success: true,
            data: {
                answer: response.answer,
                latency_ms: latency,
                model: response.model,
                sources_count: response.sources.length
            }
        });
    }
    catch (err) {
        console.error('RAG chat error:', err.message);
        res.status(500).json({
            success: false,
            error: 'Er ging iets mis bij het verwerken van je vraag. Probeer het opnieuw.'
        });
    }
});
/**
 * GET /api/v1/rag/health
 * Check RAG system health
 */
router.get('/health', async (req, res) => {
    try {
        const { VectorStoreService } = require('../services/rag/vector-store.service');
        const health = await claude_direct_service_1.ClaudeDirectService.healthCheck();
        const docCount = VectorStoreService.getCount();
        res.json({
            success: true,
            data: {
                status: health.claude ? 'healthy' : 'degraded',
                storage: 'in-memory',
                documents_loaded: docCount,
                model: 'claude-3-5-haiku-20241022',
                embeddings_model: 'intfloat/multilingual-e5-base',
                backends: health
            }
        });
    }
    catch (err) {
        res.status(500).json({
            success: false,
            error: 'RAG system unhealthy',
            details: err.message
        });
    }
});
exports.default = router;
//# sourceMappingURL=rag.routes.js.map