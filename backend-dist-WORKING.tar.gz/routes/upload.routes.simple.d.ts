declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=upload.routes.simple.d.ts.map