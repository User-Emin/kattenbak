"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const fs_1 = require("fs");
const router = (0, express_1.Router)();
/**
 * SIMPLE FILE UPLOAD - ZONDER SHARP
 * Voor video's en afbeeldingen zonder conversie
 * Team Sparring: Defensive - werkt altijd, geen dependencies
 */
const UPLOAD_DIR = path_1.default.join(process.cwd(), 'public', 'uploads');
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
// Ensure upload directory exists
async function ensureUploadDir() {
    try {
        await fs_1.promises.access(UPLOAD_DIR);
    }
    catch {
        await fs_1.promises.mkdir(UPLOAD_DIR, { recursive: true });
        console.log('✅ Created upload directory:', UPLOAD_DIR);
    }
}
// Multer configuration - simple storage
const storage = multer_1.default.diskStorage({
    destination: async (req, file, cb) => {
        await ensureUploadDir();
        cb(null, UPLOAD_DIR);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
        const ext = path_1.default.extname(file.originalname);
        const sanitized = path_1.default.basename(file.originalname, ext).replace(/[^a-zA-Z0-9-]/g, '_');
        cb(null, `${sanitized}-${uniqueSuffix}${ext}`);
    },
});
const fileFilter = (req, file, cb) => {
    const allowedTypes = [
        'image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif',
        'video/mp4', 'video/quicktime', 'video/webm'
    ];
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    }
    else {
        cb(new Error(`Invalid file type: ${file.mimetype}`));
    }
};
const upload = (0, multer_1.default)({
    storage,
    fileFilter,
    limits: { fileSize: MAX_FILE_SIZE },
});
/**
 * Upload Single File (Image or Video)
 * POST /api/v1/upload/image
 */
router.post('/image', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                error: 'No file uploaded',
            });
        }
        const fileUrl = `/uploads/${req.file.filename}`;
        console.log(`✅ File uploaded: ${req.file.originalname} → ${fileUrl}`);
        return res.json({
            success: true,
            data: {
                message: 'File uploaded successfully',
                url: fileUrl,
                urls: {
                    thumbnail: fileUrl,
                    medium: fileUrl,
                    large: fileUrl,
                    original: fileUrl,
                },
            },
        });
    }
    catch (error) {
        console.error('❌ Upload error:', error);
        return res.status(500).json({
            success: false,
            error: error.message || 'Upload failed',
        });
    }
});
/**
 * Upload Multiple Files
 * POST /api/v1/upload/images
 */
router.post('/images', upload.array('files', 5), async (req, res) => {
    try {
        if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'No files uploaded',
            });
        }
        const uploadedFiles = req.files.map((file) => ({
            url: `/uploads/${file.filename}`,
            originalName: file.originalname,
        }));
        console.log(`✅ ${uploadedFiles.length} files uploaded`);
        return res.json({
            success: true,
            data: {
                message: `${uploadedFiles.length} files uploaded successfully`,
                files: uploadedFiles,
            },
        });
    }
    catch (error) {
        console.error('❌ Multiple upload error:', error);
        return res.status(500).json({
            success: false,
            error: error.message || 'Upload failed',
        });
    }
});
exports.default = router;
//# sourceMappingURL=upload.routes.simple.js.map