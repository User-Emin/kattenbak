"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const mock_products_1 = require("@/data/mock-products");
const router = (0, express_1.Router)();
/**
 * PUBLIC PRODUCT ROUTES - DRY & Database-free
 * Uses SHARED mock data source - changes from admin are visible here!
 */
// DRY helper - Prevents redundancy
const jsonResponse = (res, data) => {
    res.json({ success: true, data });
};
// Get all products
router.get('/', (req, res) => {
    const product = (0, mock_products_1.getProduct)();
    jsonResponse(res, {
        products: [product],
        pagination: { page: 1, pageSize: 12, total: 1, totalPages: 1 },
    });
});
// Get featured products
router.get('/featured', (req, res) => {
    const product = (0, mock_products_1.getProduct)();
    jsonResponse(res, [product]);
});
// Get product by slug - CRITICAL for product detail page
router.get('/slug/:slug', (req, res) => {
    const product = (0, mock_products_1.getProduct)();
    jsonResponse(res, product);
});
// Get product by ID
router.get('/:id', (req, res) => {
    const product = (0, mock_products_1.getProduct)();
    jsonResponse(res, product);
});
exports.default = router;
//# sourceMappingURL=product.routes.simple.js.map