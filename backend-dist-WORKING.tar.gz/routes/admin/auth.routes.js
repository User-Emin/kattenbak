"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_controller_1 = require("../../controllers/admin/auth.controller");
const validation_middleware_1 = require("../../middleware/validation.middleware");
const zod_1 = require("zod");
const router = (0, express_1.Router)();
// DRY Login Schema - Accept localhost emails for development
const loginSchema = zod_1.z.object({
    body: zod_1.z.object({
        email: zod_1.z.string().min(3, 'Email required'), // Relaxed validation
        password: zod_1.z.string().min(1, 'Password is required'),
    }),
});
router.post('/login', (0, validation_middleware_1.validateRequest)(loginSchema), auth_controller_1.AdminAuthController.login);
exports.default = router;
//# sourceMappingURL=auth.routes.js.map