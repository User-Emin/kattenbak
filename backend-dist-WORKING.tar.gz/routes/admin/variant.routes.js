"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const zod_1 = require("zod");
const database_config_1 = require("../../config/database.config");
const response_util_1 = require("../../utils/response.util");
const logger_config_1 = require("../../config/logger.config");
const router = (0, express_1.Router)();
/**
 * PRODUCT VARIANT ROUTES - DRY & SECURE
 * Manage color variants with separate images and stock
 *
 * Security:
 * - Zod validation for all inputs
 * - SQL injection prevention via Prisma
 * - XSS protection via sanitization
 * - Audit logging for all changes
 */
// ============================================
// VALIDATION SCHEMAS
// ============================================
const createVariantSchema = zod_1.z.object({
    productId: zod_1.z.string().cuid(),
    name: zod_1.z.string().min(1).max(100),
    sku: zod_1.z.string().min(1).max(50),
    colorCode: zod_1.z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
    colorImageUrl: zod_1.z.string().url().optional(),
    priceAdjustment: zod_1.z.number().optional(),
    stock: zod_1.z.number().int().min(0).default(0),
    images: zod_1.z.array(zod_1.z.string().url()).default([]),
    isActive: zod_1.z.boolean().default(true),
    sortOrder: zod_1.z.number().int().min(0).default(0),
});
const updateVariantSchema = createVariantSchema.partial().omit({ productId: true });
// ============================================
// ROUTES
// ============================================
/**
 * GET /admin/variants?productId=xxx
 * List all variants for a product
 */
router.get('/', async (req, res) => {
    try {
        const { productId } = req.query;
        if (!productId || typeof productId !== 'string') {
            return (0, response_util_1.errorResponse)(res, 'Product ID is required', 400);
        }
        const variants = await database_config_1.prisma.productVariant.findMany({
            where: { productId },
            orderBy: { sortOrder: 'asc' },
            include: {
                product: {
                    select: {
                        id: true,
                        name: true,
                        sku: true,
                    },
                },
            },
        });
        logger_config_1.logger.info('📦 Variants fetched', { productId, count: variants.length });
        return (0, response_util_1.successResponse)(res, variants);
    }
    catch (error) {
        logger_config_1.logger.error('❌ Variant list error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to fetch variants', 500);
    }
});
/**
 * GET /admin/variants/:id
 * Get single variant
 */
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const variant = await database_config_1.prisma.productVariant.findUnique({
            where: { id },
            include: {
                product: {
                    select: {
                        id: true,
                        name: true,
                        sku: true,
                        hasVariants: true,
                    },
                },
            },
        });
        if (!variant) {
            return (0, response_util_1.errorResponse)(res, 'Variant not found', 404);
        }
        return (0, response_util_1.successResponse)(res, variant);
    }
    catch (error) {
        logger_config_1.logger.error('❌ Variant fetch error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to fetch variant', 500);
    }
});
/**
 * POST /admin/variants
 * Create new variant
 */
router.post('/', async (req, res) => {
    try {
        // Validate input
        const validatedData = createVariantSchema.parse(req.body);
        // Check if product exists
        const product = await database_config_1.prisma.product.findUnique({
            where: { id: validatedData.productId },
        });
        if (!product) {
            return (0, response_util_1.errorResponse)(res, 'Product not found', 404);
        }
        // Check SKU uniqueness
        const existingSku = await database_config_1.prisma.productVariant.findUnique({
            where: { sku: validatedData.sku },
        });
        if (existingSku) {
            return (0, response_util_1.errorResponse)(res, 'SKU already exists', 400);
        }
        // Create variant
        const variant = await database_config_1.prisma.productVariant.create({
            data: validatedData,
        });
        // Enable hasVariants on product if not already
        if (!product.hasVariants) {
            await database_config_1.prisma.product.update({
                where: { id: validatedData.productId },
                data: { hasVariants: true },
            });
        }
        logger_config_1.logger.info('✅ Variant created', {
            variantId: variant.id,
            productId: validatedData.productId,
            name: variant.name,
        });
        return (0, response_util_1.successResponse)(res, variant, 'Variant created successfully', 201);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return (0, response_util_1.errorResponse)(res, 'Validation error', 400);
        }
        logger_config_1.logger.error('❌ Variant creation error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to create variant', 500);
    }
});
/**
 * PUT /admin/variants/:id
 * Update variant
 */
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        // Validate input
        const validatedData = updateVariantSchema.parse(req.body);
        // Check if variant exists
        const existingVariant = await database_config_1.prisma.productVariant.findUnique({
            where: { id },
        });
        if (!existingVariant) {
            return (0, response_util_1.errorResponse)(res, 'Variant not found', 404);
        }
        // Check SKU uniqueness if being updated
        if (validatedData.sku && validatedData.sku !== existingVariant.sku) {
            const skuExists = await database_config_1.prisma.productVariant.findUnique({
                where: { sku: validatedData.sku },
            });
            if (skuExists) {
                return (0, response_util_1.errorResponse)(res, 'SKU already exists', 400);
            }
        }
        // Update variant
        const variant = await database_config_1.prisma.productVariant.update({
            where: { id },
            data: validatedData,
        });
        logger_config_1.logger.info('✅ Variant updated', {
            variantId: variant.id,
            changes: Object.keys(validatedData),
        });
        return (0, response_util_1.successResponse)(res, variant, 'Variant updated successfully');
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return (0, response_util_1.errorResponse)(res, 'Validation error', 400);
        }
        logger_config_1.logger.error('❌ Variant update error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to update variant', 500);
    }
});
/**
 * DELETE /admin/variants/:id
 * Delete variant
 */
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        // Check if variant exists
        const variant = await database_config_1.prisma.productVariant.findUnique({
            where: { id },
            include: {
                product: {
                    include: {
                        variants: true,
                    },
                },
            },
        });
        if (!variant) {
            return (0, response_util_1.errorResponse)(res, 'Variant not found', 404);
        }
        // Delete variant
        await database_config_1.prisma.productVariant.delete({
            where: { id },
        });
        // If this was the last variant, disable hasVariants on product
        if (variant.product.variants.length === 1) {
            await database_config_1.prisma.product.update({
                where: { id: variant.productId },
                data: { hasVariants: false },
            });
        }
        logger_config_1.logger.info('✅ Variant deleted', {
            variantId: id,
            productId: variant.productId,
        });
        return (0, response_util_1.successResponse)(res, { id }, 'Variant deleted successfully');
    }
    catch (error) {
        logger_config_1.logger.error('❌ Variant deletion error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to delete variant', 500);
    }
});
/**
 * POST /admin/variants/:id/images
 * Add images to variant
 */
router.post('/:id/images', async (req, res) => {
    try {
        const { id } = req.params;
        const { images } = req.body;
        // Validate images array
        const imageSchema = zod_1.z.array(zod_1.z.string().url());
        const validatedImages = imageSchema.parse(images);
        // Check if variant exists
        const variant = await database_config_1.prisma.productVariant.findUnique({
            where: { id },
        });
        if (!variant) {
            return (0, response_util_1.errorResponse)(res, 'Variant not found', 404);
        }
        // Get existing images
        const existingImages = Array.isArray(variant.images) ? variant.images : [];
        // Merge with new images (avoid duplicates)
        const mergedImages = Array.from(new Set([...existingImages, ...validatedImages]));
        // Update variant
        const updated = await database_config_1.prisma.productVariant.update({
            where: { id },
            data: { images: mergedImages },
        });
        logger_config_1.logger.info('✅ Variant images added', {
            variantId: id,
            newCount: mergedImages.length,
        });
        return (0, response_util_1.successResponse)(res, updated, 'Images added successfully');
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return (0, response_util_1.errorResponse)(res, 'Invalid image URLs', 400);
        }
        logger_config_1.logger.error('❌ Variant image add error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to add images', 500);
    }
});
/**
 * DELETE /admin/variants/:id/images
 * Remove images from variant
 */
router.delete('/:id/images', async (req, res) => {
    try {
        const { id } = req.params;
        const { imageUrls } = req.body;
        // Validate image URLs array
        const imageSchema = zod_1.z.array(zod_1.z.string().url());
        const validatedUrls = imageSchema.parse(imageUrls);
        // Check if variant exists
        const variant = await database_config_1.prisma.productVariant.findUnique({
            where: { id },
        });
        if (!variant) {
            return (0, response_util_1.errorResponse)(res, 'Variant not found', 404);
        }
        // Get existing images
        const existingImages = Array.isArray(variant.images) ? variant.images : [];
        // Remove specified images
        const filteredImages = existingImages.filter((img) => !validatedUrls.includes(img));
        // Update variant
        const updated = await database_config_1.prisma.productVariant.update({
            where: { id },
            data: { images: filteredImages },
        });
        logger_config_1.logger.info('✅ Variant images removed', {
            variantId: id,
            removedCount: existingImages.length - filteredImages.length,
        });
        return (0, response_util_1.successResponse)(res, updated, 'Images removed successfully');
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return (0, response_util_1.errorResponse)(res, 'Invalid image URLs', 400);
        }
        logger_config_1.logger.error('❌ Variant image remove error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to remove images', 500);
    }
});
/**
 * PATCH /admin/variants/:id/stock
 * Update variant stock
 */
router.patch('/:id/stock', async (req, res) => {
    try {
        const { id } = req.params;
        const { stock } = req.body;
        // Validate stock
        const stockSchema = zod_1.z.number().int().min(0);
        const validatedStock = stockSchema.parse(stock);
        // Check if variant exists
        const variant = await database_config_1.prisma.productVariant.findUnique({
            where: { id },
        });
        if (!variant) {
            return (0, response_util_1.errorResponse)(res, 'Variant not found', 404);
        }
        // Update stock
        const updated = await database_config_1.prisma.productVariant.update({
            where: { id },
            data: { stock: validatedStock },
        });
        logger_config_1.logger.info('✅ Variant stock updated', {
            variantId: id,
            oldStock: variant.stock,
            newStock: validatedStock,
        });
        return (0, response_util_1.successResponse)(res, updated, 'Stock updated successfully');
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            return (0, response_util_1.errorResponse)(res, 'Invalid stock value', 400);
        }
        logger_config_1.logger.error('❌ Variant stock update error:', error);
        return (0, response_util_1.errorResponse)(res, 'Failed to update stock', 500);
    }
});
exports.default = router;
//# sourceMappingURL=variant.routes.js.map