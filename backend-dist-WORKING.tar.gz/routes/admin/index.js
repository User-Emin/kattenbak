"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_routes_1 = __importDefault(require("./auth.routes"));
const product_routes_1 = __importDefault(require("./product.routes"));
const order_routes_1 = __importDefault(require("./order.routes"));
const category_routes_1 = __importDefault(require("./category.routes"));
const shipment_routes_1 = __importDefault(require("./shipment.routes"));
const returns_routes_1 = __importDefault(require("./returns.routes"));
const variant_routes_1 = __importDefault(require("./variant.routes"));
const auth_middleware_1 = require("../../middleware/auth.middleware");
/**
 * ADMIN ROUTES INDEX - DRY & Complete with SECURITY
 * All resources voor React Admin dashboard
 */
const router = (0, express_1.Router)();
// Public: Auth routes (login)
router.use('/auth', auth_routes_1.default);
// 🔒 PROTECTED: All other admin routes require authentication + admin role
router.use('/products', auth_middleware_1.authenticate, auth_middleware_1.adminOnly, product_routes_1.default);
router.use('/variants', auth_middleware_1.authenticate, auth_middleware_1.adminOnly, variant_routes_1.default);
router.use('/orders', auth_middleware_1.authenticate, auth_middleware_1.adminOnly, order_routes_1.default);
router.use('/categories', auth_middleware_1.authenticate, auth_middleware_1.adminOnly, category_routes_1.default);
router.use('/shipments', auth_middleware_1.authenticate, auth_middleware_1.adminOnly, shipment_routes_1.default);
router.use('/returns', auth_middleware_1.authenticate, auth_middleware_1.adminOnly, returns_routes_1.default);
exports.default = router;
//# sourceMappingURL=index.js.map