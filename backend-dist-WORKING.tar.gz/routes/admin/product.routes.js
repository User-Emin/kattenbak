"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const mock_products_1 = require("@/data/mock-products");
const router = (0, express_1.Router)();
/**
 * ADMIN PRODUCT ROUTES - DRY & Mock Data
 * React Admin compatible: pagination, sorting, filtering
 * Uses SHARED mock data source for consistency
 */
// GET /admin/products - List with pagination
router.get('/', (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    const product = (0, mock_products_1.getProduct)();
    res.json({
        success: true,
        data: [product],
        meta: {
            page,
            pageSize,
            total: 1,
            totalPages: 1,
        },
    });
});
// GET /admin/products/:id - Single product
router.get('/:id', (req, res) => {
    const product = (0, mock_products_1.getProduct)();
    res.json({
        success: true,
        data: product,
    });
});
// PUT /admin/products/:id - Update (ECHTE update!)
router.put('/:id', (req, res) => {
    console.log('📝 Admin PUT request:', req.body);
    const updated = (0, mock_products_1.updateProduct)(req.body);
    res.json({
        success: true,
        data: updated,
    });
});
// POST /admin/products - Create
router.post('/', (req, res) => {
    const product = (0, mock_products_1.getProduct)();
    res.json({
        success: true,
        data: { ...product, ...req.body, id: String(Date.now()) },
    });
});
// DELETE /admin/products/:id
router.delete('/:id', (req, res) => {
    res.json({
        success: true,
        data: { id: req.params.id },
    });
});
exports.default = router;
//# sourceMappingURL=product.routes.js.map