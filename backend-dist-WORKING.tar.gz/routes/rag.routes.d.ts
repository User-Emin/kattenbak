/**
 * RAG API ROUTES
 * No hCaptcha - security via rate limiting + input validation
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=rag.routes.d.ts.map