"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const webhook_controller_1 = require("../controllers/webhook.controller");
const router = (0, express_1.Router)();
// Mollie webhook (payment status updates)
router.post('/mollie', webhook_controller_1.WebhookController.handleMollieWebhook);
// MyParcel webhook (shipping status updates)
router.post('/myparcel', webhook_controller_1.WebhookController.handleMyParcelWebhook);
exports.default = router;
//# sourceMappingURL=webhook.routes.js.map