/**
 * Enterprise Express Server
 * Production-ready with security, logging, and error handling
 */
declare class Server {
    private app;
    constructor();
    /**
     * Validate environment configuration
     */
    private validateEnvironment;
    /**
     * Initialize middleware
     */
    private initializeMiddleware;
    /**
     * Initialize routes
     */
    private initializeRoutes;
    /**
     * Initialize error handling
     */
    private initializeErrorHandling;
    /**
     * Start server
     */
    start(): Promise<void>;
    /**
     * Graceful shutdown
     */
    shutdown(): Promise<void>;
}
declare const server: Server;
export default server;
//# sourceMappingURL=server.d.ts.map