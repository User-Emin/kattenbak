import { UserRole } from '@prisma/client';
export interface JWTPayload {
    id: string;
    email: string;
    role: UserRole;
}
/**
 * Hash password with bcrypt
 */
export declare function hashPassword(password: string): Promise<string>;
/**
 * Compare password with hash
 */
export declare function comparePasswords(password: string, hash: string): Promise<boolean>;
export declare function generateToken(payload: JWTPayload): string;
/**
 * Verify JWT token
 */
export declare function verifyToken(token: string): JWTPayload | null;
//# sourceMappingURL=auth.util.d.ts.map