"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.noContentResponse = exports.createdResponse = exports.paginatedResponse = void 0;
exports.successResponse = successResponse;
exports.errorResponse = errorResponse;
function successResponse(resOrData, dataOrMessage, messageOrUndefined, statusCode = 200) {
    // Pattern 1: Direct response (res, data, message?, statusCode?)
    if (resOrData && typeof resOrData.status === 'function') {
        const res = resOrData;
        const data = dataOrMessage;
        const message = messageOrUndefined;
        const response = {
            success: true,
            data,
            message,
        };
        return res.status(statusCode).json(response);
    }
    // Pattern 2: Object only (data, message?)
    const data = resOrData;
    const message = dataOrMessage;
    return {
        success: true,
        data,
        message,
    };
}
function errorResponse(resOrMessage, messageOrStatusCode, statusCodeOrUndefined) {
    // Pattern 1: Direct response (res, message, statusCode?)
    if (resOrMessage && typeof resOrMessage.status === 'function') {
        const res = resOrMessage;
        const message = messageOrStatusCode;
        const statusCode = statusCodeOrUndefined || 500;
        const response = {
            success: false,
            error: message,
        };
        return res.status(statusCode).json(response);
    }
    // Pattern 2: Object only (message, statusCode?)
    const message = resOrMessage;
    return {
        success: false,
        error: message,
    };
}
/**
 * Success response with pagination
 */
const paginatedResponse = (res, data, page, pageSize, total, message) => {
    const totalPages = Math.ceil(total / pageSize);
    const response = {
        success: true,
        data,
        message,
        meta: {
            page,
            pageSize,
            total,
            totalPages,
        },
    };
    return res.status(200).json(response);
};
exports.paginatedResponse = paginatedResponse;
/**
 * Created response (201)
 */
const createdResponse = (res, data, message) => {
    return successResponse(res, data, message, 201);
};
exports.createdResponse = createdResponse;
/**
 * No content response (204)
 */
const noContentResponse = (res) => {
    return res.status(204).send();
};
exports.noContentResponse = noContentResponse;
//# sourceMappingURL=response.util.js.map