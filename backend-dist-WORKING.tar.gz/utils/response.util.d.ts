import { Response } from 'express';
import { ApiResponse } from '../types';
/**
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * RESPONSE UTILITIES - DRY & Type-Safe
 * Two patterns supported:
 * 1. Direct: successResponse(res, data) - returns Response
 * 2. Object: successResponse(data) - returns JSON object
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 */
/**
 * Success response - OVERLOADED for flexibility
 */
export declare function successResponse<T>(data: T, message?: string): ApiResponse<T>;
export declare function successResponse<T>(res: Response, data: T, message?: string, statusCode?: number): Response;
/**
 * Error response - OVERLOADED for flexibility
 */
export declare function errorResponse(message: string, statusCode?: number): ApiResponse;
export declare function errorResponse(res: Response, message: string, statusCode?: number): Response;
/**
 * Success response with pagination
 */
export declare const paginatedResponse: <T>(res: Response, data: T[], page: number, pageSize: number, total: number, message?: string) => Response;
/**
 * Created response (201)
 */
export declare const createdResponse: <T>(res: Response, data: T, message?: string) => Response;
/**
 * No content response (204)
 */
export declare const noContentResponse: (res: Response) => Response;
//# sourceMappingURL=response.util.d.ts.map