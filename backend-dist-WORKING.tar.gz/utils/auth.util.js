"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.hashPassword = hashPassword;
exports.comparePasswords = comparePasswords;
exports.generateToken = generateToken;
exports.verifyToken = verifyToken;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const env_config_1 = require("../config/env.config");
/**
 * Hash password with bcrypt
 */
async function hashPassword(password) {
    return bcryptjs_1.default.hash(password, 12);
}
/**
 * Compare password with hash
 */
async function comparePasswords(password, hash) {
    return bcryptjs_1.default.compare(password, hash);
}
function generateToken(payload) {
    const options = {
        expiresIn: env_config_1.env.JWT_EXPIRES_IN, // JWT accepts string or number
    };
    return jsonwebtoken_1.default.sign(payload, env_config_1.env.JWT_SECRET, options);
}
/**
 * Verify JWT token
 */
function verifyToken(token) {
    try {
        return jsonwebtoken_1.default.verify(token, env_config_1.env.JWT_SECRET);
    }
    catch {
        return null;
    }
}
//# sourceMappingURL=auth.util.js.map