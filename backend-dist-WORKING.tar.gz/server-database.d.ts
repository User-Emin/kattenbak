/**
 * PRODUCTION SERVER MET DATABASE
 * - PostgreSQL via Prisma
 * - Geen @ imports (direct requires)
 * - Enterprise niveau
 * - Alles dynamisch uit database
 */
import { Application } from 'express';
declare const app: Application;
export default app;
//# sourceMappingURL=server-database.d.ts.map