"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkoutRateLimiter = exports.authRateLimiter = exports.apiRateLimiter = void 0;
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const env_config_1 = require("../config/env.config");
const logger_config_1 = require("../config/logger.config");
/**
 * Rate limiter configuration
 */
const createRateLimiter = (windowMs, max, message = 'Too many requests, please try again later') => {
    return (0, express_rate_limit_1.default)({
        windowMs,
        max,
        message: { success: false, error: message },
        standardHeaders: true,
        legacyHeaders: false,
        // Use Redis if available, otherwise use memory
        skip: (req) => {
            // Skip rate limiting for health checks
            return req.path === '/health' || req.path === '/api/v1/health';
        },
        handler: (req, res) => {
            logger_config_1.logger.warn('Rate limit exceeded:', {
                ip: req.ip,
                path: req.path,
                method: req.method,
            });
            res.status(429).json({
                success: false,
                error: message,
            });
        },
    });
};
/**
 * General API rate limiter
 */
exports.apiRateLimiter = createRateLimiter(env_config_1.env.RATE_LIMIT_WINDOW_MS, env_config_1.env.RATE_LIMIT_MAX_REQUESTS, 'Too many requests from this IP, please try again later');
/**
 * Strict rate limiter for authentication endpoints
 */
exports.authRateLimiter = createRateLimiter(15 * 60 * 1000, // 15 minutes
5, // 5 attempts
'Too many login attempts, please try again after 15 minutes');
/**
 * Checkout rate limiter
 */
exports.checkoutRateLimiter = createRateLimiter(60 * 1000, // 1 minute
3, // 3 attempts
'Too many checkout attempts, please wait a minute');
//# sourceMappingURL=ratelimit.middleware.js.map