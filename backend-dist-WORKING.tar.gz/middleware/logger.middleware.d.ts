import { Request, Response, NextFunction } from 'express';
/**
 * Request logging middleware
 * Logs all incoming requests
 */
export declare const requestLogger: (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=logger.middleware.d.ts.map