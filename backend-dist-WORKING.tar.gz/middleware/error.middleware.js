"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.notFoundHandler = exports.errorHandler = void 0;
const errors_util_1 = require("../utils/errors.util");
const logger_config_1 = require("../config/logger.config");
const env_config_1 = require("../config/env.config");
const response_util_1 = require("../utils/response.util");
/**
 * Global error handler middleware
 * Catches all errors and sends appropriate response
 */
const errorHandler = (error, req, res, next) => {
    // Default error
    let statusCode = 500;
    let message = 'Internal server error';
    let isOperational = false;
    // If it's our custom AppError
    if (error instanceof errors_util_1.AppError) {
        statusCode = error.statusCode;
        message = error.message;
        isOperational = error.isOperational;
    }
    // Log error
    if (!isOperational || statusCode >= 500) {
        logger_config_1.logger.error('Error:', {
            message: error.message,
            stack: error.stack,
            url: req.url,
            method: req.method,
            ip: req.ip,
            statusCode,
        });
    }
    else {
        logger_config_1.logger.warn('Operational error:', {
            message: error.message,
            url: req.url,
            method: req.method,
            statusCode,
        });
    }
    // Send error response
    (0, response_util_1.errorResponse)(res, message, statusCode, env_config_1.env.IS_DEVELOPMENT ? { stack: error.stack } : undefined);
};
exports.errorHandler = errorHandler;
/**
 * 404 Not Found handler
 */
const notFoundHandler = (req, res, next) => {
    (0, response_util_1.errorResponse)(res, `Route ${req.method} ${req.url} not found`, 404);
};
exports.notFoundHandler = notFoundHandler;
//# sourceMappingURL=error.middleware.js.map