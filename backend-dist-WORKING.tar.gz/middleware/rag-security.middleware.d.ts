/**
 * RAG SECURITY MIDDLEWARE
 * 4-Layer defense against prompt injection and attacks
 * In-memory rate limiting (no database dependency)
 */
import { Request, Response, NextFunction } from 'express';
export interface SecurityCheckResult {
    safe: boolean;
    flagged: boolean;
    attack_type?: string;
    sanitized_query: string;
}
export declare class RAGSecurityMiddleware {
    /**
     * Main security check middleware
     */
    static checkSecurity(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * Layer 1: Rate limiting (10 requests per minute per IP) - IN-MEMORY
     */
    private static checkRateLimit;
    /**
     * Layer 2: Input sanitization
     */
    private static sanitizeInput;
    /**
     * Layer 3: Attack detection
     */
    private static detectAttacks;
    /**
     * Layer 4: Query logging (console only - no database)
     */
    private static logQuery;
}
//# sourceMappingURL=rag-security.middleware.d.ts.map