/**
 * General API rate limiter
 */
export declare const apiRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Strict rate limiter for authentication endpoints
 */
export declare const authRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Checkout rate limiter
 */
export declare const checkoutRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
//# sourceMappingURL=ratelimit.middleware.d.ts.map