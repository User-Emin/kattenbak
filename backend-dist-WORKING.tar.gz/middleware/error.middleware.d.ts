import { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/errors.util';
/**
 * Global error handler middleware
 * Catches all errors and sends appropriate response
 */
export declare const errorHandler: (error: Error | AppError, req: Request, res: Response, next: NextFunction) => void;
/**
 * 404 Not Found handler
 */
export declare const notFoundHandler: (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=error.middleware.d.ts.map