"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminOnly = exports.authorize = exports.authenticate = void 0;
const auth_util_1 = require("../utils/auth.util");
const errors_util_1 = require("../utils/errors.util");
const client_1 = require("@prisma/client");
/**
 * Authentication middleware
 * Verifies JWT token and attaches user to request
 */
const authenticate = (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new errors_util_1.UnauthorizedError('No token provided');
        }
        const token = authHeader.substring(7);
        const user = (0, auth_util_1.verifyToken)(token);
        if (!user) {
            throw new errors_util_1.UnauthorizedError('Invalid or expired token');
        }
        // Attach user to request
        req.user = user;
        next();
    }
    catch (error) {
        if (error instanceof errors_util_1.UnauthorizedError) {
            next(error);
        }
        else {
            next(new errors_util_1.UnauthorizedError('Authentication failed'));
        }
    }
};
exports.authenticate = authenticate;
/**
 * Authorization middleware factory
 * Checks if user has required role
 */
const authorize = (...roles) => {
    return (req, res, next) => {
        const user = req.user;
        if (!user) {
            return next(new errors_util_1.UnauthorizedError('Authentication required'));
        }
        if (!roles.includes(user.role)) {
            return next(new errors_util_1.ForbiddenError('Insufficient permissions to access this resource'));
        }
        next();
    };
};
exports.authorize = authorize;
/**
 * Admin only middleware
 */
exports.adminOnly = (0, exports.authorize)(client_1.UserRole.ADMIN);
//# sourceMappingURL=auth.middleware.js.map