"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestLogger = void 0;
const logger_config_1 = require("../config/logger.config");
const env_config_1 = require("../config/env.config");
/**
 * Request logging middleware
 * Logs all incoming requests
 */
const requestLogger = (req, res, next) => {
    const start = Date.now();
    // Log response when finished
    res.on('finish', () => {
        const duration = Date.now() - start;
        const logData = {
            method: req.method,
            url: req.url,
            statusCode: res.statusCode,
            duration: `${duration}ms`,
            ip: req.ip,
            userAgent: req.get('user-agent'),
        };
        if (res.statusCode >= 500) {
            logger_config_1.logger.error('Request failed', logData);
        }
        else if (res.statusCode >= 400) {
            logger_config_1.logger.warn('Request error', logData);
        }
        else if (env_config_1.env.IS_DEVELOPMENT) {
            logger_config_1.logger.info('Request', logData);
        }
    });
    next();
};
exports.requestLogger = requestLogger;
//# sourceMappingURL=logger.middleware.js.map