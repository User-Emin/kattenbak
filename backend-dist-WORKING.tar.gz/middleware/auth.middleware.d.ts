import { Request, Response, NextFunction } from 'express';
import { UserRole } from '@prisma/client';
/**
 * Authentication middleware
 * Verifies JWT token and attaches user to request
 */
export declare const authenticate: (req: Request, res: Response, next: NextFunction) => void;
/**
 * Authorization middleware factory
 * Checks if user has required role
 */
export declare const authorize: (...roles: UserRole[]) => (req: Request, res: Response, next: NextFunction) => void;
/**
 * Admin only middleware
 */
export declare const adminOnly: (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=auth.middleware.d.ts.map