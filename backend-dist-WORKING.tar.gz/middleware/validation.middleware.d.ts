import { Request, Response, NextFunction } from 'express';
import { AnyZodObject } from 'zod';
/**
 * Validation Middleware
 * Validates request using Zod schemas
 */
export declare const validateRequest: (schema: AnyZodObject) => (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=validation.middleware.d.ts.map