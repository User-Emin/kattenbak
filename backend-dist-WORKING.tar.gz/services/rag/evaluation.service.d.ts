/**
 * RAG EVALUATION SERVICE
 * MRR, Precision@K, NDCG metrics
 */
interface EvaluationResult {
    mrr: number;
    precision_at_1: number;
    precision_at_3: number;
    precision_at_5: number;
    ndcg: number;
    total_queries: number;
    avg_latency_ms: number;
}
interface TestQuery {
    question: string;
    expected_doc_ids: string[];
    category: string;
    importance: 'critical' | 'high' | 'medium';
}
export declare class EvaluationService {
    /**
     * Calculate Mean Reciprocal Rank
     */
    static calculateMRR(results: Array<{
        retrieved: string[];
        expected: string[];
    }>): number;
    /**
     * Find rank of first correct document
     */
    private static findFirstCorrectRank;
    /**
     * Calculate Precision@K
     */
    static calculatePrecisionAtK(retrieved: string[], expected: string[], k: number): number;
    /**
     * Run complete evaluation
     */
    static runEvaluation(testQueries: TestQuery[]): Promise<EvaluationResult>;
}
export {};
//# sourceMappingURL=evaluation.service.d.ts.map