"use strict";
/**
 * DOCUMENT INGESTION SERVICE
 * Load product specifications into IN-MEMORY vector store
 * No PostgreSQL/pgvector needed
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentIngestionService = void 0;
const embeddings_service_1 = require("./embeddings.service");
const vector_store_service_1 = require("./vector-store.service");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
class DocumentIngestionService {
    /**
     * Ingest all product specifications
     */
    static async ingestProductSpecifications() {
        console.log('🔄 Starting document ingestion (IN-MEMORY)...');
        const specsPath = path.join(__dirname, '../../data/product-specifications.json');
        const specsData = JSON.parse(fs.readFileSync(specsPath, 'utf-8'));
        console.log(`📄 Found ${specsData.documents.length} documents for product ${specsData.sku}`);
        const vectorDocs = [];
        for (const doc of specsData.documents) {
            try {
                // Generate content hash for ID
                const contentHash = embeddings_service_1.EmbeddingsService.calculateHash(doc.content);
                const docId = `doc_${contentHash.substring(0, 12)}`;
                // Generate embedding
                console.log(`🔮 Generating embedding for: ${doc.title}`);
                const { embedding } = await embeddings_service_1.EmbeddingsService.generateEmbedding(doc.content);
                // Create vector document
                const vectorDoc = {
                    id: docId,
                    content: doc.content,
                    embedding,
                    metadata: {
                        title: doc.title,
                        keywords: doc.keywords,
                        importance: doc.importance,
                        sku: specsData.sku,
                        product_id: specsData.product_id,
                        type: doc.type
                    },
                    type: doc.type
                };
                vectorDocs.push(vectorDoc);
                console.log(`✅ Prepared: ${doc.title}`);
            }
            catch (err) {
                console.error(`❌ Failed to prepare ${doc.title}:`, err.message);
            }
        }
        // Add all documents to vector store
        await vector_store_service_1.VectorStoreService.addDocuments(vectorDocs);
        console.log('');
        console.log('========================================');
        console.log('📊 INGESTION COMPLETE');
        console.log('========================================');
        console.log(`✅ Ingested: ${vectorDocs.length} documents`);
        console.log(`💾 Storage: IN-MEMORY + File persistence`);
        console.log('========================================');
    }
    /**
     * Clear all documents (for re-ingestion)
     */
    static async clearDocuments() {
        console.log('🗑️  Clearing all documents...');
        await vector_store_service_1.VectorStoreService.clear();
        console.log('✅ All documents cleared');
    }
    /**
     * Get document count
     */
    static async getDocumentCount() {
        return vector_store_service_1.VectorStoreService.getCount();
    }
}
exports.DocumentIngestionService = DocumentIngestionService;
// CLI commands
if (require.main === module) {
    const command = process.argv[2];
    (async () => {
        try {
            if (command === 'ingest') {
                await DocumentIngestionService.ingestProductSpecifications();
            }
            else if (command === 'clear') {
                await DocumentIngestionService.clearDocuments();
            }
            else if (command === 'count') {
                const count = await DocumentIngestionService.getDocumentCount();
                console.log(`📊 Document count: ${count}`);
            }
            else {
                console.log('Usage: ts-node document-ingestion.service.ts [ingest|clear|count]');
            }
        }
        catch (err) {
            console.error('❌ Error:', err.message);
            process.exit(1);
        }
    })();
}
//# sourceMappingURL=document-ingestion.service.js.map