/**
 * IN-MEMORY VECTOR STORE
 * Alternative to pgvector for immediate deployment
 * Suitable for <1000 documents
 *
 * TEAM DECISION: Use this instead of pgvector due to AlmaLinux packaging issues
 * Can upgrade to pgvector later when package available
 */
export interface VectorDocument {
    id: string;
    content: string;
    embedding: number[];
    metadata: any;
    type: string;
}
export declare class VectorStoreService {
    private static documents;
    private static readonly STORE_PATH;
    /**
     * Initialize vector store
     */
    static initialize(): Promise<void>;
    /**
     * Add document to store
     */
    static addDocument(doc: VectorDocument): Promise<void>;
    /**
     * Add multiple documents
     */
    static addDocuments(docs: VectorDocument[]): Promise<void>;
    /**
     * Cosine similarity search
     */
    static similaritySearch(queryEmbedding: number[], maxResults?: number, threshold?: number): Promise<Array<{
        id: string;
        content: string;
        similarity: number;
        metadata: any;
    }>>;
    /**
     * Calculate cosine similarity
     */
    private static cosineSimilarity;
    /**
     * Clear all documents
     */
    static clear(): Promise<void>;
    /**
     * Get document count
     */
    static getCount(): number;
    /**
     * Save to disk
     */
    private static save;
}
//# sourceMappingURL=vector-store.service.d.ts.map