/**
 * DOCUMENT INGESTION SERVICE
 * Load product specifications into IN-MEMORY vector store
 * No PostgreSQL/pgvector needed
 */
export declare class DocumentIngestionService {
    /**
     * Ingest all product specifications
     */
    static ingestProductSpecifications(): Promise<void>;
    /**
     * Clear all documents (for re-ingestion)
     */
    static clearDocuments(): Promise<void>;
    /**
     * Get document count
     */
    static getDocumentCount(): Promise<number>;
}
//# sourceMappingURL=document-ingestion.service.d.ts.map