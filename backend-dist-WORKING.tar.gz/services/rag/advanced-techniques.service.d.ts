/**
 * 10 RAG ADVANCED TECHNIQUES IMPLEMENTATION
 * Based on: Scherm_afbeelding_2025-12-16_om_16.05.33
 * Team: ML Engineer + RAG Specialist
 */
/**
 * 1. CHUNKING R&D
 * Experiment with chunking strategy
 */
export declare class ChunkingService {
    static splitIntoChunks(text: string, chunkSize?: number, overlap?: number): string[];
    static semanticChunking(text: string): string[];
}
/**
 * 2. ENCODER R&D
 * Already implemented: intfloat/multilingual-e5-base (768-dim)
 * This is BEST encoder for Dutch/multilingual
 */
export declare class EncoderOptimization {
    static readonly CURRENT_MODEL = "intfloat/multilingual-e5-base";
    static readonly DIMENSIONS = 768;
    static getModelInfo(): {
        model: string;
        dimensions: number;
        language: string;
        quality: string;
        benchmarks: {
            mteb_dutch: string;
            retrieval_accuracy: string;
        };
    };
}
/**
 * 3. IMPROVE PROMPTS
 * General content, current date, relevant context and history
 */
export declare class PromptOptimization {
    static buildOptimizedPrompt(query: string, context: string, conversationHistory?: string[]): string;
}
/**
 * 4. DOCUMENT PRE-PROCESSING
 * Use an LLM to make the chunks and/or text for encoding
 */
export declare class DocumentPreprocessing {
    static enrichMetadata(document: any): any;
    private static extractKeywords;
    private static categorizeTags;
    private static generateSummary;
}
/**
 * 5. QUERY REWRITING
 * Use an LLM to convert the user's question to a RAG query
 */
export declare class QueryRewriting {
    static expandQuery(query: string): string[];
    static normalizeQuery(query: string): string;
}
/**
 * 6. QUERY EXPANSION
 * Use an LLM to turn the question into multiple RAG queries
 */
export declare class QueryExpansion {
    static generateSubQueries(mainQuery: string): string[];
}
/**
 * 7. RE-RANKING
 * Use an LLM to sub-select from RAG results
 */
export declare class ReRanking {
    static reRankResults(query: string, results: any[]): any[];
}
/**
 * 8. HIERARCHICAL RAG
 * Use an LLM to summarize at multiple levels
 */
export declare class HierarchicalRAG {
    static hierarchicalRetrieval(query: string, topK?: number): Promise<any[]>;
    private static groupByCategory;
}
/**
 * 9. GRAPH RAG
 * Retrieve content closely related to similar documents
 * (Simplified for our use case - full graph DB would be overkill for 21 docs)
 */
export declare class GraphRAG {
    static findRelatedDocuments(documentId: string, maxRelated?: number): Promise<any[]>;
    private static countSharedKeywords;
}
/**
 * 10. AGENTIC RAG
 * Use Agents for retrieval, combining with Memory and Tools such as SQL
 * (Simplified - we don't need SQL for product info)
 */
export declare class AgenticRAG {
    private static memory;
    static agenticRetrieval(query: string, useMemory?: boolean): Promise<{
        answer: string;
        sources: any[];
        reasoning: string[];
        usedMemory: boolean;
    }>;
    private static searchMemory;
    private static classifyQuery;
    private static stringSimilarity;
    private static levenshteinDistance;
    static addToMemory(query: string, answer: string): void;
}
/**
 * INTEGRATION: Enhanced RAG Service using all 10 techniques
 */
export declare class EnhancedRAGPipeline {
    static processQuery(query: string): Promise<{
        optimizedQuery: string;
        expandedQueries: string[];
        results: any[];
        reasoning: string[];
    }>;
}
//# sourceMappingURL=advanced-techniques.service.d.ts.map