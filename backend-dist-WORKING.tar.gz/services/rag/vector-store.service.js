"use strict";
/**
 * IN-MEMORY VECTOR STORE
 * Alternative to pgvector for immediate deployment
 * Suitable for <1000 documents
 *
 * TEAM DECISION: Use this instead of pgvector due to AlmaLinux packaging issues
 * Can upgrade to pgvector later when package available
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.VectorStoreService = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
class VectorStoreService {
    static documents = [];
    static STORE_PATH = path.join(__dirname, '../../../data/vector-store.json');
    /**
     * Initialize vector store
     */
    static async initialize() {
        try {
            if (fs.existsSync(this.STORE_PATH)) {
                const data = fs.readFileSync(this.STORE_PATH, 'utf-8');
                const parsed = JSON.parse(data);
                // Handle both old format (array) and new format (object with documents key)
                if (Array.isArray(parsed)) {
                    this.documents = parsed;
                }
                else if (parsed.documents && Array.isArray(parsed.documents)) {
                    this.documents = parsed.documents;
                }
                else {
                    throw new Error('Invalid vector store format');
                }
                console.log(`✅ Vector store loaded: ${this.documents.length} documents`);
            }
            else {
                console.log('ℹ️  Vector store empty - run ingestion');
            }
        }
        catch (err) {
            console.error('Vector store initialization error:', err.message);
            this.documents = [];
        }
    }
    /**
     * Add document to store
     */
    static async addDocument(doc) {
        // Check for duplicates
        const existing = this.documents.findIndex(d => d.id === doc.id);
        if (existing >= 0) {
            this.documents[existing] = doc;
        }
        else {
            this.documents.push(doc);
        }
        // Persist to disk
        await this.save();
    }
    /**
     * Add multiple documents
     */
    static async addDocuments(docs) {
        for (const doc of docs) {
            await this.addDocument(doc);
        }
        console.log(`✅ Added ${docs.length} documents to vector store`);
    }
    /**
     * Cosine similarity search
     */
    static async similaritySearch(queryEmbedding, maxResults = 5, threshold = 0.65) {
        // Calculate cosine similarity for all documents
        const results = this.documents.map(doc => ({
            id: doc.id,
            content: doc.content,
            metadata: doc.metadata,
            similarity: this.cosineSimilarity(queryEmbedding, doc.embedding)
        }));
        // Filter by threshold and sort by similarity
        return results
            .filter(r => r.similarity >= threshold)
            .sort((a, b) => b.similarity - a.similarity)
            .slice(0, maxResults);
    }
    /**
     * Calculate cosine similarity
     */
    static cosineSimilarity(a, b) {
        if (a.length !== b.length) {
            throw new Error('Vectors must have same dimensions');
        }
        let dotProduct = 0;
        let normA = 0;
        let normB = 0;
        for (let i = 0; i < a.length; i++) {
            dotProduct += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        normA = Math.sqrt(normA);
        normB = Math.sqrt(normB);
        if (normA === 0 || normB === 0)
            return 0;
        return dotProduct / (normA * normB);
    }
    /**
     * Clear all documents
     */
    static async clear() {
        this.documents = [];
        await this.save();
        console.log('✅ Vector store cleared');
    }
    /**
     * Get document count
     */
    static getCount() {
        return this.documents.length;
    }
    /**
     * Save to disk
     */
    static async save() {
        try {
            const dir = path.dirname(this.STORE_PATH);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            fs.writeFileSync(this.STORE_PATH, JSON.stringify(this.documents, null, 2), 'utf-8');
        }
        catch (err) {
            console.error('Failed to save vector store:', err.message);
        }
    }
}
exports.VectorStoreService = VectorStoreService;
// Initialize on import
VectorStoreService.initialize();
//# sourceMappingURL=vector-store.service.js.map