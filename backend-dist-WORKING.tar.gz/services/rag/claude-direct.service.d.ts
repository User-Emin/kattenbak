/**
 * CLAUDE DIRECT API - NO SDK DEPENDENCY
 * Uses native fetch to call Anthropic REST API
 * Team: AI Engineer + Security Expert
 */
export declare class ClaudeDirectService {
    private static readonly API_URL;
    private static readonly API_KEY;
    private static readonly MODEL;
    private static readonly API_VERSION;
    /**
     * Main RAG pipeline
     */
    static answerQuestion(question: string): Promise<{
        answer: string;
        latency_ms: number;
        model: string;
        sources: any[];
        backend: string;
    }>;
    /**
     * Call Claude REST API directly
     */
    private static callClaude;
    /**
     * Health check
     */
    static healthCheck(): Promise<{
        claude: boolean;
        vectorStore: boolean;
        embeddings: boolean;
    }>;
}
//# sourceMappingURL=claude-direct.service.d.ts.map