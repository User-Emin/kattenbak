"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductService = void 0;
const database_config_1 = require("../config/database.config");
const errors_util_1 = require("../utils/errors.util");
const logger_config_1 = require("../config/logger.config");
const redis_config_1 = require("../config/redis.config");
/**
 * Enterprise Product Service
 * Handles all product-related business logic
 */
class ProductService {
    static CACHE_TTL = 300; // 5 minutes
    static CACHE_PREFIX = 'product:';
    /**
     * Get all products with filters and pagination
     */
    static async getAllProducts(filters = {}, pagination) {
        const { page, pageSize, sortBy = 'createdAt', sortOrder = 'desc' } = pagination;
        const skip = (page - 1) * pageSize;
        // Build where clause
        const where = {
            isActive: true,
            ...(filters.categoryId && { categoryId: filters.categoryId }),
            ...(filters.isFeatured !== undefined && { isFeatured: filters.isFeatured }),
            ...(filters.inStock && { stock: { gt: 0 } }),
            ...(filters.minPrice && { price: { gte: filters.minPrice } }),
            ...(filters.maxPrice && { price: { lte: filters.maxPrice } }),
            ...(filters.search && {
                OR: [
                    { name: { contains: filters.search, mode: 'insensitive' } },
                    { description: { contains: filters.search, mode: 'insensitive' } },
                    { sku: { contains: filters.search, mode: 'insensitive' } },
                ],
            }),
        };
        // Execute queries in parallel
        const [products, total] = await Promise.all([
            database_config_1.prisma.product.findMany({
                where,
                skip,
                take: pageSize,
                orderBy: { [sortBy]: sortOrder },
                include: {
                    category: {
                        select: {
                            id: true,
                            name: true,
                            slug: true,
                        },
                    },
                },
            }),
            database_config_1.prisma.product.count({ where }),
        ]);
        return { products, total };
    }
    /**
     * Get product by ID
     */
    static async getProductById(id) {
        // Try cache first
        if (redis_config_1.RedisClient.isAvailable()) {
            const cached = await redis_config_1.redis?.get(`${this.CACHE_PREFIX}${id}`);
            if (cached) {
                logger_config_1.logger.debug(`Product ${id} served from cache`);
                return JSON.parse(cached);
            }
        }
        const product = await database_config_1.prisma.product.findUnique({
            where: { id },
            include: {
                category: true,
                variants: {
                    where: { isActive: true },
                    orderBy: { sortOrder: 'asc' },
                },
            },
        });
        if (!product) {
            throw new errors_util_1.NotFoundError(`Product with ID ${id} not found`);
        }
        if (!product.isActive) {
            throw new errors_util_1.NotFoundError('Product is not available');
        }
        // Cache the result
        if (redis_config_1.RedisClient.isAvailable()) {
            await redis_config_1.redis?.setex(`${this.CACHE_PREFIX}${id}`, this.CACHE_TTL, JSON.stringify(product));
        }
        return product;
    }
    /**
     * Get product by slug
     */
    static async getProductBySlug(slug) {
        const product = await database_config_1.prisma.product.findUnique({
            where: { slug },
            include: {
                category: true,
                variants: {
                    where: { isActive: true },
                    orderBy: { sortOrder: 'asc' },
                },
            },
        });
        if (!product) {
            throw new errors_util_1.NotFoundError(`Product with slug ${slug} not found`);
        }
        if (!product.isActive) {
            throw new errors_util_1.NotFoundError('Product is not available');
        }
        return product;
    }
    /**
     * Get featured products
     */
    static async getFeaturedProducts(limit = 8) {
        return database_config_1.prisma.product.findMany({
            where: {
                isActive: true,
                isFeatured: true,
            },
            take: limit,
            orderBy: { createdAt: 'desc' },
            include: {
                category: {
                    select: {
                        id: true,
                        name: true,
                        slug: true,
                    },
                },
            },
        });
    }
    /**
     * Create product (admin only)
     */
    static async createProduct(data) {
        // Validate SKU uniqueness
        const existing = await database_config_1.prisma.product.findUnique({
            where: { sku: data.sku },
        });
        if (existing) {
            throw new errors_util_1.ValidationError(`Product with SKU ${data.sku} already exists`);
        }
        const product = await database_config_1.prisma.product.create({
            data,
            include: {
                category: true,
            },
        });
        logger_config_1.logger.info(`Product created: ${product.id} (${product.sku})`);
        return product;
    }
    /**
     * Update product (admin only)
     */
    static async updateProduct(id, data) {
        // Check if product exists
        await this.getProductById(id);
        const product = await database_config_1.prisma.product.update({
            where: { id },
            data,
            include: {
                category: true,
            },
        });
        // Invalidate cache
        if (redis_config_1.RedisClient.isAvailable()) {
            await redis_config_1.redis?.del(`${this.CACHE_PREFIX}${id}`);
        }
        logger_config_1.logger.info(`Product updated: ${product.id} (${product.sku})`);
        return product;
    }
    /**
     * Delete product (admin only)
     */
    static async deleteProduct(id) {
        // Check if product exists
        await this.getProductById(id);
        // Soft delete by marking as inactive
        await database_config_1.prisma.product.update({
            where: { id },
            data: { isActive: false },
        });
        // Invalidate cache
        if (redis_config_1.RedisClient.isAvailable()) {
            await redis_config_1.redis?.del(`${this.CACHE_PREFIX}${id}`);
        }
        logger_config_1.logger.info(`Product deleted (soft): ${id}`);
    }
    /**
     * Check product availability
     */
    static async checkAvailability(productId, quantity) {
        const product = await database_config_1.prisma.product.findUnique({
            where: { id: productId },
            select: { stock: true, trackInventory: true, isActive: true },
        });
        if (!product || !product.isActive) {
            return false;
        }
        if (!product.trackInventory) {
            return true;
        }
        return product.stock >= quantity;
    }
    /**
     * Update stock after order
     */
    static async updateStock(productId, quantity) {
        const product = await database_config_1.prisma.product.findUnique({
            where: { id: productId },
        });
        if (!product) {
            throw new errors_util_1.NotFoundError(`Product ${productId} not found`);
        }
        if (product.trackInventory) {
            await database_config_1.prisma.product.update({
                where: { id: productId },
                data: {
                    stock: {
                        decrement: quantity,
                    },
                },
            });
            logger_config_1.logger.info(`Stock updated for product ${productId}: -${quantity}`);
        }
    }
    /**
     * Search products
     */
    static async searchProducts(query, limit = 10) {
        return database_config_1.prisma.product.findMany({
            where: {
                isActive: true,
                OR: [
                    { name: { contains: query, mode: 'insensitive' } },
                    { description: { contains: query, mode: 'insensitive' } },
                    { sku: { contains: query, mode: 'insensitive' } },
                ],
            },
            take: limit,
            include: {
                category: {
                    select: {
                        id: true,
                        name: true,
                        slug: true,
                    },
                },
            },
        });
    }
}
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map