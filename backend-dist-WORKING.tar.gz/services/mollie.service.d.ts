import { Payment as MolliePayment } from '@mollie/api-client';
import { Payment } from '@prisma/client';
/**
 * Mollie Payment Service
 * Enterprise payment integration
 */
export declare class MollieService {
    private static client;
    /**
     * Create payment with optional method selection
     */
    static createPayment(orderId: string, amount: number, description: string, redirectUrl: string, method?: 'ideal' | 'paypal'): Promise<Payment>;
    /**
     * Handle webhook from Mollie
     */
    static handleWebhook(mollieId: string): Promise<void>;
    /**
     * Get payment status
     */
    static getPaymentStatus(mollieId: string): Promise<MolliePayment>;
    /**
     * Refund payment
     */
    static refundPayment(mollieId: string, amount?: number): Promise<void>;
    /**
     * Map Mollie payment method to our enum
     */
    private static mapMollieMethod;
}
//# sourceMappingURL=mollie.service.d.ts.map