import { Order } from '@prisma/client';
interface CreateOrderData {
    items: Array<{
        productId: string;
        quantity: number;
    }>;
    customerEmail: string;
    customerPhone?: string;
    shippingAddress: {
        firstName: string;
        lastName: string;
        street: string;
        houseNumber: string;
        addition?: string;
        postalCode: string;
        city: string;
        country: string;
        phone?: string;
    };
    billingAddress?: {
        firstName: string;
        lastName: string;
        street: string;
        houseNumber: string;
        addition?: string;
        postalCode: string;
        city: string;
        country: string;
        phone?: string;
    };
    customerNotes?: string;
}
/**
 * Order Service
 * Handles order business logic
 */
export declare class OrderService {
    /**
     * Generate unique order number
     */
    private static generateOrderNumber;
    /**
     * Create new order
     */
    static createOrder(data: CreateOrderData): Promise<Order>;
    /**
     * Get order by ID
     */
    static getOrderById(id: string): Promise<Order>;
    /**
     * Get order by order number
     */
    static getOrderByNumber(orderNumber: string): Promise<Order>;
    /**
     * Update order status
     */
    static updateOrderStatus(id: string, status: string): Promise<Order>;
}
export {};
//# sourceMappingURL=order.service.d.ts.map