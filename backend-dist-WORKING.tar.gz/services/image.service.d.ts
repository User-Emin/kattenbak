import multer from 'multer';
export declare const upload: multer.Multer;
/**
 * Process uploaded image - convert to WebP + create sizes
 * DRY: Single function for all image processing
 */
export declare function processImage(filePath: string, originalFilename: string): Promise<{
    thumbnail: string;
    medium: string;
    large: string;
    original: string;
}>;
/**
 * Validate image dimensions (minimum size)
 */
export declare function validateImageDimensions(filePath: string): Promise<boolean>;
/**
 * Delete image files (all sizes)
 */
export declare function deleteImage(filename: string): Promise<void>;
//# sourceMappingURL=image.service.d.ts.map