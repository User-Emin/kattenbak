import { Product, Prisma } from '@prisma/client';
import { ProductFilters, PaginationParams } from '../types';
/**
 * Enterprise Product Service
 * Handles all product-related business logic
 */
export declare class ProductService {
    private static readonly CACHE_TTL;
    private static readonly CACHE_PREFIX;
    /**
     * Get all products with filters and pagination
     */
    static getAllProducts(filters: ProductFilters | undefined, pagination: PaginationParams): Promise<{
        products: Product[];
        total: number;
    }>;
    /**
     * Get product by ID
     */
    static getProductById(id: string): Promise<Product>;
    /**
     * Get product by slug
     */
    static getProductBySlug(slug: string): Promise<Product>;
    /**
     * Get featured products
     */
    static getFeaturedProducts(limit?: number): Promise<Product[]>;
    /**
     * Create product (admin only)
     */
    static createProduct(data: Prisma.ProductCreateInput): Promise<Product>;
    /**
     * Update product (admin only)
     */
    static updateProduct(id: string, data: Prisma.ProductUpdateInput): Promise<Product>;
    /**
     * Delete product (admin only)
     */
    static deleteProduct(id: string): Promise<void>;
    /**
     * Check product availability
     */
    static checkAvailability(productId: string, quantity: number): Promise<boolean>;
    /**
     * Update stock after order
     */
    static updateStock(productId: string, quantity: number): Promise<void>;
    /**
     * Search products
     */
    static searchProducts(query: string, limit?: number): Promise<Product[]>;
}
//# sourceMappingURL=product.service.d.ts.map