"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MollieService = void 0;
const api_client_1 = __importDefault(require("@mollie/api-client"));
const database_config_1 = require("../config/database.config");
const env_config_1 = require("../config/env.config");
const logger_config_1 = require("../config/logger.config");
const errors_util_1 = require("../utils/errors.util");
const client_1 = require("@prisma/client");
/**
 * Mollie Payment Service
 * Enterprise payment integration
 */
class MollieService {
    static client = (0, api_client_1.default)({ apiKey: env_config_1.env.MOLLIE_API_KEY });
    /**
     * Create payment with optional method selection
     */
    static async createPayment(orderId, amount, description, redirectUrl, method // Mollie-supported methods only
    ) {
        try {
            // Create Mollie payment
            const molliePayment = await this.client.payments.create({
                amount: {
                    currency: 'EUR',
                    value: amount.toFixed(2),
                },
                description,
                redirectUrl,
                webhookUrl: env_config_1.env.MOLLIE_WEBHOOK_URL,
                method, // Allow customer to select payment method
                metadata: {
                    orderId,
                },
            });
            // Store payment in database
            const payment = await database_config_1.prisma.payment.create({
                data: {
                    orderId,
                    mollieId: molliePayment.id,
                    amount,
                    currency: 'EUR',
                    status: client_1.PaymentStatus.PENDING,
                    checkoutUrl: molliePayment._links.checkout?.href || null,
                    webhookUrl: env_config_1.env.MOLLIE_WEBHOOK_URL,
                    redirectUrl,
                    description,
                    metadata: {
                        mollieStatus: molliePayment.status,
                    },
                },
            });
            logger_config_1.logger.info(`Payment created: ${payment.id} (Mollie: ${molliePayment.id})`);
            return payment;
        }
        catch (error) {
            logger_config_1.logger.error('Mollie payment creation failed:', error);
            throw new errors_util_1.InternalServerError('Failed to create payment');
        }
    }
    /**
     * Handle webhook from Mollie
     */
    static async handleWebhook(mollieId) {
        try {
            // Get payment status from Mollie
            const molliePayment = await this.client.payments.get(mollieId);
            // Find payment in database
            const payment = await database_config_1.prisma.payment.findUnique({
                where: { mollieId },
                include: { order: true },
            });
            if (!payment) {
                throw new errors_util_1.NotFoundError(`Payment with Mollie ID ${mollieId} not found`);
            }
            // Map Mollie status to our status
            let status = client_1.PaymentStatus.PENDING;
            switch (molliePayment.status) {
                case 'paid':
                    status = client_1.PaymentStatus.PAID;
                    break;
                case 'failed':
                case 'canceled':
                    status = client_1.PaymentStatus.FAILED;
                    break;
                case 'expired':
                    status = client_1.PaymentStatus.EXPIRED;
                    break;
                case 'refunded':
                    status = client_1.PaymentStatus.REFUNDED;
                    break;
            }
            // Update payment and order
            await database_config_1.prisma.$transaction(async (tx) => {
                // Update payment
                await tx.payment.update({
                    where: { id: payment.id },
                    data: {
                        status,
                        method: this.mapMollieMethod(molliePayment.method),
                        paidAt: molliePayment.paidAt ? new Date(molliePayment.paidAt) : null,
                        metadata: {
                            ...payment.metadata,
                            mollieStatus: molliePayment.status,
                        },
                    },
                });
                // Update order status
                if (status === client_1.PaymentStatus.PAID) {
                    await tx.order.update({
                        where: { id: payment.orderId },
                        data: {
                            status: 'PAID',
                        },
                    });
                }
                else if (status === client_1.PaymentStatus.FAILED || status === client_1.PaymentStatus.EXPIRED) {
                    await tx.order.update({
                        where: { id: payment.orderId },
                        data: {
                            status: 'CANCELLED',
                        },
                    });
                }
            });
            logger_config_1.logger.info(`Payment webhook processed: ${mollieId} -> ${status}`);
        }
        catch (error) {
            logger_config_1.logger.error('Mollie webhook processing failed:', error);
            throw error;
        }
    }
    /**
     * Get payment status
     */
    static async getPaymentStatus(mollieId) {
        return this.client.payments.get(mollieId);
    }
    /**
     * Refund payment
     */
    static async refundPayment(mollieId, amount) {
        try {
            const refundData = {};
            if (amount) {
                refundData.amount = {
                    currency: 'EUR',
                    value: amount.toFixed(2),
                };
            }
            await this.client.payments.refund(mollieId, refundData);
            // Update payment in database
            await database_config_1.prisma.payment.update({
                where: { mollieId },
                data: {
                    status: client_1.PaymentStatus.REFUNDED,
                },
            });
            logger_config_1.logger.info(`Payment refunded: ${mollieId}`);
        }
        catch (error) {
            logger_config_1.logger.error('Mollie refund failed:', error);
            throw new errors_util_1.InternalServerError('Failed to refund payment');
        }
    }
    /**
     * Map Mollie payment method to our enum
     */
    static mapMollieMethod(method) {
        if (!method)
            return null;
        const methodMap = {
            ideal: client_1.PaymentMethod.IDEAL,
            creditcard: client_1.PaymentMethod.CREDITCARD,
            bancontact: client_1.PaymentMethod.BANCONTACT,
            paypal: client_1.PaymentMethod.PAYPAL,
            sofort: client_1.PaymentMethod.SOFORT,
            banktransfer: client_1.PaymentMethod.BANK_TRANSFER,
        };
        return methodMap[method] || null;
    }
}
exports.MollieService = MollieService;
//# sourceMappingURL=mollie.service.js.map