"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MyParcelService = void 0;
const axios_1 = __importDefault(require("axios"));
const database_config_1 = require("../config/database.config");
const env_config_1 = require("../config/env.config");
const logger_config_1 = require("../config/logger.config");
const errors_util_1 = require("../utils/errors.util");
const client_1 = require("@prisma/client");
/**
 * MyParcel Shipping Service
 * Enterprise shipping integration
 */
class MyParcelService {
    static API_URL = 'https://api.myparcel.nl';
    static HEADERS = {
        'Authorization': `Bearer ${env_config_1.env.MYPARCEL_API_KEY}`,
        'Content-Type': 'application/json',
        'User-Agent': 'Kattenbak-Webshop/1.0.0',
    };
    /**
     * Create shipment and label
     */
    static async createShipment(orderId) {
        if (!env_config_1.env.MYPARCEL_API_KEY) {
            throw new errors_util_1.InternalServerError('MyParcel API key not configured');
        }
        try {
            // Get order with address
            const order = await database_config_1.prisma.order.findUnique({
                where: { id: orderId },
                include: {
                    shippingAddress: true,
                },
            });
            if (!order || !order.shippingAddress) {
                throw new errors_util_1.NotFoundError(`Order ${orderId} not found or has no shipping address`);
            }
            const address = order.shippingAddress;
            // Create shipment in MyParcel
            const response = await axios_1.default.post(`${this.API_URL}/shipments`, {
                data: {
                    shipments: [{
                            carrier: 1, // PostNL
                            recipient: {
                                cc: address.country,
                                person: `${address.firstName} ${address.lastName}`,
                                street: address.street,
                                number: address.houseNumber,
                                number_suffix: address.addition || '',
                                postal_code: address.postalCode,
                                city: address.city,
                                email: order.customerEmail,
                                phone: address.phone || order.customerPhone || '',
                            },
                            options: {
                                package_type: 1, // Package
                                delivery_type: 2, // Standard delivery
                                signature: false,
                                return: false,
                            },
                        }],
                },
            }, { headers: this.HEADERS });
            const myparcelId = response.data.data.ids[0].id;
            // Download label
            const labelUrl = await this.downloadLabel(myparcelId);
            // Get tracking info
            const trackingInfo = await this.getTrackingInfo(myparcelId);
            // Store shipment in database
            const shipment = await database_config_1.prisma.shipment.create({
                data: {
                    orderId,
                    myparcelId,
                    trackingCode: trackingInfo.trackingCode,
                    trackingUrl: trackingInfo.trackingUrl,
                    carrier: 'PostNL',
                    status: client_1.ShipmentStatus.LABEL_CREATED,
                    labelUrl,
                },
            });
            // Update order status
            await database_config_1.prisma.order.update({
                where: { id: orderId },
                data: { status: 'PROCESSING' },
            });
            logger_config_1.logger.info(`Shipment created: ${shipment.id} (MyParcel: ${myparcelId})`);
            return shipment;
        }
        catch (error) {
            logger_config_1.logger.error('MyParcel shipment creation failed:', error);
            throw new errors_util_1.InternalServerError('Failed to create shipment');
        }
    }
    /**
     * Download label PDF
     */
    static async downloadLabel(myparcelId) {
        try {
            const response = await axios_1.default.get(`${this.API_URL}/shipment_labels/${myparcelId}`, {
                headers: this.HEADERS,
                responseType: 'arraybuffer',
            });
            // In production, save to S3/cloud storage
            // For now, return a placeholder URL
            const labelUrl = `${env_config_1.env.BACKEND_URL}/labels/${myparcelId}.pdf`;
            logger_config_1.logger.info(`Label downloaded for shipment ${myparcelId}`);
            return labelUrl;
        }
        catch (error) {
            logger_config_1.logger.error('MyParcel label download failed:', error);
            throw new errors_util_1.InternalServerError('Failed to download label');
        }
    }
    /**
     * Get tracking information
     */
    static async getTrackingInfo(myparcelId) {
        try {
            const response = await axios_1.default.get(`${this.API_URL}/shipments/${myparcelId}`, { headers: this.HEADERS });
            const shipment = response.data.data.shipments[0];
            const trackingCode = shipment.barcode;
            const trackingUrl = `https://postnl.nl/tracktrace/?B=${trackingCode}&P=${shipment.recipient.postal_code}`;
            return { trackingCode, trackingUrl };
        }
        catch (error) {
            logger_config_1.logger.error('MyParcel tracking info failed:', error);
            return {
                trackingCode: '',
                trackingUrl: '',
            };
        }
    }
    /**
     * Handle webhook from MyParcel
     */
    static async handleWebhook(data) {
        try {
            const myparcelId = data.shipment_id;
            const status = data.status;
            const shipment = await database_config_1.prisma.shipment.findUnique({
                where: { myparcelId },
            });
            if (!shipment) {
                throw new errors_util_1.NotFoundError(`Shipment with MyParcel ID ${myparcelId} not found`);
            }
            // Map MyParcel status to our status
            let shipmentStatus = client_1.ShipmentStatus.PENDING;
            // MyParcel status codes: 1=pending, 2=in_transit, 3=delivered
            switch (status) {
                case 2:
                    shipmentStatus = client_1.ShipmentStatus.IN_TRANSIT;
                    break;
                case 3:
                    shipmentStatus = client_1.ShipmentStatus.DELIVERED;
                    break;
                case 7:
                    shipmentStatus = client_1.ShipmentStatus.RETURNED;
                    break;
                default:
                    shipmentStatus = client_1.ShipmentStatus.IN_TRANSIT;
            }
            // Update shipment
            await database_config_1.prisma.shipment.update({
                where: { id: shipment.id },
                data: {
                    status: shipmentStatus,
                    ...(shipmentStatus === client_1.ShipmentStatus.IN_TRANSIT && { shippedAt: new Date() }),
                    ...(shipmentStatus === client_1.ShipmentStatus.DELIVERED && { deliveredAt: new Date() }),
                },
            });
            // Update order status
            if (shipmentStatus === client_1.ShipmentStatus.DELIVERED) {
                await database_config_1.prisma.order.update({
                    where: { id: shipment.orderId },
                    data: {
                        status: 'DELIVERED',
                        completedAt: new Date(),
                    },
                });
            }
            else if (shipmentStatus === client_1.ShipmentStatus.IN_TRANSIT) {
                await database_config_1.prisma.order.update({
                    where: { id: shipment.orderId },
                    data: { status: 'SHIPPED' },
                });
            }
            logger_config_1.logger.info(`Shipment webhook processed: ${myparcelId} -> ${shipmentStatus}`);
        }
        catch (error) {
            logger_config_1.logger.error('MyParcel webhook processing failed:', error);
            throw error;
        }
    }
    /**
     * Create RETURN shipment and label
     * Volgens MyParcel API: https://developer.myparcel.nl/api-reference/
     */
    static async createReturnShipment(returnId) {
        if (!env_config_1.env.MYPARCEL_API_KEY) {
            throw new errors_util_1.InternalServerError('MyParcel API key not configured');
        }
        try {
            // Get return with order and address
            const returnRecord = await database_config_1.prisma.return.findUnique({
                where: { id: returnId },
                include: {
                    order: {
                        include: {
                            shippingAddress: true,
                        },
                    },
                },
            });
            if (!returnRecord || !returnRecord.order.shippingAddress) {
                throw new errors_util_1.NotFoundError(`Return ${returnId} not found or has no shipping address`);
            }
            const order = returnRecord.order;
            const address = order.shippingAddress;
            // Create RETURN shipment in MyParcel
            // Belangrijk: "return": true zorgt ervoor dat het een retourlabel wordt
            const response = await axios_1.default.post(`${this.API_URL}/shipments`, {
                data: {
                    shipments: [{
                            carrier: 1, // PostNL
                            recipient: {
                                cc: address.country,
                                person: `${address.firstName} ${address.lastName}`,
                                street: address.street,
                                number: address.houseNumber,
                                number_suffix: address.addition || '',
                                postal_code: address.postalCode,
                                city: address.city,
                                email: order.customerEmail,
                                phone: address.phone || order.customerPhone || '',
                            },
                            options: {
                                package_type: 1, // Package
                                delivery_type: 2, // Standard delivery
                                signature: false,
                                return: true, // ⭐ DIT MAAKT HET EEN RETURN LABEL!
                            },
                        }],
                },
            }, { headers: this.HEADERS });
            const myparcelId = response.data.data.ids[0].id;
            // Download return label
            const labelUrl = await this.downloadLabel(myparcelId);
            // Get tracking info
            const trackingInfo = await this.getTrackingInfo(myparcelId);
            // Update return record in database
            const updatedReturn = await database_config_1.prisma.return.update({
                where: { id: returnId },
                data: {
                    myparcelId,
                    trackingCode: trackingInfo.trackingCode,
                    trackingUrl: trackingInfo.trackingUrl,
                    labelUrl,
                    status: 'LABEL_CREATED',
                },
            });
            logger_config_1.logger.info(`Return shipment created: ${returnId} (MyParcel: ${myparcelId})`);
            return {
                returnId: updatedReturn.id,
                myparcelId,
                trackingCode: trackingInfo.trackingCode,
                trackingUrl: trackingInfo.trackingUrl,
                labelUrl,
            };
        }
        catch (error) {
            logger_config_1.logger.error('MyParcel return shipment creation failed:', error);
            throw new errors_util_1.InternalServerError(`Failed to create return shipment: ${error.message}`);
        }
    }
    /**
     * Track return shipment
     */
    static async trackReturnShipment(myparcelId) {
        try {
            const response = await axios_1.default.get(`${this.API_URL}/shipments/${myparcelId}`, { headers: this.HEADERS });
            const shipment = response.data.data.shipments[0];
            return {
                status: shipment.status,
                trackingCode: shipment.barcode,
                trackingUrl: `https://postnl.nl/tracktrace/?B=${shipment.barcode}&P=${shipment.recipient.postal_code}`,
                statusHistory: shipment.status_history || [],
            };
        }
        catch (error) {
            logger_config_1.logger.error('MyParcel return tracking failed:', error);
            throw new errors_util_1.InternalServerError('Failed to track return shipment');
        }
    }
}
exports.MyParcelService = MyParcelService;
//# sourceMappingURL=myparcel.service.js.map