import { Shipment } from '@prisma/client';
/**
 * MyParcel Shipping Service
 * Enterprise shipping integration
 */
export declare class MyParcelService {
    private static readonly API_URL;
    private static readonly HEADERS;
    /**
     * Create shipment and label
     */
    static createShipment(orderId: string): Promise<Shipment>;
    /**
     * Download label PDF
     */
    static downloadLabel(myparcelId: number): Promise<string>;
    /**
     * Get tracking information
     */
    static getTrackingInfo(myparcelId: number): Promise<{
        trackingCode: string;
        trackingUrl: string;
    }>;
    /**
     * Handle webhook from MyParcel
     */
    static handleWebhook(data: any): Promise<void>;
    /**
     * Create RETURN shipment and label
     * Volgens MyParcel API: https://developer.myparcel.nl/api-reference/
     */
    static createReturnShipment(returnId: string): Promise<any>;
    /**
     * Track return shipment
     */
    static trackReturnShipment(myparcelId: number): Promise<any>;
}
//# sourceMappingURL=myparcel.service.d.ts.map