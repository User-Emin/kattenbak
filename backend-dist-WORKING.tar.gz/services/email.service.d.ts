interface ReturnLabelEmailData {
    to: string;
    customerName: string;
    orderNumber: string;
    returnId: string;
    labelUrl: string;
    trackingCode: string;
    trackingUrl: string;
}
/**
 * Send return label email with instructions
 */
export declare function sendReturnLabelEmail(data: ReturnLabelEmailData): Promise<void>;
/**
 * Send order confirmation email
 */
export declare function sendOrderConfirmationEmail(data: {
    to: string;
    customerName: string;
    orderNumber: string;
    total: number;
    trackingUrl?: string;
}): Promise<void>;
/**
 * Test email configuration
 */
export declare function testEmailConfig(): Promise<boolean>;
export {};
//# sourceMappingURL=email.service.d.ts.map