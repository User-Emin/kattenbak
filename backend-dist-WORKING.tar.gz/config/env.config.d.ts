declare class EnvironmentConfig {
    readonly NODE_ENV: string;
    readonly IS_PRODUCTION: boolean;
    readonly IS_DEVELOPMENT: boolean;
    readonly BACKEND_PORT: number;
    readonly BACKEND_URL: string;
    readonly DATABASE_URL: string;
    readonly JWT_SECRET: string;
    readonly JWT_EXPIRES_IN: string;
    readonly MOLLIE_API_KEY: string;
    readonly MOLLIE_WEBHOOK_URL: string;
    readonly MYPARCEL_API_KEY: string;
    readonly SMTP_HOST: string;
    readonly SMTP_PORT: string;
    readonly SMTP_SECURE: string;
    readonly SMTP_USER: string;
    readonly SMTP_PASS: string;
    readonly MYPARCEL_WEBHOOK_URL: string;
    readonly REDIS_HOST: string;
    readonly REDIS_PORT: number;
    readonly REDIS_PASSWORD: string;
    readonly SMTP_HOST: string;
    readonly SMTP_PORT: string;
    readonly SMTP_USER: string;
    readonly SMTP_PASSWORD: string;
    readonly EMAIL_FROM: string;
    readonly ADMIN_EMAIL: string;
    readonly ADMIN_PASSWORD: string;
    readonly RATE_LIMIT_WINDOW_MS: number;
    readonly RATE_LIMIT_MAX_REQUESTS: number;
    readonly CORS_ORIGINS: string[];
    readonly LOG_LEVEL: string;
    readonly LOG_TO_FILE: boolean;
    readonly UPLOAD_MAX_SIZE: number;
    readonly UPLOAD_ALLOWED_TYPES: string[];
    readonly UPLOAD_PATH: string;
    readonly FRONTEND_URL: string;
    /**
     * Get required environment variable or throw error
     */
    private getRequired;
    /**
     * Validate configuration on startup
     */
    validate(): void;
}
export declare const env: EnvironmentConfig;
export {};
//# sourceMappingURL=env.config.d.ts.map