import { PrismaClient } from '@prisma/client';
/**
 * Prisma Client Singleton
 * Ensures single database connection instance
 */
declare class DatabaseClient {
    private static instance;
    private constructor();
    static getInstance(): PrismaClient;
    /**
     * Test database connection
     */
    static testConnection(): Promise<boolean>;
}
export declare const prisma: PrismaClient<import(".prisma/client").Prisma.PrismaClientOptions, never, import("@prisma/client/runtime/library").DefaultArgs>;
export { DatabaseClient };
//# sourceMappingURL=database.config.d.ts.map