"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisClient = exports.redis = void 0;
const ioredis_1 = __importDefault(require("ioredis"));
const env_config_1 = require("./env.config");
const logger_config_1 = require("./logger.config");
/**
 * Redis Client Singleton
 * Voor caching en session management
 */
class RedisClient {
    static instance = null;
    static isEnabled = false;
    constructor() { }
    static getInstance() {
        if (!RedisClient.instance && !RedisClient.isEnabled) {
            try {
                RedisClient.instance = new ioredis_1.default({
                    host: env_config_1.env.REDIS_HOST,
                    port: env_config_1.env.REDIS_PORT,
                    password: env_config_1.env.REDIS_PASSWORD || undefined,
                    retryStrategy: (times) => {
                        const delay = Math.min(times * 50, 2000);
                        return delay;
                    },
                    maxRetriesPerRequest: 3,
                });
                RedisClient.instance.on('connect', () => {
                    logger_config_1.logger.info('✅ Redis connected');
                    RedisClient.isEnabled = true;
                });
                RedisClient.instance.on('error', (error) => {
                    logger_config_1.logger.warn('Redis connection error (caching disabled):', error.message);
                    RedisClient.isEnabled = false;
                });
                RedisClient.instance.on('close', () => {
                    logger_config_1.logger.warn('Redis connection closed');
                    RedisClient.isEnabled = false;
                });
            }
            catch (error) {
                logger_config_1.logger.warn('Redis initialization failed (caching disabled):', error);
                RedisClient.instance = null;
            }
        }
        return RedisClient.instance;
    }
    /**
     * Check if Redis is available
     */
    static isAvailable() {
        return RedisClient.isEnabled && RedisClient.instance !== null;
    }
    /**
     * Graceful disconnect
     */
    static async disconnect() {
        if (RedisClient.instance) {
            await RedisClient.instance.quit();
            RedisClient.instance = null;
            RedisClient.isEnabled = false;
        }
    }
}
exports.RedisClient = RedisClient;
exports.redis = RedisClient.getInstance();
//# sourceMappingURL=redis.config.js.map