"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseClient = exports.prisma = void 0;
const client_1 = require("@prisma/client");
const env_config_1 = require("./env.config");
/**
 * Prisma Client Singleton
 * Ensures single database connection instance
 */
class DatabaseClient {
    static instance;
    constructor() { }
    static getInstance() {
        if (!DatabaseClient.instance) {
            DatabaseClient.instance = new client_1.PrismaClient({
                log: env_config_1.env.IS_DEVELOPMENT
                    ? ['query', 'info', 'warn', 'error']
                    : ['error'],
                errorFormat: env_config_1.env.IS_DEVELOPMENT ? 'pretty' : 'minimal',
            });
            // Handle graceful shutdown
            process.on('SIGINT', async () => {
                await DatabaseClient.instance.$disconnect();
                process.exit(0);
            });
            process.on('SIGTERM', async () => {
                await DatabaseClient.instance.$disconnect();
                process.exit(0);
            });
        }
        return DatabaseClient.instance;
    }
    /**
     * Test database connection
     */
    static async testConnection() {
        try {
            const client = DatabaseClient.getInstance();
            await client.$queryRaw `SELECT 1`;
            console.log('✅ Database connection successful');
            return true;
        }
        catch (error) {
            console.error('❌ Database connection failed:', error);
            return false;
        }
    }
}
exports.DatabaseClient = DatabaseClient;
exports.prisma = DatabaseClient.getInstance();
//# sourceMappingURL=database.config.js.map