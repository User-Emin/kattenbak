"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const winston_1 = __importDefault(require("winston"));
const winston_daily_rotate_file_1 = __importDefault(require("winston-daily-rotate-file"));
const env_config_1 = require("./env.config");
/**
 * Enterprise Logger Configuration
 * Structured logging met rotation en verschillende levels
 */
class Logger {
    static instance;
    constructor() { }
    static getInstance() {
        if (!Logger.instance) {
            const transports = [
                // Console transport
                new winston_1.default.transports.Console({
                    format: winston_1.default.format.combine(winston_1.default.format.colorize(), winston_1.default.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), winston_1.default.format.printf(({ timestamp, level, message, ...meta }) => {
                        const metaStr = Object.keys(meta).length ? JSON.stringify(meta, null, 2) : '';
                        return `${timestamp} [${level}]: ${message} ${metaStr}`;
                    })),
                }),
            ];
            // File transports (only if enabled)
            if (env_config_1.env.LOG_TO_FILE) {
                // Error logs
                transports.push(new winston_daily_rotate_file_1.default({
                    filename: 'logs/error-%DATE%.log',
                    datePattern: 'YYYY-MM-DD',
                    level: 'error',
                    maxSize: '20m',
                    maxFiles: '14d',
                    format: winston_1.default.format.combine(winston_1.default.format.timestamp(), winston_1.default.format.json()),
                }));
                // Combined logs
                transports.push(new winston_daily_rotate_file_1.default({
                    filename: 'logs/combined-%DATE%.log',
                    datePattern: 'YYYY-MM-DD',
                    maxSize: '20m',
                    maxFiles: '7d',
                    format: winston_1.default.format.combine(winston_1.default.format.timestamp(), winston_1.default.format.json()),
                }));
            }
            Logger.instance = winston_1.default.createLogger({
                level: env_config_1.env.LOG_LEVEL,
                format: winston_1.default.format.combine(winston_1.default.format.errors({ stack: true }), winston_1.default.format.timestamp(), winston_1.default.format.json()),
                defaultMeta: { service: 'kattenbak-backend' },
                transports,
            });
        }
        return Logger.instance;
    }
}
exports.logger = Logger.getInstance();
//# sourceMappingURL=logger.config.js.map