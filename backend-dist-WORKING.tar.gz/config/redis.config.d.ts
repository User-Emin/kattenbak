import Redis from 'ioredis';
/**
 * Redis Client Singleton
 * Voor caching en session management
 */
declare class RedisClient {
    private static instance;
    private static isEnabled;
    private constructor();
    static getInstance(): Redis | null;
    /**
     * Check if Redis is available
     */
    static isAvailable(): boolean;
    /**
     * Graceful disconnect
     */
    static disconnect(): Promise<void>;
}
export declare const redis: Redis | null;
export { RedisClient };
//# sourceMappingURL=redis.config.d.ts.map