import {
  Admin,
  Resource,
  List,
  Datagrid,
  TextField,
  NumberField,
  BooleanField,
  DateField,
  Edit,
  Create,
  SimpleForm,
  TextInput,
  NumberInput,
  BooleanInput,
  required,
  ArrayInput,
  SimpleFormIterator,
  ImageInput,
  ImageField,
} from "react-admin";
import { dataProvider } from "./dataProvider";
import { authProvider } from "./authProvider";
import { ShoppingCart, Inventory, LocalShipping, Category } from "@mui/icons-material";

/**
 * React Admin Dashboard - DRY & Maintainable
 * Met drag & drop image upload support
 */

// DRY: Product List Component
const ProductList = () => (
  <List>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="sku" />
      <TextField source="name" />
      <NumberField source="price" options={{ style: 'currency', currency: 'EUR' }} />
      <NumberField source="stock" />
      <BooleanField source="isActive" />
      <DateField source="updatedAt" />
    </Datagrid>
  </List>
);

// DRY: Product Edit/Create Form met Image Upload
const ProductForm = () => (
  <SimpleForm>
    <TextInput source="sku" validate={[required()]} />
    <TextInput source="name" validate={[required()]} fullWidth />
    <TextInput source="slug" validate={[required()]} fullWidth />
    <TextInput source="description" multiline rows={4} fullWidth />
    <TextInput source="shortDescription" multiline rows={2} fullWidth />
    
    <NumberInput source="price" validate={[required()]} />
    <NumberInput source="compareAtPrice" />
    <NumberInput source="costPrice" />
    <NumberInput source="stock" validate={[required()]} />
    
    {/* DRY: OPTIE 1 - Image Upload (Drag & Drop) */}
    <ImageInput 
      source="imageFiles" 
      label="Upload Product Afbeeldingen (Drag & Drop)"
      accept={{ 'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp'] }}
      multiple
      placeholder={<p>Sleep afbeeldingen hier, of klik om te selecteren</p>}
    >
      <ImageField source="src" title="title" />
    </ImageInput>
    
    {/* DRY: OPTIE 2 - Image URLs (Manual) */}
    <ArrayInput source="images" label="Of voer Image URLs in">
      <SimpleFormIterator inline>
        <TextInput 
          source="" 
          label="Image URL" 
          fullWidth 
          helperText="Volledige URL naar afbeelding"
          placeholder="https://example.com/image.jpg of /images/product.jpg"
        />
      </SimpleFormIterator>
    </ArrayInput>
    
    <BooleanInput source="isActive" />
    <BooleanInput source="isFeatured" />
    
    <TextInput source="metaTitle" fullWidth />
    <TextInput source="metaDescription" multiline rows={2} fullWidth />
  </SimpleForm>
);

const ProductEdit = () => (
  <Edit>
    <ProductForm />
  </Edit>
);

const ProductCreate = () => (
  <Create>
    <ProductForm />
  </Create>
);

// DRY: Order List
const OrderList = () => (
  <List>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="orderNumber" />
      <TextField source="customerEmail" />
      <NumberField source="total" options={{ style: 'currency', currency: 'EUR' }} />
      <TextField source="status" />
      <DateField source="createdAt" />
    </Datagrid>
  </List>
);

// DRY: Category List
const CategoryList = () => (
  <List>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="name" />
      <TextField source="slug" />
      <BooleanField source="isActive" />
      <DateField source="updatedAt" />
    </Datagrid>
  </List>
);

// DRY: Shipment List
const ShipmentList = () => (
  <List>
    <Datagrid rowClick="show">
      <TextField source="id" />
      <TextField source="orderId" />
      <TextField source="trackingNumber" />
      <TextField source="carrier" />
      <TextField source="status" />
      <DateField source="shippedAt" />
    </Datagrid>
  </List>
);

function App() {
  return (
    <Admin
      dataProvider={dataProvider}
      authProvider={authProvider}
      title="Kattenbak Admin"
    >
      <Resource
        name="products"
        list={ProductList}
        edit={ProductEdit}
        create={ProductCreate}
        icon={Inventory}
      />
      <Resource
        name="orders"
        list={OrderList}
        icon={ShoppingCart}
      />
      <Resource
        name="categories"
        list={CategoryList}
        icon={Category}
      />
      <Resource
        name="shipments"
        list={ShipmentList}
        icon={LocalShipping}
      />
    </Admin>
  );
}

export default App;
