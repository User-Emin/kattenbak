import axios from "axios";
import { DataProvider } from "react-admin";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3101/api/v1";

const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Add auth token to requests
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("auth_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/**
 * React Admin Data Provider - DRY & Backend Compatible
 * Backend response: { success: true, data: [...], meta: {...} }
 */
export const dataProvider: DataProvider = {
  getList: async (resource, params) => {
    const { page, perPage } = params.pagination || { page: 1, perPage: 10 };
    const { field, order } = params.sort || { field: 'id', order: 'ASC' };

    const response = await apiClient.get(`/admin/${resource}`, {
      params: {
        page,
        pageSize: perPage,
        sortBy: field,
        sortOrder: order.toLowerCase(),
        ...params.filter,
      },
    });

    // Backend: { success, data: [...], meta: { total } }
    return {
      data: response.data.data,
      total: response.data.meta.total,
    };
  },

  getOne: async (resource, params) => {
    const response = await apiClient.get(`/admin/${resource}/${params.id}`);
    // Backend: { success, data: {...} }
    return { data: response.data.data };
  },

  getMany: async (resource, params) => {
    const responses = await Promise.all(
      params.ids.map((id) => apiClient.get(`/admin/${resource}/${id}`))
    );
    return { data: responses.map((r) => r.data.data) };
  },

  getManyReference: async (resource, params) => {
    const { page, perPage } = params.pagination;
    const { field, order } = params.sort;

    const response = await apiClient.get(`/admin/${resource}`, {
      params: {
        [params.target]: params.id,
        page,
        pageSize: perPage,
        sortBy: field,
        sortOrder: order.toLowerCase(),
      },
    });

    return {
      data: response.data.data,
      total: response.data.meta.total,
    };
  },

  create: async (resource, params) => {
    // DRY: Handle file uploads for images
    const data = { ...params.data };
    
    // Convert uploaded files to image URLs
    if (params.data.imageFiles) {
      const newImageUrls: string[] = [];
      
      for (const file of params.data.imageFiles) {
        if (file.rawFile) {
          // Create a local URL for the uploaded file
          const localUrl = URL.createObjectURL(file.rawFile);
          newImageUrls.push(localUrl);
        }
      }
      
      // Merge with existing images array
      data.images = [...(data.images || []), ...newImageUrls];
      delete data.imageFiles; // Remove file objects before sending
    }
    
    const response = await apiClient.post(`/admin/${resource}`, data);
    return { data: response.data.data };
  },

  update: async (resource, params) => {
    // DRY: Handle file uploads for images
    const data = { ...params.data };
    
    // Convert uploaded files to image URLs
    if (params.data.imageFiles) {
      const newImageUrls: string[] = [];
      
      for (const file of params.data.imageFiles) {
        if (file.rawFile) {
          // Create a local URL for the uploaded file
          const localUrl = URL.createObjectURL(file.rawFile);
          newImageUrls.push(localUrl);
        }
      }
      
      // Merge with existing images array
      data.images = [...(data.images || []), ...newImageUrls];
      delete data.imageFiles; // Remove file objects before sending
    }
    
    const response = await apiClient.put(`/admin/${resource}/${params.id}`, data);
    return { data: response.data.data };
  },

  updateMany: async (resource, params) => {
    await Promise.all(
      params.ids.map((id) =>
        apiClient.put(`/admin/${resource}/${id}`, params.data)
      )
    );
    return { data: params.ids };
  },

  delete: async (resource, params) => {
    await apiClient.delete(`/admin/${resource}/${params.id}`);
    return { data: params.previousData! };
  },

  deleteMany: async (resource, params) => {
    await Promise.all(
      params.ids.map((id) => apiClient.delete(`/admin/${resource}/${id}`))
    );
    return { data: params.ids };
  },
};

