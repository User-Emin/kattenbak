import { AuthProvider } from "react-admin";
import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3101/api/v1";

/**
 * React Admin Auth Provider - DRY & Maintainable
 * FIX: Prevents infinite loops door correcte Promise handling
 */
export const authProvider: AuthProvider = {
  login: async ({ username, password }) => {
    try {
      const response = await axios.post(`${API_URL}/admin/auth/login`, {
        email: username,
        password,
      });

      const { token, user } = response.data.data;
      localStorage.setItem("auth_token", token);
      localStorage.setItem("auth_user", JSON.stringify(user));

      return Promise.resolve();
    } catch (error: any) {
      console.error("Login error:", error.response?.data || error.message);
      return Promise.reject(new Error(error.response?.data?.error || "Login failed"));
    }
  },

  logout: async () => {
    localStorage.removeItem("auth_token");
    localStorage.removeItem("auth_user");
    return Promise.resolve();
  },

  checkAuth: async () => {
    const token = localStorage.getItem("auth_token");
    if (!token) {
      return Promise.reject(new Error("Not authenticated"));
    }
    return Promise.resolve();
  },

  checkError: async (error) => {
    const status = error?.status || error?.response?.status;
    if (status === 401 || status === 403) {
      localStorage.removeItem("auth_token");
      localStorage.removeItem("auth_user");
      return Promise.reject(new Error("Unauthorized"));
    }
    // CRITICAL: Always resolve for non-auth errors to prevent infinite loops
    return Promise.resolve();
  },

  getIdentity: async () => {
    try {
      const userStr = localStorage.getItem("auth_user");
      if (!userStr) {
        return Promise.reject(new Error("No user data"));
      }

      const user = JSON.parse(userStr);
      return Promise.resolve({
        id: user.id,
        fullName: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email,
        avatar: undefined,
      });
    } catch (error) {
      return Promise.reject(new Error("Failed to get identity"));
    }
  },

  getPermissions: async () => {
    // Return empty permissions - no infinite loop
    return Promise.resolve(undefined);
  },
};

