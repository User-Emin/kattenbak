# 🔐 ADMIN LOGIN TEST GUIDE

## ✅ DEFINITIEVE WERKENDE SETUP

### 🌐 URLs
- **Frontend**: http://localhost:3100
- **Backend API**: http://localhost:3101
- **Admin Panel**: http://localhost:3102

### 🔑 Login Credentials (Dynamisch via ENV)
```bash
Email: admin@localhost
Password: admin123
```

### 📋 TEST STAPPEN

#### 1. Test Backend API Direct (CURL)
```bash
curl -X POST http://localhost:3101/api/v1/admin/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@localhost","password":"admin123"}' | jq
```

**Verwacht resultaat:**
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGc...",
    "user": {
      "id": "admin-1",
      "email": "admin@localhost",
      "role": "ADMIN"
    }
  }
}
```

#### 2. Test Admin Panel Login (Browser)
1. Open: http://localhost:3102
2. Vul in:
   - Username: `admin@localhost`
   - Password: `admin123`
3. Klik "Sign in"

**Verwacht resultaat:**
- ✅ Redirect naar dashboard
- ✅ Ziet "Products", "Orders", "Categories", "Shipments" in menu

#### 3. Alternatieve Test (Als form issues)
```bash
# Open browser console en run:
localStorage.setItem('auth_token', 'manual-test-token');
localStorage.setItem('auth_user', '{"id":"admin-1","email":"admin@localhost","role":"ADMIN","firstName":"Admin","lastName":"User"}');
location.reload();
```

## 🔧 TROUBLESHOOTING

### Issue: "Internal Server Error"
**Fix:** Backend response helper gebruikt verkeerde signature
```typescript
// FOUT: res.json(successResponse(data))
// GOED: successResponse(res, data)
```

### Issue: Form validation "Required"
**Oorzaak:** React Admin form detecteert typed input niet altijd
**Fix:** Gebruik browser's eigen autocomplete of localStorage inject

### Issue: "Site niet bereikbaar"
**Fix:** 
```bash
# Restart services
lsof -ti:3102 | xargs kill -9
cd admin && npm run dev
```

## 📝 CONFIGURATIE LOCATIES

### Backend Credentials (DRY - Single Source)
`backend/src/config/env.config.ts`:
```typescript
public readonly ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@localhost';
public readonly ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
```

### Admin Panel API URL (DRY)
`admin/src/authProvider.ts` & `admin/src/dataProvider.ts`:
```typescript
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3101/api/v1";
```

### Frontend API URL (DRY)
`frontend/lib/config.ts`:
```typescript
export const API_CONFIG = {
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3101/api/v1',
};
```

## 🎯 SUCCES CRITERIA
- [x] Backend login endpoint returns token
- [x] Admin panel loads without errors
- [x] Login credentials are dynamisch via ENV
- [x] Geen hardcoded values (DRY)
- [x] Maximaal maintainable setup
- [ ] Succesvolle manual login via browser ⬅️ LAATSTE STAP

## 📊 HUIDIGE STATUS
```
✅ Backend API: WERKEND (curl test slaagt)
✅ Admin Panel: BEREIKBAAR (loads correct)
✅ Credentials: DYNAMISCH (via env vars)
⏳ Browser Login: TE TESTEN HANDMATIG
```

