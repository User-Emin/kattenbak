(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/kattenbak_admin-next_app_globals_950b02bd.css",
  "static/chunks/44ceb_336aacac._.js",
  "static/chunks/kattenbak_admin-next_a374af5a._.js"
],
    source: "dynamic"
});
