(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/44ceb_zod_v4_d4c50a3b._.js",
  "static/chunks/44ceb_tailwind-merge_dist_bundle-mjs_mjs_8c2a8614._.js",
  "static/chunks/44ceb_b40290a8._.js",
  "static/chunks/kattenbak_admin-next_4096d119._.js"
],
    source: "dynamic"
});
