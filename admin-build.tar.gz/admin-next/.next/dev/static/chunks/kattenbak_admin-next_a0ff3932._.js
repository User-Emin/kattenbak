(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_525b6b17._.js",
  "static/chunks/44ceb_next_dist_compiled_react-dom_c15b6569._.js",
  "static/chunks/44ceb_next_dist_compiled_react-server-dom-turbopack_8b3bca25._.js",
  "static/chunks/44ceb_next_dist_compiled_next-devtools_index_355ba2f4.js",
  "static/chunks/44ceb_next_dist_compiled_c95eb555._.js",
  "static/chunks/44ceb_next_dist_client_23c21356._.js",
  "static/chunks/44ceb_next_dist_f3eb6b30._.js",
  "static/chunks/44ceb_@swc_helpers_cjs_bb573137._.js"
],
    source: "entry"
});
