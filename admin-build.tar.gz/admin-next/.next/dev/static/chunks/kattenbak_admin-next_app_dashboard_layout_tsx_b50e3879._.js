(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/44ceb_5d8c33ee._.js",
  "static/chunks/kattenbak_admin-next_2707bbb0._.js"
],
    source: "dynamic"
});
