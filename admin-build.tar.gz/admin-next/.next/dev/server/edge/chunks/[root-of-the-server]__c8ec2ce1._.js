(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__c8ec2ce1._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/kattenbak/admin-next/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * SECURITY MIDDLEWARE - XSS & Input Sanitization
 */ __turbopack_context__.s([
    "checkRateLimit",
    ()=>checkRateLimit,
    "config",
    ()=>config,
    "isValidUrl",
    ()=>isValidUrl,
    "middleware",
    ()=>middleware,
    "sanitizeInput",
    ()=>sanitizeInput,
    "securityHeaders",
    ()=>securityHeaders
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$admin$2d$next$2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/kattenbak/admin-next/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$admin$2d$next$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kattenbak/admin-next/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
;
const securityHeaders = {
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'
};
function sanitizeInput(input) {
    return input.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;').replace(/\//g, '&#x2F;');
}
function isValidUrl(url) {
    try {
        const parsed = new URL(url);
        return [
            'http:',
            'https:'
        ].includes(parsed.protocol);
    } catch  {
        return false;
    }
}
// DRY: Rate limiting (simple in-memory)
const requestCounts = new Map();
function checkRateLimit(ip, limit = 100, windowMs = 60000) {
    const now = Date.now();
    const record = requestCounts.get(ip);
    if (!record || now > record.resetTime) {
        requestCounts.set(ip, {
            count: 1,
            resetTime: now + windowMs
        });
        return true;
    }
    if (record.count >= limit) {
        return false;
    }
    record.count++;
    return true;
}
function middleware(request) {
    const response = __TURBOPACK__imported__module__$5b$project$5d2f$kattenbak$2f$admin$2d$next$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    // Add security headers
    Object.entries(securityHeaders).forEach(([key, value])=>{
        response.headers.set(key, value);
    });
    return response;
}
const config = {
    matcher: [
        '/((?!_next/static|_next/image|favicon.ico).*)'
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__c8ec2ce1._.js.map