module.exports = [
"[project]/kattenbak/admin-next/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app__not-found_page_actions_5a257caf.js.map