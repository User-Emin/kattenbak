module.exports = [
"[project]/kattenbak/admin-next/.next-internal/server/app/dashboard/returns/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=8ef6f_admin-next__next-internal_server_app_dashboard_returns_page_actions_9008c030.js.map