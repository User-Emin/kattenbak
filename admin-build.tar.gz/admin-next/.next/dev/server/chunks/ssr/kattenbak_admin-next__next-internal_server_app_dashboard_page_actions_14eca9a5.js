module.exports = [
"[project]/kattenbak/admin-next/.next-internal/server/app/dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app_dashboard_page_actions_14eca9a5.js.map