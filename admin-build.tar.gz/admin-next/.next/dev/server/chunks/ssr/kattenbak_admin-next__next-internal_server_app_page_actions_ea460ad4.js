module.exports = [
"[project]/kattenbak/admin-next/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kattenbak_admin-next__next-internal_server_app_page_actions_ea460ad4.js.map